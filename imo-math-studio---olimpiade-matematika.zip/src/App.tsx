import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { TheorySection } from './components/TheorySection';
import { MathDictionary } from './components/MathDictionary';
import { ProblemBank } from './components/ProblemBank';
import { ProofWorkspace } from './components/ProofWorkspace';
import { AITutorView } from './components/AITutorView';
import { ExamSimulation } from './components/ExamSimulation';
import { Footer } from './components/Footer';
import { INITIAL_PROBLEMS } from './data/imoData';
import { IMOProblem, UserProgress } from './types';
import { Bookmark, CheckCircle2, X, Trash2, ArrowRight } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [selectedTopicForTheory, setSelectedTopicForTheory] = useState<string>('Semua');

  // Problems state
  const [problems, setProblems] = useState<IMOProblem[]>(INITIAL_PROBLEMS);
  const [activeProblemForWorkspace, setActiveProblemForWorkspace] = useState<IMOProblem | null>(null);

  // Bookmarks Modal state
  const [isBookmarksOpen, setIsBookmarksOpen] = useState<boolean>(false);

  // Persistent User Progress
  const [userProgress, setUserProgress] = useState<UserProgress>(() => {
    try {
      const saved = localStorage.getItem('imo_user_progress');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return {
      solvedProblemIds: ['imo-2019-p1'],
      bookmarkedProblemIds: ['osn-2023-p2'],
      submissions: [],
      streakDays: 3,
      lastActiveDate: new Date().toISOString().split('T')[0],
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem('imo_user_progress', JSON.stringify(userProgress));
    } catch (e) {
      // ignore
    }
  }, [userProgress]);

  // Toggle Bookmark
  const handleToggleBookmark = (problemId: string) => {
    setUserProgress((prev) => {
      const isBookmarked = prev.bookmarkedProblemIds.includes(problemId);
      const updatedBookmarks = isBookmarked
        ? prev.bookmarkedProblemIds.filter((id) => id !== problemId)
        : [...prev.bookmarkedProblemIds, problemId];
      return { ...prev, bookmarkedProblemIds: updatedBookmarks };
    });
  };

  // Save Submission
  const handleSaveSubmission = (problemId: string, proof: string, score: number) => {
    setUserProgress((prev) => {
      const newSub = {
        problemId,
        userProof: proof,
        score,
        submittedAt: new Date().toISOString(),
      };

      const isSolved = score >= 5;
      const updatedSolved = isSolved && !prev.solvedProblemIds.includes(problemId)
        ? [...prev.solvedProblemIds, problemId]
        : prev.solvedProblemIds;

      return {
        ...prev,
        solvedProblemIds: updatedSolved,
        submissions: [newSub, ...prev.submissions],
      };
    });
  };

  // Add new AI Generated problem
  const handleAddNewProblem = (newProb: IMOProblem) => {
    setProblems((prev) => [newProb, ...prev]);
  };

  // Navigate to ProofWorkspace with selected problem
  const handleSelectProblemForProof = (problem: IMOProblem) => {
    setActiveProblemForWorkspace(problem);
    setActiveTab('workspace');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        userProgress={userProgress}
        onOpenBookmarks={() => setIsBookmarksOpen(true)}
      />

      {/* Main Content View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 pt-3 sm:pt-8 pb-24 md:pb-12">
        {activeTab === 'overview' && (
          <HeroSection
            onNavigate={(tab) => setActiveTab(tab)}
            onSelectTopic={(topic) => setSelectedTopicForTheory(topic)}
            problems={problems}
            onSelectProblemForProof={handleSelectProblemForProof}
            onToggleBookmark={handleToggleBookmark}
            userProgress={userProgress}
          />
        )}

        {activeTab === 'theory' && (
          <TheorySection
            initialTopic={selectedTopicForTheory}
            onNavigateToProblems={(topic) => {
              setSelectedTopicForTheory(topic);
              setActiveTab('problems');
            }}
          />
        )}

        {activeTab === 'dictionary' && (
          <MathDictionary />
        )}

        {activeTab === 'problems' && (
          <ProblemBank
            problems={problems}
            selectedTopicFilter={selectedTopicForTheory}
            userProgress={userProgress}
            onToggleBookmark={handleToggleBookmark}
            onSelectProblemForProof={handleSelectProblemForProof}
            onAddNewProblem={handleAddNewProblem}
          />
        )}

        {activeTab === 'workspace' && (
          <ProofWorkspace
            activeProblem={activeProblemForWorkspace}
            problems={problems}
            userProgress={userProgress}
            onSelectProblem={(p) => setActiveProblemForWorkspace(p)}
            onSaveSubmission={handleSaveSubmission}
          />
        )}

        {activeTab === 'tutor' && (
          <AITutorView activeProblem={activeProblemForWorkspace} />
        )}

        {activeTab === 'exam' && (
          <ExamSimulation
            problems={problems}
            onFinishExam={(score) => {
              // Updated user streak
              setUserProgress((prev) => ({ ...prev, streakDays: prev.streakDays + 1 }));
            }}
          />
        )}
      </main>

      {/* Saved Bookmarks Drawer Modal */}
      {isBookmarksOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-6 shadow-2xl space-y-4 my-8 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <Bookmark className="w-5 h-5 text-amber-500 fill-amber-500" />
                <h3 className="text-xl font-bold text-slate-900">Soal Tersimpan Saya</h3>
              </div>
              <button
                onClick={() => setIsBookmarksOpen(false)}
                className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {userProgress.bookmarkedProblemIds.length === 0 ? (
              <p className="text-slate-500 text-xs py-8 text-center font-medium">Belum ada soal yang Anda simpan.</p>
            ) : (
              <div className="space-y-3">
                {userProgress.bookmarkedProblemIds.map((id) => {
                  const prob = problems.find((p) => p.id === id);
                  if (!prob) return null;
                  return (
                    <div
                      key={id}
                      className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4 text-xs"
                    >
                      <div>
                        <span className="font-bold text-indigo-900">[{prob.topic}] {prob.title}</span>
                        <p className="text-slate-500 text-[11px] mt-0.5">{prob.source} • {prob.difficulty}</p>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            setIsBookmarksOpen(false);
                            handleSelectProblemForProof(prob);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] shadow-xs"
                        >
                          Buka di Papan
                        </button>
                        <button
                          onClick={() => handleToggleBookmark(id)}
                          className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50"
                          title="Hapus"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <Footer />
    </div>
  );
}
