export type IMOTopic = 'Aljabar' | 'Kombinatorika' | 'Geometri' | 'Teori Bilangan';

export type DifficultyLevel = 'Kota/Provinsi' | 'OSN Nasional' | 'IMO' | 'IMO Shortlist';

export interface IMOProblem {
  id: string;
  title: string;
  topic: IMOTopic;
  difficulty: DifficultyLevel;
  year: string;
  source: string; // e.g., "IMO 2019 Problem 1", "OSN 2022 SMA"
  statement: string; // LaTeX enabled text
  hints: string[];
  solution: string; // LaTeX enabled text
  keyConcepts: string[];
}

export interface ExampleProblem {
  title: string;
  level: 'Intermediate' | 'Medium' | 'Hard';
  levelLabel: string; // e.g. "Level Intermediate (OSN-K)", "Level Medium (OSN-P)", "Level Hard (IMO Shortlist)"
  problemText: string;
  solutionText: string;
  keyTakeaway: string;
}

export interface ChallengeProblem {
  id: string;
  title: string;
  difficultyLabel: string; // e.g. "Tantangan OSN-K", "Tantangan OSN-P", "Tantangan IMO"
  problemText: string;
  hint?: string;
  solutionText: string;
  keyTakeaway?: string;
}

export interface RecommendedBook {
  title: string;
  author: string;
  description: string;
  level: 'Pemula & Menengah' | 'Olimpiade Nasional (OSN)' | 'Tingkat IMO / Internasional';
}

export interface SubChapter {
  id: string;
  title: string;
  description: string;
  detailedContent: string; // Detailed lecture text with LaTeX
  workedExamples: ExampleProblem[]; // Graded examples: Intermediate, Medium, Hard
  challengeProblems?: ChallengeProblem[]; // Challenge problems per subchapter
  diagramType?: 
    | 'ceva-menelaus' 
    | 'cyclic-quad' 
    | 'miquel-theorem' 
    | 'simson-line' 
    | 'power-of-point' 
    | 'incircle-excircle' 
    | 'euler-line'
    | 'pascal-theorem';
}

export interface TheoryModule {
  id: string;
  topic: IMOTopic;
  title: string;
  subtitle: string;
  summary: string;
  content: string; // Markdown/LaTeX overview
  applicationGuide?: string; // Step-by-step methodology to solve problems
  recommendedBooks?: RecommendedBook[];
  subChapters?: SubChapter[];
  challengeProblems?: ChallengeProblem[]; // Challenge problems for the module
  keyTheorems: {
    name: string;
    statement: string;
    proofOutline: string;
    exampleProblem: string;
    applicationMethod?: string;
  }[];
  tips: string[];
}

export interface ProofEvaluationResult {
  score: number; // 0 - 7
  summary: string;
  strengths: string[];
  gaps: string[];
  suggestions: string;
  detailedFeedback: string;
}

export interface UserProgress {
  solvedProblemIds: string[];
  bookmarkedProblemIds: string[];
  submissions: {
    problemId: string;
    userProof: string;
    score: number;
    submittedAt: string;
  }[];
  streakDays: number;
  lastActiveDate: string;
}
