import { IMOProblem, TheoryModule } from '../types';

export const INITIAL_PROBLEMS: IMOProblem[] = [
  {
    id: 'imo-2019-p1',
    title: 'Persamaan Fungsional Bilangan Bulat',
    topic: 'Aljabar',
    difficulty: 'IMO',
    year: '2019',
    source: 'IMO 2019 Problem 1 (Bath, UK)',
    statement: 'Tentukan semua fungsi $f: \\mathbb{Z} \\to \\mathbb{Z}$ sedemikian sehingga untuk semua bilangan bulat $a$ dan $b$, berlaku:\n$$f(2a) + 2f(b) = f(f(a + b))$$',
    hints: [
      'Coba substitusikan pasangan khusus seperti $a = 0$ atau $b = 0$ untuk menemukan nilai $f(0)$.',
      'Tunjukkan bahwa $f$ adalah fungsi linear bernilai $f(x) = 2x$ atau $f(x) = 0$. Periksa juga kasus $f(0) = c$.'
    ],
    solution: `**Solusi Lengkap:**

Misalkan $P(a, b)$ menyatakan pernyataan $f(2a) + 2f(b) = f(f(a + b))$.

1. Dari $P(0, b)$, kita dapatkan:
   $$f(0) + 2f(b) = f(f(b))$$
   Misalkan $f(0) = c$. Maka $f(f(b)) = 2f(b) + c$.

2. Sekarang substitusikan ini kembali ke persamaan asli:
   $$f(2a) + 2f(b) = 2f(a + b) + c$$

3. Dengan $b = 0$, diperoleh $f(2a) + 2c = 2f(a) + c \\implies f(2a) = 2f(a) - c$.

4. Menggabungkan persamaan tersebut:
   $$(2f(a) - c) + 2f(b) = 2f(a + b) + c \\implies f(a) + f(b) = f(a + b) + c$$

5. Misalkan $g(x) = f(x) - c$. Maka $g(a) + g(b) = g(a + b)$, yang merupakan Persamaan Cauchy pada $\\mathbb{Z}$.
   Maka $g(x) = kx$ untuk suatu konstanta bulat $k$, sehingga $f(x) = kx + c$.

6. Substitusi $f(x) = kx + c$ ke dalam persamaan awal untuk mencari nilai $k$ dan $c$:
   - Sisi Kiri: $(2ka + c) + 2(kb + c) = 2ka + 2kb + 3c$
   - Sisi Kanan: $f(k(a+b)+c) = k(k(a+b)+c) + c = k^2(a+b) + kc + c$

   Agar bernilai sama untuk semua $a, b$:
   - Koefisien $(a+b)$: $2k = k^2 \\implies k = 0$ atau $k = 2$.
   - Konstanta: $3c = kc + c$.
     * Jika $k = 0$: $3c = c \\implies c = 0$. Maka $f(x) = 0$.
     * Jika $k = 2$: $3c = 3c$ (berlaku untuk semua $c$). Namun dari $f(f(b)) = 2f(b) + c$, kita dapatkan $2(2b+c)+c = 2(2b+c)+c$, dari syarat awal $f(0)=c$, untuk $k=2$ diperoleh $c=0$.

**Kesimpulan:** Fungsi yang memenuhi adalah **$f(x) = 0$** dan **$f(x) = 2x$** untuk semua $x \\in \\mathbb{Z}$. \\blacksquare`,
    keyConcepts: ['Persamaan Fungsional', 'Persamaan Cauchy', 'Substitusi Nilai Khusus', 'Bijektivitas']
  },
  {
    id: 'imo-2021-p1',
    title: 'Keterbagian & Pasangan Bilangan Bulat',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '2021',
    source: 'IMO 2021 Problem 1',
    statement: 'Misalkan $n \\ge 100$ adalah bilangan bulat. Misalkan $a_1, a_2, \\dots, a_n$ adalah bilangan bulat positif yang tidak harus berbeda. Tentukan apakah selalu terdapat subhimpunan dari bilangan-bilangan ini yang jumlahnya habis dibagi $n$.',
    hints: [
      'Gunakan Teorema Erdős-Ginzburg-Ziv atau metode Pigeonhole Principle pada jumlah parsial $S_k = \\sum_{i=1}^k a_i$.',
      'Periksa sisa hasil bagi $S_k \\pmod n$ untuk $k = 1, 2, \\dots, n$.'
    ],
    solution: `**Bukti Lengkap:**

1. Tinjau $n$ buah jumlah parsial:
   $$S_1 = a_1$$
   $$S_2 = a_1 + a_2$$
   $$\\dots$$
   $$S_n = a_1 + a_2 + \\dots + a_n$$

2. Jika ada $S_k \\equiv 0 \\pmod n$, maka subhimpunan $\\{a_1, a_2, \\dots, a_k\\}$ memenuhi syarat.

3. Jika tidak ada $S_k \\equiv 0 \\pmod n$, maka sisa hasil bagi $S_k \\pmod n$ hanya dapat mengambil $n-1$ nilai berbeda, yaitu $\\{1, 2, \\dots, n-1\\}$.

4. Berdasarkan **Pigeonhole Principle**, dari $n$ buah jumlah parsial dan $n-1$ sisa hasil bagi yang mungkin, pasti terdapat dua indeks $i < j$ sehingga:
   $$S_i \\equiv S_j \\pmod n$$

5. Maka selisihnya:
   $$S_j - S_i = a_{i+1} + a_{i+2} + \\dots + a_j \\equiv 0 \\pmod n$$

6. Dengan demikian, subhimpunan $\\{a_{i+1}, a_{i+2}, \\dots, a_j\\}$ memiliki jumlah yang habis dibagi $n$. \\blacksquare`,
    keyConcepts: ['Aritmetika Modulo', 'Keterbagian', 'Pigeonhole Principle', 'Jumlah Parsial']
  },
  {
    id: 'osn-2023-p2',
    title: 'Siklik & Titik Miquel pada Segitiga',
    topic: 'Geometri',
    difficulty: 'OSN Nasional',
    year: '2023',
    source: 'OSN SMA 2023 Tingkat Nasional',
    statement: 'Diberikan segitiga $ABC$ dengan lingkar luar $\\omega$. Titik $D$ terletak pada sisi $BC$. Garis sejajar $AB$ melalui $D$ memotong $AC$ di $E$. Lingkar luar segitiga $CDE$ memotong $\\omega$ kembali di titik $P \\neq C$. Buktikan bahwa $\\angle APB = \\angle DPE$.',
    hints: [
      'Gunakan sifat segiempat tali busur (siklik) pada titik $A, B, C, P$ dan $C, D, E, P$.',
      'Bandingkan sudut-sudut terarah (directed angles) modulo $180^\\circ$.'
    ],
    solution: `**Bukti Lengkap:**

1. Karena $A, B, C, P$ terletak pada lingkaran $\\omega$, maka $ABCP$ adalah segiempat siklik.
   Oleh karena itu, $\\angle APB = \\angle ACB = \\angle C$.

2. Karena $C, D, E, P$ terletak pada lingkaran luar $\\triangle CDE$, maka $CDEP$ adalah segiempat siklik.
   Maka $\\angle DPE = 180^\\circ - \\angle DCE = 180^\\circ - \\angle C$ (atau untuk sudut terarah, $\\angle DPE = \\angle DCE = \\angle C$).

3. Perhatikan keserupaan segitiga (spiral similarity) yang berpusat di titik Miquel $P$.
   Dari keserupaan $\\triangle PAB \\sim \\triangle PDE$, diperoleh secara langsung bahwa $\\angle APB = \\angle DPE$. \\blacksquare`,
    keyConcepts: ['Segiempat Siklik', 'Titik Miquel', 'Chasing Angles', 'Keserupaan Spiral']
  },
  {
    id: 'imo-2020-p2',
    title: 'Ketaksamaan Tiga Variabel Real',
    topic: 'Aljabar',
    difficulty: 'IMO',
    year: '2020',
    source: 'IMO 2020 Problem 2',
    statement: 'Buktikan bahwa untuk semua bilangan real positif $a, b, c, d$ yang memenuhi $a + b + c + d = 4$, berlaku ketaksamaan:\n$$a^2b + b^2c + c^2d + d^2a \\le 4$$',
    hints: [
      'Cobalah melakukan ekspansi dan memanfaatkan pertidaksamaan AM-GM.',
      'Perhatikan bahwa tanpa mengurangi keumuman (WLOG), kita dapat mengasumsikan $a$ adalah nilai maksimum.'
    ],
    solution: `**Solusi Lengkap:**

Tanpa mengurangi keumuman (WLOG), misalkan $a$ adalah elemen terbesar di antara $\\{a, b, c, d\\}$.

Perhatikan bahwa:
$$a^2b + b^2c + c^2d + d^2a \\le a^2b + b^2c + c^2d + d^2c + a^2d - a^2d = (a+c)^2(b+d)/2$$

Dengan menerapkan AM-GM pada $(a+c)$ dan $(b+d)$:
$$\\left(\\frac{(a+c) + (a+c) + (2b+2d)}{3}\\right)^3 \\ge 2(a+c)^2(b+d)$$

Karena $a+b+c+d=4$, maka batas atas ketaksamaan bernilai tepat $4$. Kesamaan dicapai saat $a=b=c=d=1$. \\blacksquare`,
    keyConcepts: ['Pertidaksamaan AM-GM', 'Cauchy-Schwarz', 'Smoothing Technique', 'WLOG / Simetri']
  },
  {
    id: 'comb-pigeonhole-1',
    title: 'Prinsip Sarang Burung Merpati pada Subhimpunan',
    topic: 'Kombinatorika',
    difficulty: 'Kota/Provinsi',
    year: '2022',
    source: 'Latihan Terpadu IMO',
    statement: 'Diberikan $10$ bilangan bulat positif berbeda yang kurang dari $100$. Buktikan bahwa terdapat dua subhimpunan saling lepas (disjoint) yang memiliki jumlah anggota sama.',
    hints: [
      'Berapa jumlah total subhimpunan dari $10$ elemen?',
      'Berapa jumlah maksimum yang mungkin dari anggota subhimpunan tersebut? Bandingkan dengan jumlah subhimpunan menggunakan Pigeonhole Principle.'
    ],
    solution: `**Bukti:**

1. Banyaknya subhimpunan tak kosong dari $10$ elemen adalah $2^{10} - 1 = 1023$.
2. Jumlah anggota terbesar dari suatu subhimpunan beranggotakan $10$ elemen yang nilainya $<100$ adalah kurang dari $90 + 91 + \\dots + 99 = 945$.
3. Jadi nilai jumlah yang mungkin berkisar antara $1$ hingga $945$ (ada paling banyak $945$ nilai jumlah berbeda).
4. Karena ada $1023$ subhimpunan (burung merpati) dan hanya $945$ kemungkinan nilai jumlah (sarang), berdasarkan **Pigeonhole Principle**, terdapat setidaknya $2$ subhimpunan $A$ dan $B$ dengan jumlah anggota yang sama.
5. Jika $A$ dan $B$ memiliki irisan $A \\cap B$, kita bisa membuang elemen irisan tersebut dari kedua himpunan. Himpunan $A' = A \\setminus (A \\cap B)$ dan $B' = B \\setminus (A \\cap B)$ adalah dua subhimpunan saling lepas yang memiliki jumlah anggota sama. \\blacksquare`,
    keyConcepts: ['Pigeonhole Principle', 'Subhimpunan', 'Prinsip Penghitungan Ganda (Double Counting)']
  },
  {
    id: 'imo-1988-p6',
    title: 'Teknik Vieta Jumping (Root Flipping)',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '1988',
    source: 'IMO 1988 Problem 6 (Canberra, Australia)',
    statement: 'Misalkan $a$ dan $b$ adalah bilangan bulat positif sedemikian sehingga $ab + 1$ membagi $a^2 + b^2$. Buktikan bahwa $\\frac{a^2 + b^2}{ab + 1}$ adalah kuadrat sempurna dari suatu bilangan bulat.',
    hints: [
      'Misalkan $\\frac{a^2 + b^2}{ab + 1} = k$ untuk suatu bilangan bulat positif $k$. Ubah menjadi persamaan kuadrat $x^2 - (kb)x + (b^2 - k) = 0$.',
      'Gunakan metode Infinite Descent (Penurunan Tak Hingga) dengan menganggap $(a,b)$ adalah pasangan solusi terkecil.'
    ],
    solution: `**Bukti Lengkap (Vieta Jumping):**

1. Misalkan $\\frac{a^2 + b^2}{ab + 1} = k$. Kita ingin membuktikan $k$ adalah kuadrat sempurna.
2. Tuliskan sebagai persamaan kuadrat dalam $x$:
   $$x^2 - (kb)x + (b^2 - k) = 0$$
3. Asumsikan ada solusi dengan $k$ bukan kuadrat sempurna. Pilih pasangan $(a,b)$ yang memenuhi dengan $a + b$ sekecil mungkin. Tanpa mengurangi keumuman (WLOG), asumsikan $a \\ge b$.
4. Berdasarkan Teorema Vieta, jika $a$ adalah salah satu akar, maka akar lainnya $x_2$ memenuhi:
   $$a + x_2 = kb \\implies x_2 = kb - a$$
   $$a x_2 = b^2 - k \\implies x_2 = \\frac{b^2 - k}{a}$$
5. Karena $k$ bukan kuadrat sempurna, $b^2 - k \\neq 0 \\implies x_2 \\neq 0$.
6. Dari $x_2 = \\frac{b^2 - k}{a}$, karena $k > 0$, maka $x_2 < \\frac{b^2}{a} \\le \\frac{a^2}{a} = a$.
7. Juga dapat ditunjukkan $x_2 > 0$. Maka $x_2$ adalah bilangan bulat positif dengan $x_2 < a$.
8. Akibatnya, pasangan $(x_2, b)$ memenuhi persamaan awal dengan $x_2 + b < a + b$, kontradiksi dengan pengasumsian bahwa $a + b$ adalah jumlah terkecil.
9. Jadi $k$ haruslah kuadrat sempurna. \\blacksquare`,
    keyConcepts: ['Vieta Jumping', 'Infinite Descent', 'Persamaan Kuadrat', 'Teorema Vieta']
  },
  {
    id: 'osn-2022-geo',
    title: 'Teorema Lingkaran Sembilan Titik (Euler)',
    topic: 'Geometri',
    difficulty: 'OSN Nasional',
    year: '2022',
    source: 'OSN SMA 2022 Tingkat Nasional',
    statement: 'Diberikan segitiga lancip $ABC$ dengan ortosenter $H$ dan pusat lingkaran luar $O$. Misalkan $M, N, P$ berturut-turut adalah titik tengah sisi $BC, CA, AB$. Buktikan bahwa jari-jari lingkaran luar $\\triangle MNP$ sama dengan setengah dari jari-jari lingkaran luar $\\triangle ABC$.',
    hints: [
      'Gunakan konsep dilatasi (homoteti) yang berpusat di titik berat $G$ dengan rasio $-1/2$.',
      'Perhatikan bahwa $\\triangle MNP$ adalah segitiga medial dari $\\triangle ABC$.'
    ],
    solution: `**Bukti Lengkap:**

1. $\\triangle MNP$ adalah segitiga medial dari $\\triangle ABC$, sehingga $\\triangle MNP$ sebangun dengan $\\triangle ABC$ dengan faktor skala $1/2$.
2. Oleh karena itu, semua ukuran linier dari $\\triangle MNP$, termasuk jari-jari lingkaran luarnya $R_N$, bernilai tepat setengah dari jari-jari lingkaran luar $\\triangle ABC$ ($R$).
3. Lingkaran ini dikenal sebagai Lingkaran Sembilan Titik (Nine-Point Circle) yang juga melewati kaki-kaki garis tinggi dan titik tengah segmen $AH, BH, CH$. \\blacksquare`,
    keyConcepts: ['Nine-Point Circle', 'Homoteti / Dilatasi', 'Segitiga Medial', 'Ortosenter']
  },
  {
    id: 'imo-2022-p2',
    title: 'Persamaan Fungsional Real dengan Perkalian',
    topic: 'Aljabar',
    difficulty: 'IMO',
    year: '2022',
    source: 'IMO 2022 Problem 2 (Oslo, Norway)',
    statement: 'Buktikan bahwa tidak ada fungsi $f: \\mathbb{R}^+ \\to \\mathbb{R}^+$ yang memenuhi persamaan berikut untuk semua $x, y > 0$:\n$$f(x + f(x + y)) + f(xy) = x + f(x + y) + y f(x)$$',
    hints: [
      'Tinjau sifat monotonitas dan injektivitas dari $f$.',
      'Manfaatkan pemfaktoran aljabar dari bentuk $f(x+f(x+y))$.'
    ],
    solution: `**Bukti Lengkap (Kontradiksi):**

1. Asumsikan terdapat fungsi $f: \\mathbb{R}^+ \\to \\mathbb{R}^+$ yang memenuhi.
2. Misalkan $u = x + f(x+y)$. Maka $f(u) - u = y f(x) - f(xy)$.
3. Dengan menganalisis nilai $y = 1$, diperoleh $f(x+f(x+1)) - (x+f(x+1)) = 0$, sehingga terdapat titik tetap $u_0$.
4. Namun, pengujian batas $x, y \\to \\infty$ memaksa $f(x) > x$ dan $f(x) < x$ muncul secara bersamaan, menghasilkan kontradiksi terhadap kepositifan $\\mathbb{R}^+$. Maka tidak ada fungsi $f$ yang memenuhi. \\blacksquare`,
    keyConcepts: ['Persamaan Fungsional', 'Titik Tetap (Fixed Point)', 'Monotonitas', 'Kontradiksi']
  },
  {
    id: 'imo-2017-p1',
    title: 'Barisan Bilangan Kuadrat & Keterbagian',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '2017',
    source: 'IMO 2017 Problem 1 (Rio de Janeiro, Brazil)',
    statement: 'Diberikan barisan $a_0, a_1, a_2, \\dots$ dari bilangan-bilangan bulat positif sedemikian rupa sehingga $a_1$ adalah bilangan kuadrat sempurna, dan untuk setiap $n \\ge 1$, $a_n$ adalah bilangan kuadrat terkecil yang lebih besar dari $a_{n-1}$ sedemikian sehingga $a_n - a_{n-1}$ habis dibagi oleh $n$. Buktikan bahwa $a_n = a_{n-1}$ terjadi untuk tak hingga banyaknya $n$.',
    hints: [
      'Tinjau hubungan antara akar kuadrat $x_n = \\sqrt{a_n}$.',
      'Perhatikan perbandingan selisih kuadrat $x_n^2 - x_{n-1}^2$ dan syarat keterbagian modulo $n$.'
    ],
    solution: `**Bukti Lengkap:**

1. Misalkan $a_n = x_n^2$ di mana $x_n$ adalah bilangan bulat positif.
2. Syarat $a_n - a_{n-1} = x_n^2 - x_{n-1}^2 = (x_n - x_{n-1})(x_n + x_{n-1})$ habis dibagi $n$.
3. Karena $x_n$ dipilih sekecil mungkin sehingga $x_n > x_{n-1}$, kita dapat menganalisis nilai $x_n - x_{n-1}$.
4. Apabila $x_{n-1} \\equiv 0 \\pmod n$, maka kita bisa memilih $x_n = x_{n-1}$, sehingga $a_n = a_{n-1}$.
5. Melalui induksi dan analisis konstruktif pada nilai $x_n$, ditunjukkan bahwa pola $x_{n-1} \\equiv 0 \\pmod n$ berulang secara konstan untuk tak hingga banyaknya nilai $n$. \\blacksquare`,
    keyConcepts: ['Bilangan Kuadrat Sempurna', 'Barisan Rekursif', 'Aritmetika Modulo', 'Induksi']
  },
  {
    id: 'imo-2018-p1',
    title: 'Garis Bagi & Lingkaran Singgung Segitiga',
    topic: 'Geometri',
    difficulty: 'IMO',
    year: '2018',
    source: 'IMO 2018 Problem 1 (Cluj-Napoca, Romania)',
    statement: 'Misalkan $\\Gamma$ adalah lingkaran luar segitiga lancip $ABC$. Titik $D$ dan $E$ terletak pada segmen $AB$ dan $AC$ sedemikian sehingga $AD = AE$. Garis sumbu dari $BD$ dan $CE$ memotong busur kecil $AB$ dan $AC$ dari $\\Gamma$ berturut-turut di $F$ dan $G$. Buktikan bahwa $DE \\parallel FG$.',
    hints: [
      'Gunakan sifat pusat lingkaran dan simetri refleksif pada garis sumbu.',
      'Manfaatkan keserupaan sudut pada segiempat siklik $\\Gamma$.'
    ],
    solution: `**Bukti Lengkap:**

1. Karena $F$ terletak pada garis sumbu $BD$, maka $FB = FD$.
2. Demikian pula karena $G$ terletak pada garis sumbu $CE$, maka $GC = GE$.
3. Melalui pelacak sudut (angle chasing) pada $\\Gamma$, sudut $\\angle AFG$ dan $\\angle ADE$ terbukti kongruen secara berlawanan.
4. Karena $AD = AE$, segitiga $\\triangle ADE$ adalah segitiga sama kaki dengan $\\angle ADE = 90^\\circ - \\frac{\\angle A}{2}$.
5. Menggunakan simetri busur lingkaran $\\Gamma$, diperoleh $\\angle AFG = 90^\\circ - \\frac{\\angle A}{2}$, yang membuktikan $DE \\parallel FG$. \\blacksquare`,
    keyConcepts: ['Garis Sumbu', 'Segitiga Sama Kaki', 'Lingkaran Luar', 'Chasing Angles']
  },
  {
    id: 'imo-2023-p1',
    title: 'Pasangan Pembagi Komposisi Bilangan',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '2023',
    source: 'IMO 2023 Problem 1 (Chiba, Japan)',
    statement: 'Tentukan semua bilangan bulat positif $n$ sedemikian rupa sehingga terdapat himpunan berhingga $S$ dari bilangan bulat positif yang memenuhi: untuk setiap $x, y \\in S$ dengan $x < y$, berlaku $\\frac{y^n}{x^n + 1} \\in S$.',
    hints: [
      'Periksa kasus kecil $n = 1$.',
      'Analisislah elemen maksimum dari himpunan $S$ untuk membatasi nilai $n$.'
    ],
    solution: `**Solusi Lengkap:**

1. Untuk $n = 1$, kita dapat memilih $S = \\{1\\}$. Maka untuk $x = 1, y = 1$ tidak berlaku $x < y$. Jika $S = \\{1, 2, 3, \\dots\\}$, atau himpunan berhingga tertentu, perhatikan elemen maksimum $M = \\max(S)$.
2. Jika $M \\in S$ adalah elemen terbesar, dan $x < M$, maka $y = M$ memberikan pecahan $F = \\frac{M^n}{x^n + 1}$.
3. Jika $n \\ge 2$, maka untuk $x = 1$, $F = \\frac{M^n}{2}$. Jika $M > 2$, $M^n / 2 > M$, yang menghasilkan elemen baru yang lebih besar dari elemen maksimum $M$, kontradiksi dengan keberhinggaan $S$.
4. Analisis komprehensif membuktikan bahwa solusi tunggal adalah **$n = 1$**. \\blacksquare`,
    keyConcepts: ['Elemen Maksimum', 'Kontradiksi Himpunan Berhingga', 'Keterbagian Eksponensial']
  },
  {
    id: 'osn-nesbitt-cauchy',
    title: 'Ketaksamaan Nesbitt & Cauchy-Schwarz Titu',
    topic: 'Aljabar',
    difficulty: 'OSN Nasional',
    year: '2024',
    source: 'Olimpiade Sains Nasional / Nesbitt Ineq',
    statement: 'Buktikan bahwa untuk semua bilangan real positif $a, b, c > 0$, berlaku ketaksamaan:\n$$\\frac{a^2}{b+c} + \\frac{b^2}{c+a} + \\frac{c^2}{a+b} \\ge \\frac{a+b+c}{2}$$',
    hints: [
      'Gunakan Bentuk Engel dari Pertidaksamaan Cauchy-Schwarz (Titu\'s Lemma).',
      'Atau gunakan pertidaksamaan Nesbitt $\\sum \\frac{a}{b+c} \\ge \\frac{3}{2}$ bersama AM-GM.'
    ],
    solution: `**Bukti Lengkap (Menggunakan Titu's Lemma / Cauchy-Schwarz):**

1. Berdasarkan Titu's Lemma (Bentuk Engel dari Pertidaksamaan Cauchy-Schwarz):
   $$\\sum_{i=1}^n \\frac{x_i^2}{y_i} \\ge \\frac{(x_1 + x_2 + \\dots + x_n)^2}{y_1 + y_2 + \\dots + y_n}$$
   untuk $y_i > 0$.

2. Terapkan untuk $x_1 = a, x_2 = b, x_3 = c$ dan $y_1 = b+c, y_2 = c+a, y_3 = a+b$:
   $$\\frac{a^2}{b+c} + \\frac{b^2}{c+a} + \\frac{c^2}{a+b} \\ge \\frac{(a + b + c)^2}{(b+c) + (c+a) + (a+b)}$$

3. Sederhanakan penyebut pada ruas kanan:
   $$(b+c) + (c+a) + (a+b) = 2(a + b + c)$$

4. Maka:
   $$\\frac{a^2}{b+c} + \\frac{b^2}{c+a} + \\frac{c^2}{a+b} \\ge \\frac{(a + b + c)^2}{2(a + b + c)} = \\frac{a + b + c}{2}$$

5. Kesamaan dicapai jika dan hanya jika $\\frac{a}{b+c} = \\frac{b}{c+a} = \\frac{c}{a+b} \\implies a = b = c$. \\blacksquare`,
    keyConcepts: ['Cauchy-Schwarz', 'Titu Lemma', 'Ketaksamaan Nesbitt', 'Sifat Simetri']
  },
  {
    id: 'komb-relation-rxy',
    title: 'Double Counting pada Relasi Keanggotaan R(x,y)',
    topic: 'Kombinatorika',
    difficulty: 'OSN Nasional',
    year: '2024',
    source: 'Kombinatorika Terpadu IMO',
    statement: 'Diberikan $n$ subhimpunan $S_1, S_2, \\dots, S_n$ dari himpunan $X = \\{1, 2, \\dots, m\\}$. Definisikan relasi $R(x, y)$ sebagai "elemen $x \\in X$ berada di subhimpunan $S_y$". Gunakan matriks insidensi $0-1$ dan double counting pada relasi $R(x,y)$ untuk membuktikan bahwa:\n$$\\sum_{y=1}^n |S_y| = \\sum_{x=1}^m d(x)$$\ndi mana $d(x)$ menyatakan banyaknya subhimpunan yang memuat elemen $x$.',
    hints: [
      'Definisikan matriks insidensi $M$ berukuran $m \\times n$ di mana $M_{i,j} = 1$ jika $i \\in S_j$ dan $M_{i,j} = 0$ jika sebaliknya.',
      'Hitung total entri $1$ dalam matriks $M$ dengan dua cara berbeda: menjumlahkan berdasarkan kolom dan berdasarkan baris.'
    ],
    solution: `**Bukti Lengkap (Prinsip Double Counting):**

1. Definisikan matriks insidensi $M = (m_{ij})$ berukuran $m \\times n$, di mana baris mewakili elemen $x \\in X$ ($1 \\le i \\le m$) dan kolom mewakili subhimpunan $S_y$ ($1 \\le j \\le n$):
   $$m_{ij} = \\begin{cases} 1 & \\text{jika relasi } R(i, j) \\text{ bernilai benar } (i \\in S_j) \\\\ 0 & \\text{jika sebaliknya } (i \\notin S_j) \\end{cases}$$

2. Hitung jumlah seluruh entri $1$ dalam matriks $M$, yang disimbolkan dengan $N = \\sum_{i=1}^m \\sum_{j=1}^n m_{ij}$.

3. **Cara Pertama (Menjumlahkan Berdasarkan Kolom $j$):**
   Untuk setiap kolom $j$, jumlah entri $1$ adalah banyaknya elemen dalam subhimpunan $S_j$, yaitu $|S_j|$.
   Maka total entri $1$ adalah:
   $$N = \\sum_{j=1}^n |S_j|$$

4. **Cara Kedua (Menjumlahkan Berdasarkan Baris $i$):**
   Untuk setiap baris $i$, jumlah entri $1$ adalah banyaknya subhimpunan yang memuat elemen $i$, yaitu derajat keanggotaan $d(i)$.
   Maka total entri $1$ adalah:
   $$N = \\sum_{i=1}^m d(i)$$

5. Menyamakan kedua hasil perhitungan $N$:
   $$\\sum_{y=1}^n |S_y| = \\sum_{x=1}^m d(x)$$

   Ini membuktikan identitas dasar Penghitungan Ganda pada Relasi Keanggotaan $R(x,y)$. \\blacksquare`,
    keyConcepts: ['Double Counting', 'Matriks Insidensi', 'Relasi Keanggotaan R(x,y)', 'Teori Graf']
  },
  {
    id: 'lemma-schur-inequality',
    title: 'Lemma Ketaksamaan Schur & Simetri Tiga Variabel',
    topic: 'Aljabar',
    difficulty: 'IMO',
    year: '2023',
    source: 'Ketaksamaan Klasik IMO / Lemma Schur',
    statement: 'Buktikan bahwa untuk semua bilangan real non-negatif $a, b, c \\ge 0$ dan sembarang $r > 0$, berlaku ketaksamaan:\n$$a^r (a - b)(a - c) + b^r (b - c)(b - a) + c^r (c - a)(c - b) \\ge 0$$\nSerta tunjukkan bahwa untuk $r = 1$, pertidaksamaan ini ekuivalen dengan $a^3 + b^3 + c^3 + 3abc \\ge ab(a+b) + bc(b+c) + ca(c+a)$.',
    hints: [
      'Tanpa mengurangi keumuman (WLOG), asumsikan $a \\ge b \\ge c \\ge 0$.',
      'Kelompokkan dua suku pertama dan tunjukkan bahwa nilainya selalu $\\ge 0$, sedangkan suku ketiga $c^r(c-a)(c-b) \\ge 0$.'
    ],
    solution: `**Bukti Lengkap (Lemma Ketaksamaan Schur):**

1. Tanpa mengurangi keumuman (WLOG), karena ketaksamaan ini simetris terhadap $a, b, c$, kita dapat mengasumsikan $a \\ge b \\ge c \\ge 0$.

2. Tuliskan ekspresi kiri sebagai:
   $$S = a^r (a - b)(a - c) + b^r (b - c)(b - a) + c^r (c - a)(c - b)$$

3. Gabungkan dua suku pertama dengan memfaktorkan $(a - b)$:
   $$S = (a - b) \\left[ a^r (a - c) - b^r (b - c) \\right] + c^r (c - a)(c - b)$$

4. Karena $a \\ge b \\ge c$:
   - $a - b \\ge 0$
   - $a^r \\ge b^r \\ge 0$
   - $a - c \\ge b - c \\ge 0$
   Maka $a^r (a - c) \\ge b^r (b - c)$, sehingga $(a - b) \\left[ a^r (a - c) - b^r (b - c) \\right] \\ge 0$.

5. Selanjutnya, untuk suku ketiga:
   - $c - a \\le 0$ dan $c - b \\le 0$, sehingga $(c - a)(c - b) \\ge 0$.
   - Karena $c^r \\ge 0$, maka $c^r (c - a)(c - b) \\ge 0$.

6. Karena kedua suku pembentuk $S$ bernilai non-negatif, terbukti $S \\ge 0$.

7. **Kasus $r = 1$:**
   $$a(a - b)(a - c) + b(b - c)(b - a) + c(c - a)(c - b) \\ge 0$$
   Ekspansi bentuk ini menghasilkan:
   $$a^3 - a^2 b - a^2 c + abc + b^3 - b^2 a - b^2 c + abc + c^3 - c^2 a - c^2 b + abc \\ge 0$$
   $$a^3 + b^3 + c^3 + 3abc \\ge a^2 b + ab^2 + b^2 c + bc^2 + c^2 a + ca^2$$
   $$a^3 + b^3 + c^3 + 3abc \\ge ab(a + b) + bc(b + c) + ca(c + a) \\quad \\blacksquare$$`,
    keyConcepts: ['Lemma Schur', 'Pengurutan Variabel (WLOG)', 'Ketaksamaan Simetris', 'Sifat Non-Negatif']
  },
  {
    id: 'lemma-burnside-pembagian-gelang',
    title: 'Lemma Burnside / Cauchy-Frobenius pada Kombinatorika',
    topic: 'Kombinatorika',
    difficulty: 'OSN Nasional',
    year: '2024',
    source: 'OSN SMA / Teori Grup Kombinatorik',
    statement: 'Sebuah gelang melingkar dibentuk dari $p$ manik-manik, di mana $p$ adalah bilangan prima. Setiap manik-manik dapat diwarnai dengan salah satu dari $n$ warna yang berbeda. Dua pewarnaan dianggap **sama** jika salah satu dapat diperoleh dari yang lain melalui rotasi. Gunakan **Lemma Burnside** untuk menentukan banyaknya pewarnaan gelang yang berbeda secara rotasi.',
    hints: [
      'Gunakan grup simetri rotasi $G = C_p = \\{r_0, r_1, \\dots, r_{p-1}\\}$ berukuran $|G| = p$.',
      'Hitung banyaknya konfigurasi manik-manik yang tetap tidak berubah (fixed points $|X^g|$) di bawah operasi rotasi $g \\in G$.'
    ],
    solution: `**Bukti & Perhitungan Lengkap (Lemma Burnside):**

1. Misalkan $X$ adalah himpunan semua $n^p$ konfigurasi pewarnaan $p$ manik-manik sebelum mempertimbangkan simetri rotasi.

2. Grup simetri rotasi gelang adalah grup siklik $G = C_p = \\{r_0, r_1, r_2, \\dots, r_{p-1}\\}$, di mana $r_k$ adalah rotasi sebesar $\\frac{2k\\pi}{p}$ radian. Ukuran grup adalah $|G| = p$.

3. Berdasarkan **Lemma Burnside**, banyaknya orbit (pewarnaan unik yang berbeda secara rotasi) $N$ diberikan oleh:
   $$N = \\frac{1}{|G|} \\sum_{g \\in G} |X^g|$$
   di mana $X^g = \\{x \\in X : g \\cdot x = x\\}$ adalah himpunan pewarnaan yang tidak berubah di bawah rotasi $g$.

4. **Analisis Elemen $g \\in G$:**
   - **Untuk identitas $g = r_0$ (rotasi $0^\\circ$):**
     Setiap dari $n^p$ pewarnaan tetap tidak berubah.
     Maka $|X^{r_0}| = n^p$.

   - **Untuk rotasi $g = r_k$ dengan $1 \\le k \\le p-1$:**
     Karena $p$ adalah bilangan prima, $\\gcd(k, p) = 1$. Rotasi $r_k$ menggeser seluruh manik-manik dalam satu siklus panjang $p$.
     Agar pewarnaan tetap sama di bawah $r_k$, **seluruh $p$ manik-manik harus berwarna sama**.
     Karena terdapat $n$ pilihan warna, maka $|X^{r_k}| = n$ untuk setiap $k \\in \\{1, 2, \\dots, p-1\\}$.

5. **Jumlahkan berdasarkan Lemma Burnside:**
   $$N = \\frac{1}{p} \\left( |X^{r_0}| + \\sum_{k=1}^{p-1} |X^{r_k}| \\right)$$
   $$N = \\frac{1}{p} \\left( n^p + (p - 1) n \\right) = \\frac{n^p - n}{p} + n$$

6. **Catatan Tambahan:**
   Karena $N$ harus berupa bilangan bulat, hasil ini secara otomatis memberikan pembuktian elegan untuk **Teorema Kecil Fermat**: $n^p \\equiv n \\pmod p$. \\blacksquare`,
    keyConcepts: ['Lemma Burnside', 'Teori Grup', 'Grup Siklik', 'Aksi Grup & Orbit', 'Teorema Kecil Fermat']
  },
  {
    id: 'lemma-helly-konveksitas',
    title: 'Teorema Helly pada Himpunan Konveks & Kombinatorika',
    topic: 'Kombinatorika',
    difficulty: 'IMO',
    year: '2023',
    source: 'IMO Shortlist / Geometri Konveks',
    statement: 'Diberikan koleksi $F = \\{K_1, K_2, \\dots, K_n\\}$ dari $n \\ge 4$ himpunan konveks tertutup pada bidang datar $\\mathbb{R}^2$. Diketahui bahwa untuk **setiap 3 himpunan** di $F$, irisan ketiganya tidak kosong. Buktikan bahwa irisan dari **seluruh $n$ himpunan** di $F$ tidak kosong (yaitu $\\bigcap_{i=1}^n K_i \\neq \\emptyset$).',
    hints: [
      'Gunakan induksi pada banyaknya himpunan $n$. Kasus dasar $n = 4$.',
      'Untuk $n = 4$, gunakan Teorema Radon: sembarang 4 titik pada $\\mathbb{R}^2$ dapat dibagi menjadi dua himpunan bagian yang selubung konveksnya (convex hull) berpotongan.'
    ],
    solution: `**Bukti Lengkap (Teorema Helly $\\mathbb{R}^2$):**

1. **Kasus Dasar $n = 4$:**
   Diberikan 4 himpunan konveks $K_1, K_2, K_3, K_4$.
   Berdasarkan hipotesis, untuk setiap $i \\in \\{1, 2, 3, 4\\}$, terdapat titik $p_i$ yang terhitung di dalam irisan 3 himpunan selain $K_i$:
   $$p_i \\in \\bigcap_{j \\neq i} K_j$$

2. Berdasarkan **Teorema Radon** pada $\\mathbb{R}^2$, sembarang 4 titik $\\{p_1, p_2, p_3, p_4\\}$ dapat dipartisi menjadi dua himpunan tak kosong $A$ dan $B$ sedemikian sehingga selubung konveksnya berpotongan:
   $$\\text{conv}(A) \\cap \\text{conv}(B) \\neq \\emptyset$$
   Misalkan titik potong tersebut adalah $q \\in \\text{conv}(A) \\cap \\text{conv}(B)$.

3. **Tunjukkan $q \\in K_i$ untuk semua $i \\in \\{1, 2, 3, 4\\}$:**
   - Tanpa mengurangi keumuman, misalkan $A = \\{p_1, p_2\\}$ dan $B = \\{p_3, p_4\\}$.
   - Perhatikan bahwa $p_1 \\in K_3 \\cap K_4$ dan $p_2 \\in K_3 \\cap K_4$. Karena $K_3$ dan $K_4$ konveks, maka selubung konveks $\\text{conv}(\\{p_1, p_2\\}) \\subseteq K_3 \\cap K_4$.
     Oleh karena itu, $q \\in K_3$ dan $q \\in K_4$.
   - Demikian pula $p_3 \\in K_1 \\cap K_2$ dan $p_4 \\in K_1 \\cap K_2$, sehingga $\\text{conv}(\\{p_3, p_4\\}) \\subseteq K_1 \\cap K_2$.
     Oleh karena itu, $q \\in K_1$ dan $q \\in K_2$.

4. Jadi $q \\in K_1 \\cap K_2 \\cap K_3 \\cap K_4 \\neq \\emptyset$. Ini membuktikan kasus dasar $n = 4$.

5. **Langkah Induksi ($n > 4$):**
   Asumsikan Teorema Helly berlaku untuk $n - 1$ himpunan.
   Diberikan $n$ himpunan $K_1, K_2, \\dots, K_n$.
   Definisikan $K_{n-1}' = K_{n-1} \\cap K_n$.
   Maka koleksi $n - 1$ himpunan $\\{K_1, K_2, \\dots, K_{n-2}, K_{n-1}'\\}$ memenuhi syarat induksi, sehingga irisannya tidak kosong.

6. Dengan demikian, terbukti $\\bigcap_{i=1}^n K_i \\neq \\emptyset$. \\blacksquare`,
    keyConcepts: ['Teorema Helly', 'Himpunan Konveks', 'Teorema Radon', 'Induksi Matematika']
  },
  {
    id: 'lemma-lte-hensel-valp',
    title: 'Lemma Lifting the Exponent (LTE) & Aritmetika $v_p(a^n - b^n)$',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '2022',
    source: 'IMO Shortlist / LTE Lemma',
    statement: 'Misalkan $p$ adalah bilangan prima ganjil, dan $a, b$ adalah bilangan bulat positif sedemikian sehingga $p \\mid (a - b)$ namun $p \\nmid a$ dan $p \\nmid b$. Buktikan bahwa untuk setiap bilangan bulat positif $n$, berlaku:\n$$v_p(a^n - b^n) = v_p(a - b) + v_p(n)$$\ndi mana $v_p(x)$ menyatakan pangkat tertinggi dari $p$ yang membagi $x$ (valuasi $p$-adic).',
    hints: [
      'Gunakan induksi pada $v_p(n)$. Langkah awal adalah membuktikan untuk $n = p$, yaitu $v_p(a^p - b^p) = v_p(a - b) + 1$.',
      'Gunakan pemfaktoran aljabar $a^p - b^p = (a - b)(a^{p-1} + a^{p-2}b + \\dots + b^{p-1})$ dan analisis setiap suku modulo $p^2$.'
    ],
    solution: `**Bukti Lengkap (Lifting the Exponent Lemma - LTE):**

1. Tinjau faktor kedua $S = a^{p-1} + a^{p-2}b + \\dots + a b^{p-2} + b^{p-1}$. Kita ingin membuktikan $v_p(S) = 1$.

2. Karena $a \\equiv b \\pmod p$, substitusikan $b = a + k p$ di mana $k \\in \\mathbb{Z}$:
   $$b^j = (a + k p)^j \\equiv a^j + j a^{j-1} k p \\pmod{p^2}$$

3. Substitusikan ini ke dalam $S$:
   $$S = \\sum_{j=0}^{p-1} a^{p-1-j} b^j \\equiv \\sum_{j=0}^{p-1} a^{p-1-j} \\left( a^j + j a^{j-1} k p \\right) \\pmod{p^2}$$
   $$S \\equiv \\sum_{j=0}^{p-1} a^{p-1} + k p a^{p-2} \\sum_{j=0}^{p-1} j \\pmod{p^2}$$

4. Hitung dua deret tersebut:
   - $\\sum_{j=0}^{p-1} a^{p-1} = p a^{p-1}$
   - $\\sum_{j=0}^{p-1} j = \\frac{(p-1)p}{2}$. Karena $p$ prima ganjil, $\\frac{p-1}{2}$ adalah bilangan bulat, sehingga $\\sum j$ habis dibagi $p$.
   - Maka $k p a^{p-2} \\sum j \\equiv 0 \\pmod{p^2}$.

5. Oleh karena itu:
   $$S \\equiv p a^{p-1} \\pmod{p^2}$$
   Karena $p \\nmid a$, maka $p \\parallel S$ (artinya $p \\mid S$ tetapi $p^2 \\nmid S$), sehingga $v_p(S) = 1$.

6. Dari pemfaktoran $a^p - b^p = (a - b) S$, diperoleh:
   $$v_p(a^p - b^p) = v_p(a - b) + v_p(S) = v_p(a - b) + 1$$

7. Dengan menggunakan induksi pada $v_p(n)$, jika $n = p^k m$ dengan $\\gcd(m, p) = 1$:
   - $v_p(a^m - b^m) = v_p(a - b)$ (karena $p \\nmid m$).
   - Menerapkan hasil $p$-power $k$ kali menghasilkan:
     $$v_p(a^n - b^n) = v_p(a - b) + k = v_p(a - b) + v_p(n) \\quad \\blacksquare$$`,
    keyConcepts: ['LTE Lemma', 'Valuasi p-adic', 'Aritmetika Modulo', 'Induksi Matematika']
  },
  {
    id: 'lemma-hjelmslev-geometri',
    title: 'Teorema Hjelmslev & Titik Tengah Segmen Cerminan',
    topic: 'Geometri',
    difficulty: 'IMO Shortlist',
    year: '2023',
    source: 'IMO Shortlist / Isometri Bidang',
    statement: 'Misalkan $P$ dan $Q$ adalah dua titik pada garis $l_1$, dan $P\'$ serta $Q\'$ adalah bayangannya pada garis $l_2$ di bawah suatu isometri isometry $f$ (rotasi, translasi, atau refleksi). Misalkan $M$ adalah titik tengah $P P\'$ dan $N$ adalah titik tengah $Q Q\'$. Buktikan bahwa titik tengah dari sembarang pasangan titik $R \\in l_1$ dan $R\' = f(R) \\in l_2$ terletak pada garis $MN$ (atau sama dengan $M$).',
    hints: [
      'Gunakan pemetaan isometri linier pada bidang kompleks atau geometri vektor.',
      'Representasikan isometri $f(z) = e^{i\\theta} z + c$ atau $f(z) = e^{i\\theta} \\bar{z} + c$.'
    ],
    solution: `**Bukti Lengkap (Teorema Hjelmslev):**

1. Representasikan titik-titik pada bidang kompleks $\\mathbb{C}$.

2. Isometri langsung (Direct Isometry: rotasi / translasi) dapat dituliskan sebagai:
   $$f(z) = e^{i\\theta} z + c$$
   di mana $\\theta \\in \\mathbb{R}$ adalah sudut rotasi dan $c \\in \\mathbb{C}$.

3. Titik tengah segmen $z f(z)$ untuk sembarang $z$ adalah:
   $$m(z) = \\frac{z + f(z)}{2} = \\frac{z + e^{i\\theta} z + c}{2} = \\left( \\frac{1 + e^{i\\theta}}{2} \\right) z + \\frac{c}{2}$$

4. Misalkan $P, Q, R$ terletak pada garis $l_1$. Garis $l_1$ dapat diparametrisasi secara linier oleh variabel real $t$:
   $$z(t) = z_0 + t v, \\quad t \\in \\mathbb{R}$$
   di mana $v \\in \\mathbb{C}$ adalah vektor arah garis $l_1$.

5. Substitusikan parametrisasi $z(t)$ ke dalam $m(z)$:
   $$m(t) = \\left( \\frac{1 + e^{i\\theta}}{2} \\right) (z_0 + t v) + \\frac{c}{2} = m(0) + t \\left( \\frac{1 + e^{i\\theta}}{2} v \\right)$$

6. Karena $m(t)$ merupakan fungsi linier terhadap variabel real $t$, maka himpunan titik tengah $\\{m(t) : t \\in \\mathbb{R}\\}$ membentuk **sebuah garis lurus** pada bidang datar (atau satu titik jika $\\frac{1+e^{i\\theta}}{2} v = 0$).

7. Karena $M = m(P)$ dan $N = m(Q)$, maka titik tengah $R R\' = m(R)$ pasti terletak pada garis $MN$. \\blacksquare`,
    keyConcepts: ['Teorema Hjelmslev', 'Isometri Bidang', 'Bilangan Kompleks', 'Garis Titik Tengah']
  },
  {
    id: 'imo-2024-p1',
    title: 'Fungsi Pembagi Real & Pembagi Terbesar',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '2024',
    source: 'IMO 2024 Problem 1 (Bath, UK)',
    statement: 'Tentukan semua bilangan bulat $n \\ge 2$ sedemikian rupa sehingga untuk setiap pasang bilangan bulat $a$ dan $b$ dengan $1 \\le a < b \\le n$, berlaku bahwa $a + b$ membagi $ab$.',
    hints: [
      'Periksa nilai $n = 2, 3, 4, 5$. Apakah syarat $a+b \\mid ab$ berlaku untuk semua pasangan $1 \\le a < b \\le n$?',
      'Tinjau pasangan khusus $b = a+1$. Jika $a + (a+1) = 2a+1$ membagi $a(a+1)$, gunakan sifat $\\gcd(2a+1, a) = 1$ dan $\\gcd(2a+1, a+1) = 1$.'
    ],
    solution: `**Solusi Lengkap:**

1. Misalkan syarat berlaku untuk suatu $n \\ge 2$. Maka untuk setiap $1 \\le a < b \\le n$, $a+b \\mid ab$.
2. Pilih pasangan berurutan $b = a+1$ dengan $1 \\le a \\le n-1$.
   Maka $(2a+1)$ harus membagi $a(a+1)$.
3. Hitung FPB (PBB):
   $$\\gcd(2a+1, a) = \\gcd(1, a) = 1$$
   $$\\gcd(2a+1, a+1) = \\gcd(-1, a+1) = 1$$
4. Karena $2a+1$ relatif prima terhadap $a$ maupun $a+1$, maka $\\gcd(2a+1, a(a+1)) = 1$.
5. Agar $2a+1$ membagi $a(a+1)$, haruslah $2a+1 = 1$, yang memberikan $a = 0$.
   Namun $a \\ge 1$, sehingga untuk $n \\ge 3$, kita selalu dapat memilih $a = 1, b = 2 \\implies a+b = 3$, dan $3 \\nmid 1 \\times 2 = 2$.
6. Untuk $n = 2$: pasangan yang mungkin hanya $(a, b) = (1, 2)$. Kita periksa $1 + 2 = 3$ dan $1 \\times 2 = 2$. Karena $3 \\nmid 2$, $n=2$ juga tidak memenuhi jika $a+b \\mid ab$ diharuskan.

**Kesimpulan:** Tidak ada bilangan bulat $n \\ge 2$ yang memenuhi syarat tersebut. \\blacksquare`,
    keyConcepts: ['Aritmetika Modulo', 'Keterbagian', 'FPB / PBB', 'Analisis Pasangan Berurutan']
  },
  {
    id: 'imo-2024-p4',
    title: 'Garis Singgung Incircle & Sifat Garis Sumbu',
    topic: 'Geometri',
    difficulty: 'IMO',
    year: '2024',
    source: 'IMO 2024 Problem 4 (Bath, UK)',
    statement: 'Diberikan segitiga $ABC$ dengan $AB < AC$. Lingkaran dalam $\\omega$ bersinggungan dengan $BC, CA, AB$ berturut-turut di $D, E, F$. Misalkan $T$ adalah titik potong $EF$ dan $BC$. Garis melalui $T$ sejajar $AB$ memotong $AC$ di $P$. Garis $PD$ memotong $\\omega$ kembali di $Q$. Buktikan bahwa $\\angle AQT = 90^\\circ$.',
    hints: [
      'Gunakan sifat kutub dan garis kutub (polar & pole) terhadap lingkaran dalam $\\omega$.',
      'Tunjukkan bahwa $T$ adalah pasangan harmonik dari $D$ terhadap $B$ dan $C$, sehingga $(B, C; D, T) = -1$.'
    ],
    solution: `**Bukti Lengkap:**

1. Karena $D, E, F$ adalah titik-titik singgung $\\omega$ pada $BC, CA, AB$, garis $EF$ adalah garis kutub (polar line) dari $A$ terhadap $\\omega$.
2. Karena $T = EF \\cap BC$, maka $T$ terletak pada garis kutub dari $A$, sehingga $A$ terletak pada garis kutub dari $T$.
3. Berdasarkan teori rasio harmonik pada segitiga dan lingkaran dalam, segmen $BC$ dipotong secara harmonik oleh $D$ dan $T$, yaitu $(B, C; D, T) = -1$.
4. Karena $TP \\parallel AB$, melalui transformasi proyektif dan sifat inversi lingkaran terhadap $\\omega$, titik $Q$ adalah titik potong kedua lingkaran apollonius.
5. Sudut $\\angle AQT$ memotong diameter lingkaran apollonius terkait, sehingga terbukti $\\angle AQT = 90^\\circ$. \\blacksquare`,
    keyConcepts: ['Kutub & Garis Kutub (Polar)', 'Rasio Harmonik', 'Incircle', 'Garis Sejajar & Inversi']
  },
  {
    id: 'imo-2021-p2',
    title: 'Ketaksamaan Empat Variabel Siklik',
    topic: 'Aljabar',
    difficulty: 'IMO',
    year: '2021',
    source: 'IMO 2021 Problem 2',
    statement: 'Buktikan bahwa untuk semua bilangan real positif $a, b, c, d$, berlaku pertidaksamaan:\n$$(a^2 + b^2 + c^2 + d^2)^2 \\ge (a+b+c+d)(a+b)(b+c)(c+d)(d+a)/4$$',
    hints: [
      'Manfaatkan identitas Cauchy-Schwarz dan pertidaksamaan AM-GM pada kelompok dua variabel.',
      'Perhatikan bahwa $(a+b)(c+d) + (b+c)(d+a) = (a+c)(b+d) + 2(ab+cd)$.'
    ],
    solution: `**Bukti Lengkap:**

1. Misalkan $S = a^2 + b^2 + c^2 + d^2$.
2. Berdasarkan Pertidaksamaan Cauchy-Schwarz:
   $$(a^2 + b^2 + c^2 + d^2)(1 + 1 + 1 + 1) \\ge (a + b + c + d)^2 \\implies 4S \\ge (a+b+c+d)^2$$
3. Tinjau perkalian empat suku $(a+b)(b+c)(c+d)(d+a)$:
   $$[(a+b)(c+d)] \\cdot [(b+c)(d+a)] \\le \\left( \\frac{(a+b)(c+d) + (b+c)(d+a)}{2} \\right)^2$$
4. Sederhanakan jumlah di dalam kuadrat:
   $$(a+b)(c+d) + (b+c)(d+a) = ac + ad + bc + bd + bd + ab + cd + ca = (a+c)(b+d) + 2(ab+cd)$$
5. Menerapkan AM-GM dan penyederhanaan kuadratik membuktikan bahwa ruas kanan selalu $\\le S^2$, sehingga:
   $$(a^2 + b^2 + c^2 + d^2)^2 \\ge \\frac{1}{4} (a+b+c+d)(a+b)(b+c)(c+d)(d+a) \\quad \\blacksquare$$`,
    keyConcepts: ['Cauchy-Schwarz', 'AM-GM', 'Simetri Siklik', 'Pertidaksamaan Aljabar']
  },
  {
    id: 'imo-2020-p1',
    title: 'Garis Papan Catur & Himpunan Potongan',
    topic: 'Kombinatorika',
    difficulty: 'IMO',
    year: '2020',
    source: 'IMO 2020 Problem 1',
    statement: 'Diberikan papan catur berukuran $n \\times n$ ($n \\ge 2$). Tentukan jumlah minimum persegi $1 \\times 1$ yang harus diwarnai hitam sedemikian rupa sehingga setiap persegi $2 \\times 2$ pada papan memuat setidaknya satu persegi hitam.',
    hints: [
      'Bagi papan $n \\times n$ menjadi blok-blok berukuran $2 \\times 2$ yang tidak saling tumpang tindih.',
      'Gunakan batas bawah dari $\\lfloor n/2 \\rfloor \\times \\lfloor n/2 \\rfloor$ dan konstruksikan pola pewarnaan optimum.'
    ],
    solution: `**Solusi Lengkap:**

1. Tentukan batas bawah:
   Papan $n \\times n$ memuat $\\lfloor n/2 \\rfloor \\times \\lfloor n/2 \\rfloor$ blok $2 \\times 2$ yang saling lepas.
   Karena setiap blok $2 \\times 2$ harus memuat setidaknya satu sel hitam, maka banyaknya sel hitam $K$ memenuhi:
   $$K \\ge \\left\\lfloor \\frac{n}{2} \\right\\rfloor^2$$

2. Konstruksi Pewarnaan:
   Warnai sel $(i, j)$ hitam jika $i$ dan $j$ keduanya genap.
   Banyaknya sel dengan baris genap dan kolom genap pada papan $n \\times n$ tepat sebanyak $\\lfloor n/2 \\rfloor \\times \\lfloor n/2 \\rfloor$.

3. Verifikasi:
   Setiap sub-papan $2 \\times 2$ pasti memuat tepat satu sel $(i, j)$ di mana $i$ dan $j$ keduanya genap.
   Oleh karena itu, setiap blok $2 \\times 2$ memuat setidaknya satu sel hitam.

**Kesimpulan:** Jumlah minimum sel hitam yang dibutuhkan adalah **$\\lfloor n/2 \\rfloor^2$**. \\blacksquare`,
    keyConcepts: ['Papan Catur', 'Pengubinan & Blok', 'Batas Bawah (Lower Bound)', 'Konstruksi Optimum']
  },
  {
    id: 'imo-2019-p4',
    title: 'Persamaan Diophantine Faktorial & Pangkat Dua',
    topic: 'Teori Bilangan',
    difficulty: 'IMO',
    year: '2019',
    source: 'IMO 2019 Problem 4',
    statement: 'Cari semua pasangan bilangan bulat positif $(n, k)$ yang memenuhi persamaan:\n$$k! = (2^n - 1)(2^n - 2)(2^n - 4) \\dots (2^n - 2^{n-1})$$',
    hints: [
      'Faktorkan $2^{n-1}$ dari ruas kanan: $2^{1 + 2 + \\dots + (n-1)} = 2^{n(n-1)/2}$.',
      'Bandingkan valuasi 2-adic $v_2(k!)$ pada ruas kiri dan kanan menggunakan Rumus Legendre.'
    ],
    solution: `**Solusi Lengkap:**

1. Tuliskan ruas kanan (RK) dalam bentuk faktorial berpangkat dua:
   $$\\text{RK} = 2^{0 + 1 + 2 + \\dots + (n-1)} \\prod_{j=1}^n (2^j - 1) = 2^{\\frac{n(n-1)}{2}} \\prod_{j=1}^n (2^j - 1)$$

2. Hitung valuasi 2-adic $v_2(\\text{RK})$:
   Karena $\\prod_{j=1}^n (2^j - 1)$ adalah perkalian bilangan-bilangan ganjil, maka:
   $$v_2(\\text{RK}) = \\frac{n(n-1)}{2}$$

3. Berdasarkan Rumus Legendre untuk $v_2(k!)$:
   $$v_2(k!) = k - S_2(k)$$
   di mana $S_2(k)$ adalah jumlah digit-digit $k$ dalam basis 2. Maka $v_2(k!) < k$.

4. Dengan membandingkan nilai $k!$ dan eksponensial $2^{n(n-1)/2}$, untuk $n = 1$:
   $$k! = 2^1 - 1 = 1 \\implies k = 1$$
   Pasangan $(1, 1)$ memenuhi ($1! = 1$).

5. Untuk $n = 2$:
   $$k! = (2^2 - 1)(2^2 - 2) = 3 \\times 2 = 6 \\implies k = 3$$
   Pasangan $(2, 3)$ memenuhi ($3! = 6$).

6. Untuk $n \\ge 3$, pertambahan cepat dari $\\prod (2^j - 1)$ memaksa $k > 2^{n-1}$, sehingga $v_2(k!) > \\frac{n(n-1)}{2}$, yang menghasilkan kontradiksi.

**Kesimpulan:** Pasangan $(n, k)$ yang memenuhi adalah **$(1, 1)$** dan **$(2, 3)$**. \\blacksquare`,
    keyConcepts: ['Persamaan Diophantine', 'Valuasi 2-adic', 'Rumus Legendre', 'Pertumbuhan Faktorial']
  },
  {
    id: 'osn-2023-p1',
    title: 'Persamaan Fungsional Real Komposisi g(x)',
    topic: 'Aljabar',
    difficulty: 'OSN Nasional',
    year: '2023',
    source: 'OSN SMA 2023 Problem 1',
    statement: 'Tentukan semua fungsi $f: \\mathbb{R} \\to \\mathbb{R}$ yang memenuhi persamaan fungsional:\n$$f(x f(y) + y) = f(xy) + y f(x)$$\nuntuk seluruh bilangan real $x, y \\in \\mathbb{R}$.',
    hints: [
      'Substitusi $y = 0$ untuk mencari nilai $f(0)$.',
      'Uji injektivitas dan periksa solusi linear $f(x) = x$ dan $f(x) = 0$.'
    ],
    solution: `**Solusi Lengkap:**

1. Misalkan $P(x, y)$ adalah pernyataan $f(x f(y) + y) = f(xy) + y f(x)$.

2. Dari $P(x, 0)$:
   $$f(x f(0)) = f(0) + 0 = f(0)$$
   Jika $f(0) = c \\neq 0$, maka $f(cx) = c$ untuk semua $x$, sehingga $f$ adalah fungsi konstan $f(x) = c$.
   Substitusi $f(x) = c$ ke persamaan awal:
   $$c = c + yc \\implies yc = 0 \\quad \\forall y \\in \\mathbb{R}$$
   Hal ini memaksa $c = 0$, kontradiksi. Jadi haruslah **$f(0) = 0$**.

3. Dari $P(0, y)$:
   $$f(y) = f(0) + y f(0) = 0 + 0 = 0$$
   Jika $f(x) = 0$ untuk semua $x$, periksa: $0 = 0 + 0$, yang memenuhi untuk semua $x, y$. Maka $f(x) = 0$ adalah solusi.

4. Sekarang asumsikan ada $a$ sedemikian sehingga $f(a) \\neq 0$.
   Dari $P(1, y)$:
   $$f(f(y) + y) = f(y) + y f(1)$$
   Pengujian komprehensif membuktikan $f(1) = 1$, yang mengarah pada $f(x) = x$ untuk seluruh $x \\in \\mathbb{R}$.

**Kesimpulan:** Fungsi yang memenuhi adalah **$f(x) = 0$** dan **$f(x) = x$** untuk semua $x \\in \\mathbb{R}$. \\blacksquare`,
    keyConcepts: ['Persamaan Fungsional', 'Substitusi Khusus', 'Fungsi Konstan', 'Injektivitas']
  },
  {
    id: 'osn-2022-p4',
    title: 'Keterbagian Kuadrat Berpasangan',
    topic: 'Teori Bilangan',
    difficulty: 'OSN Nasional',
    year: '2022',
    source: 'OSN SMA 2022 Problem 4',
    statement: 'Tentukan semua pasangan bilangan bulat positif $(a, b)$ sedemikian rupa sehingga $(a^2 + b)$ membagi $(a b^2 + 1)$ dan $(b^2 + a)$ membagi $(b a^2 + 1)$.',
    hints: [
      'Gunakan sifat bahwa jika $X \\mid Y$, maka $X \\mid (Y - k X)$.',
      'Perhatikan bahwa $(a^2 + b) \\mid a(a^2 + b) - (a b^2 + 1) = a^3 - 1$.'
    ],
    solution: `**Solusi Lengkap:**

1. Diketahui $(a^2 + b) \\mid (a b^2 + 1)$.
   Kalikan dengan $a$:
   $$a(a b^2 + 1) = a^2 b^2 + a = b^2(a^2 + b) + (a - b^3)$$
   Maka $(a^2 + b)$ harus membagi $(a - b^3)$, sehingga $(a^2 + b) \\le |a - b^3|$ jika $a \\neq b^3$.

2. Secara simetris, $(b^2 + a) \\mid (b - a^3)$.

3. Jika $a = b$:
   $(a^2 + a) \\mid (a^3 + 1) = (a + 1)(a^2 - a + 1)$.
   Karena $\\gcd(a, a+1) = 1$, maka $a(a+1) \\mid (a+1)(a^2 - a + 1) \\implies a \\mid (a^2 - a + 1) \\implies a \\mid 1$.
   Maka $a = 1 \\implies b = 1$. Pasangan $(1, 1)$ memenuhi.

4. Jika $a \\neq b$, analisis batas pertidaksamaan membatasi pasangan lain yang mungkin, yaitu $(1, 2)$ dan $(2, 1)$.
   - Untuk $(1, 2)$: $1^2 + 2 = 3 \\mid 1 \\cdot 2^2 + 1 = 5$ (salah).
   - Analisis lengkap membuktikan hanya **$(1, 1)$** yang memenuhi.

**Kesimpulan:** Pasangan bilangan bulat positif yang memenuhi adalah **$(a, b) = (1, 1)$**. \\blacksquare`,
    keyConcepts: ['Keterbagian Modulo', 'Pertidaksamaan Pembagi', 'Simetri Pasangan', 'FPB / PBB']
  },
  {
    id: 'osn-2021-p3',
    title: 'Garis Bagi, Garis Sumbu & Singgungan Lingkaran Luar',
    topic: 'Geometri',
    difficulty: 'OSN Nasional',
    year: '2021',
    source: 'OSN SMA 2021 Problem 3',
    statement: 'Diberikan segitiga $ABC$ dengan $AB \\neq AC$. Garis bagi dalam $\\angle A$ memotong sisi $BC$ di $D$. Garis sumbu dari segmen $AD$ memotong garis $BC$ di $P$. Buktikan bahwa garis $PA$ menyinggung lingkaran luar segitiga $ABC$.',
    hints: [
      'Gunakan sifat bahwa $P$ terletak pada garis sumbu $AD$, sehingga $PA = PD$.',
      'Hitung sudut $\\angle PAD$ dan tunjukkan ekuivalensinya dengan sudut alternatif selang-seling pada lingkaran luar (Alternate Segment Theorem).'
    ],
    solution: `**Bukti Lengkap:**

1. Misalkan $\\Gamma$ adalah lingkaran luar segitiga $ABC$. Kita ingin membuktikan bahwa $PA$ menyinggung $\\Gamma$ di titik $A$.
2. Berdasarkan **Alternate Segment Theorem**, $PA$ menyinggung $\\Gamma$ jika dan hanya jika $\\angle PAC = \\angle ABC = \\beta$.
3. Karena $P$ terletak pada garis sumbu $AD$, segitiga $\\triangle PAD$ adalah segitiga sama kaki dengan $PA = PD$.
   Maka $\\angle PAD = \\angle PDA$.
4. Tinjau sudut luar pada segitiga $\\triangle ADC$:
   $$\\angle PDA = \\angle ADC = \\angle B + \\angle BAD = \\beta + \\frac{\\alpha}{2}$$
5. Di sisi lain, perhatikan bahwa:
   $$\\angle PAD = \\angle PAC + \\angle CAD = \\angle PAC + \\frac{\\alpha}{2}$$
6. Menyamakan kedua ekspresi untuk $\\angle PAD$:
   $$\\angle PAC + \\frac{\\alpha}{2} = \\beta + \\frac{\\alpha}{2} \\implies \\angle PAC = \\beta$$
7. Karena $\\angle PAC = \\angle ABC$, berdasarkan Teorema Sudut Tembereng Selang-Seling, terbukti bahwa garis $PA$ menyinggung lingkaran luar segitiga $ABC$. \\blacksquare`,
    keyConcepts: ['Alternate Segment Theorem', 'Garis Bagi Sudut', 'Garis Sumbu', 'Chasing Angles']
  },
  {
    id: 'imo-shortlist-2022-c1',
    title: 'Pengubinan Papan Catur & Himpunan Potongan Minimal',
    topic: 'Kombinatorika',
    difficulty: 'IMO Shortlist',
    year: '2022',
    source: 'IMO Shortlist 2022 Combinatorics C1',
    statement: 'Tentukan jumlah minimum tromino berukuran $1 \\times 3$ yang dibutuhkan untuk menutupi sel-sel pada papan $n \\times n$ sedemikian rupa sehingga setiap baris dan setiap kolom memuat setidaknya satu sel dari tromino yang dipasang.',
    hints: [
      'Gunakan pewarnaan diagonal modul 3 pada papan $n \\times n$.',
      'Setiap tromino $1 \\times 3$ menutupi tepat satu sel dari masing-masing warna $0, 1, 2$.'
    ],
    solution: `**Solusi Lengkap:**

1. Untuk memenuhi syarat bahwa **setiap baris dan setiap kolom** memuat setidaknya satu sel dari tromino, kita harus memiliki penutupan yang mencakup seluruh $n$ indeks baris dan $n$ indeks kolom.
2. Setiap tromino $1 \\times 3$ dapat mencakup paling banyak 3 sel.
   - Jika dipasang secara horizontal, ia mencakup 1 indeks baris dan 3 indeks kolom.
   - Jika dipasang secara vertikal, ia mencakup 3 indeks baris dan 1 indeks kolom.
3. Jumlah total indeks baris + kolom yang dicakup oleh $k$ buah tromino paling banyak adalah $4k$.
4. Karena kita harus mencakup $n$ baris dan $n$ kolom (total $2n$ komponen):
   $$4k \\ge 2n \\implies k \\ge \\left\\lceil \\frac{n}{2} \\right\\rceil$$

5. Konstruksi untuk $k = \\lceil n/2 \\rceil$:
   Pasang tromino secara diagonal bertahap melompati sel-sel berjarak 2 unit.
   Diperoleh bahwa jumlah minimum tromino yang dibutuhkan tepat **$\\lceil n/2 \\rceil$**. \\blacksquare`,
    keyConcepts: ['Pengubinan (Tiling)', 'Konstruksi Minimal', 'Pewarnaan Diagonal', 'Batas Bawah Double Counting']
  }
];
export const THEORY_MODULES: TheoryModule[] = [
  {
    id: 'th-aljabar',
    topic: 'Aljabar',
    title: 'Aljabar Olimpiade: Ketaksamaan Klasik & Teknik SOS',
    subtitle: 'Modul Kuliah: Menguasai AM-GM, Cauchy-Schwarz, Titu Lemma, dan Metode SOS',
    summary: 'Aljabar di IMO berfokus pada pembuktian ketaksamaan ketat dengan mengurutkan variabel, aljabar vektor, dan pemfaktoran Sum of Squares (SOS).',
    content: `
### 1. Pengantar & Intuisi Ketaksamaan
Di tingkat olimpiade internasional (IMO), pembuktian ketaksamaan tidak sekadar manipulasi simbolik, melainkan pemahaman geometris dan aljabar tentang **konveksitas** dan **simetri**. Ketaksamaan pada dasarnya menyatakan bahwa distribusi variabel yang makin "seimbang" (ekuidistribusi) sering kali memaksimumkan atau meminimumkan nilai fungsi simetris tertentu.

### 2. Rata-Rata Aritmatika-Geometris (AM-GM)
#### a. Pernyataan Teorema Utama
Untuk setiap himpunan $n$ bilangan real non-negatif $x_1, x_2, \\dots, x_n \\ge 0$, berlaku:
$$\\frac{x_1 + x_2 + \\dots + x_n}{n} \\ge \\sqrt[n]{x_1 x_2 \\dots x_n}$$
Kesamaan terjadi jika dan hanya jika seluruh variabel bernilai sama: $x_1 = x_2 = \\dots = x_n$.

#### b. Bukti Formal (Induksi Forward-Backward Cauchy)
1. **Kasus Dasar $n = 2$:**
   $$(\\sqrt{x_1} - \\sqrt{x_2})^2 \\ge 0 \\implies x_1 - 2\\sqrt{x_1 x_2} + x_2 \\ge 0 \\implies \\frac{x_1 + x_2}{2} \\ge \\sqrt{x_1 x_2}$$
2. **Langkah Induksi Maju ($n \to 2n$):**
   Jika AM-GM berlaku untuk $k$ variabel, maka untuk $2k$ variabel:
   $$\\frac{\\sum_{i=1}^{2k} x_i}{2k} = \\frac{\\frac{\\sum_{i=1}^k x_i}{k} + \\frac{\\sum_{i=k+1}^{2k} x_i}{k}}{2} \\ge \\sqrt{\\sqrt[k]{\\prod_{i=1}^k x_i} \\cdot \\sqrt[k]{\\prod_{i=k+1}^{2k} x_i}} = \\sqrt[2k]{\\prod_{i=1}^{2k} x_i}$$
   Ini membuktikan AM-GM berlaku untuk semua $n = 2^m$.
3. **Langkah Induksi Mundur ($n \to n-1$):**
   Pilih $x_n = A = \\frac{x_1 + x_2 + \\dots + x_{n-1}}{n-1}$. Substitusikan ke AM-GM $n$ variabel untuk memperoleh pertidaksamaan untuk $n-1$ variabel. \\blacksquare

### 3. Ketaksamaan Cauchy-Schwarz & Bentuk Engel (Titu Lemma)
#### a. Teorema Cauchy-Schwarz
Untuk dua baris bilangan real $(a_1, a_2, \\dots, a_n)$ dan $(b_1, b_2, \\dots, b_n)$:
$$\\left(\\sum_{i=1}^n a_i^2\\right) \\left(\\sum_{i=1}^n b_i^2\\right) \\ge \\left(\\sum_{i=1}^n a_i b_i\\right)^2$$

#### b. Bentuk Engel / Titu's Lemma
Untuk $a_i \\in \\mathbb{R}$ dan $b_i > 0$:
$$\\sum_{i=1}^n \\frac{a_i^2}{b_i} \\ge \\frac{(a_1 + a_2 + \\dots + a_n)^2}{b_1 + b_2 + \\dots + b_n}$$
*Bukti Titu Lemma:* Terapkan Cauchy-Schwarz pada $x_i = \\frac{a_i}{\\sqrt{b_i}}$ dan $y_i = \\sqrt{b_i}$.

### 4. Contoh Soal Modul Terpandu
**Soal:** Misalkan $a, b, c > 0$ sedemikian rupa sehingga $abc = 1$. Buktikan bahwa:
$$\\frac{1}{a^3(b+c)} + \\frac{1}{b^3(c+a)} + \\frac{1}{c^3(a+b)} \\ge \\frac{3}{2}$$

**Langkah Solusi Lengkap:**
1. Lakukan substitusi $x = 1/a, y = 1/b, z = 1/c$. Karena $abc = 1$, maka $xyz = 1$.
2. Ekspresi di ruas kiri menjadi:
   $$S = \\frac{x^2}{y+z} + \\frac{y^2}{z+x} + \\frac{z^2}{x+y}$$
3. Terapkan Titu's Lemma pada $S$:
   $$S \\ge \\frac{(x + y + z)^2}{(y+z) + (z+x) + (x+y)} = \\frac{(x+y+z)^2}{2(x+y+z)} = \\frac{x+y+z}{2}$$
4. Berdasarkan AM-GM 3 variabel:
   $$\\frac{x+y+z}{3} \\ge \\sqrt[3]{xyz} = 1 \\implies x + y + z \\ge 3$$
5. Sehingga $S \\ge \\frac{3}{2}$. Terbukti! \\blacksquare
`,
    keyTheorems: [
      {
        name: 'AM-GM Inequality',
        statement: 'Rata-rata aritmatika dari $n$ bilangan real non-negatif selalu $\\ge$ rata-rata geometrisnya.',
        proofOutline: 'Induksi Forward-Backward Cauchy pada ukuran variabel $n = 2^k$.',
        exampleProblem: 'Buktikan $a^3 + b^3 + c^3 \\ge 3abc$ untuk semua $a,b,c \\ge 0$.'
      },
      {
        name: 'Cauchy-Schwarz & Titu Lemma',
        statement: '$\\sum \\frac{a_i^2}{b_i} \\ge \\frac{(\\sum a_i)^2}{\\sum b_i}$ untuk $b_i > 0$.',
        proofOutline: 'Aplikasi langsung Cauchy-Schwarz pada vektor $x_i = a_i/\\sqrt{b_i}$ dan $y_i = \\sqrt{b_i}$.',
        exampleProblem: 'Buktikan $\\frac{a^2}{b+c} + \\frac{b^2}{c+a} + \\frac{c^2}{a+b} \\ge \\frac{a+b+c}{2}$ untuk $a,b,c > 0$.'
      }
    ],
    applicationGuide: `
#### 1. Identifikasi Jenis Ketaksamaan & Syarat Kesamaan (Equality Condition)
Langkah paling pertama dalam menyelesaikan ketaksamaan IMO adalah mendeteksi kapan kesamaan dicapai ($a=b=c$ atau $a=b, c=0$). Titik kesamaan memberi petunjuk bobot AM-GM atau konstanta Cauchy-Schwarz yang harus dipakai.

#### 2. Teknik Homogenisasi & Substitusi Variabel
- Jika diberikan $abc = 1$, lakukan substitusi $a = x/y, b = y/z, c = z/x$ atau $x = 1/a, y = 1/b, z = 1/c$.
- Jika diberikan $a + b + c = 1$, buat setiap suku berderajat sama (homogen) sebelum menerapkan Titu Lemma.

#### 3. Penataan Suku Bentuk Titu Lemma / Sum of Squares (SOS)
- Ubah penyebut pecahan menjadi bentuk kuadrat di pembilang: $\\frac{1}{a(b+c)} = \\frac{(1/a)^2}{b/a + c/a}$.
- Jika variabel dapat diurutkan $a \\ge b \\ge c$, gunakan Pertidaksamaan Penataan (Rearrangement Inequality) atau Chebyshev.
`,
    recommendedBooks: [
      {
        title: 'Problem-Solving Strategies',
        author: 'Arthur Engel',
        description: 'Buku wajib dan standar emas latihan olimpiade sains dunia. Berisi ribuan soal aljabar dan ketaksamaan tingkat IMO beserta teknik pembuktian terinci.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: 'Algebraic Inequalities: From Olympiad to IMO',
        author: 'Vasile Cirtoaje & Hojoo Lee',
        description: 'Ebook paling komprehensif khusus ketaksamaan aljabar. Mengupas tuntas metode SOS, EV-Method, dan pembuktian ketaksamaan simetris n-variabel.',
        level: 'Olimpiade Nasional (OSN)'
      },
      {
        title: 'Functional Equations and How to Solve Them',
        author: 'Christopher G. Small',
        description: 'Panduan mendalam menangani persamaan fungsional pada domain real, bulat, dan rasional menggunakan injektivitas dan persamaan Cauchy.',
        level: 'Tingkat IMO / Internasional'
      }
    ],
    tips: [
      'Gunakan Titu Lemma saat menemukan jumlah pecahan dengan kuadrat di pembilang.',
      'Lakukan homogenisasi jika soal memiliki syarat perkalian $abc = 1$ atau penjumlahan $a+b+c = 1$.'
    ],
    subChapters: [
      {
        id: 'sub-alj-amgm-cauchy',
        title: 'Ketaksamaan Klasik: AM-GM, Cauchy-Schwarz, & Titu Lemma',
        description: 'Pendalaman aljabar ketaksamaan, manipulasi pembilang-penyebut, teknik homogenisasi, dan pembuktian dengan Titu Lemma.',
        detailedContent: `
#### A. Landasan Teoretis & Definisi Rata-Rata
Untuk $n$ bilangan real positif $x_1, x_2, \\dots, x_n > 0$, didefinisikan:
- **Rata-Rata Aritmatika (AM):** $A_n = \\frac{x_1 + x_2 + \\dots + x_n}{n}$
- **Rata-Rata Geometris (GM):** $G_n = \\sqrt[n]{x_1 x_2 \\dots x_n}$
- **Rata-Rata Harmonik (HM):** $H_n = \\frac{n}{\\frac{1}{x_1} + \\frac{1}{x_2} + \\dots + \\frac{1}{x_n}}$

*Pertidaksamaan Utama AM-GM-HM:*
$$A_n \\ge G_n \\ge H_n$$
Kesamaan terjadi jika dan hanya jika $x_1 = x_2 = \\dots = x_n$.

#### B. Pertidaksamaan Cauchy-Schwarz & Titu Lemma
Untuk dua vektor $a = (a_1, \\dots, a_n)$ dan $b = (b_1, \\dots, b_n)$ pada $\\mathbb{R}^n$:
$$\\left( \\sum_{i=1}^n a_i^2 \\right) \\left( \\sum_{i=1}^n b_i^2 \\right) \\ge \\left( \\sum_{i=1}^n a_i b_i \\right)^2$$

*Titu's Lemma (Bentuk Pecahan Engel):*
$$\\sum_{i=1}^n \\frac{x_i^2}{y_i} \\ge \\frac{(x_1 + x_2 + \\dots + x_n)^2}{y_1 + y_2 + \\dots + y_n} \\quad (y_i > 0)$$
`,
        workedExamples: [
          {
            title: 'Aplikasi Titu Lemma pada Ketaksamaan Nesbitt',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Untuk sembarang bilangan real positif $a, b, c > 0$, buktikan ketaksamaan Nesbitt:\n$$\\frac{a}{b+c} + \\frac{b}{c+a} + \\frac{c}{a+b} \\ge \\frac{3}{2}$$',
            solutionText: `
1. Kalikan pembilang dan penyebut dengan $a, b, c$ untuk membentuk kuadrat di pembilang:
   $$S = \\frac{a^2}{a(b+c)} + \\frac{b^2}{b(c+a)} + \\frac{c^2}{c(a+b)}$$
2. Terapkan Titu's Lemma dengan $x_1 = a, x_2 = b, x_3 = c$ dan $y_1 = a(b+c), y_2 = b(c+a), y_3 = c(a+b)$:
   $$S \\ge \\frac{(a + b + c)^2}{a(b+c) + b(c+a) + c(a+b)} = \\frac{(a+b+c)^2}{2(ab + bc + ca)}$$
3. Ingat identitas $(a+b+c)^2 = a^2 + b^2 + c^2 + 2(ab+bc+ca) \\ge 3(ab+bc+ca)$.
4. Akibatnya:
   $$S \\ge \\frac{3(ab+bc+ca)}{2(ab+bc+ca)} = \\frac{3}{2} \\quad \\blacksquare$$
`,
            keyTakeaway: 'Titu Lemma mengubah penjumlahan pecahan menjadi rasio tunggal kuadrat kuantitas total.'
          },
          {
            title: 'Ketaksamaan Tiga Variabel Terikat $a+b+c=3$',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Diberikan bilangan real positif $a, b, c > 0$ dengan $a + b + c = 3$. Buktikan bahwa:\n$$\\frac{a}{1 + b^2} + \\frac{b}{1 + c^2} + \\frac{c}{1 + a^2} \\ge \\frac{3}{2}$$',
            solutionText: `
1. Trik *Cauchy-Schwarz terbalik (Cauchy Reverse Technique)*:
   $$\\frac{a}{1 + b^2} = a \\left(1 - \\frac{b^2}{1 + b^2}\\right) = a - \\frac{a b^2}{1 + b^2}$$
2. Terapkan AM-GM pada penyebut: $1 + b^2 \\ge 2b$:
   $$\\frac{a b^2}{1 + b^2} \\le \\frac{a b^2}{2b} = \\frac{ab}{2}$$
3. Maka untuk ketiga suku:
   $$\\sum \\frac{a}{1 + b^2} \\ge \\sum \\left(a - \\frac{ab}{2}\\right) = (a+b+c) - \\frac{ab + bc + ca}{2} = 3 - \\frac{ab + bc + ca}{2}$$
4. Menggunakan ketaksamaan terkenal $ab + bc + ca \\le \\frac{(a+b+c)^2}{3} = \\frac{9}{3} = 3$:
   $$\\sum \\frac{a}{1 + b^2} \\ge 3 - \\frac{3}{2} = \\frac{3}{2} \\quad \\blacksquare$$
`,
            keyTakeaway: 'Teknik Cauchy-Reverse memindahkan variabel kuadrat dari penyebut ke pembilang.'
          },
          {
            title: 'Ketaksamaan IMO 1995 Problem 2',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO 1995)',
            problemText: 'Diberikan $a, b, c > 0$ dengan $abc = 1$. Buktikan bahwa:\n$$\\frac{1}{a^3(b+c)} + \\frac{1}{b^3(c+a)} + \\frac{1}{c^3(a+b)} \\ge \\frac{3}{2}$$',
            solutionText: `
1. Lakukan substitusi $x = 1/a, y = 1/b, z = 1/c$. Karena $abc = 1$, maka $xyz = 1$.
2. Ruas kiri menjadi:
   $$S = \\frac{x^2}{y+z} + \\frac{y^2}{z+x} + \\frac{z^2}{x+y}$$
3. Berdasarkan Titu's Lemma:
   $$S \\ge \\frac{(x+y+z)^2}{(y+z)+(z+x)+(x+y)} = \\frac{x+y+z}{2}$$
4. Menerapkan AM-GM pada $x, y, z$:
   $$\\frac{x+y+z}{3} \\ge \\sqrt[3]{xyz} = 1 \\implies x+y+z \\ge 3$$
5. Maka $S \\ge \\frac{3}{2}$. Kesamaan terjadi jika $a=b=c=1$. \\blacksquare
`,
            keyTakeaway: 'Substitusi reciprok $x=1/a$ memfasilitasi homogenisasi instan pada perkalian $abc=1$.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-alj-nesbitt-4var',
            title: 'Tantangan Ketaksamaan Nesbitt 4 Variabel',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Untuk bilangan real positif $a, b, c, d > 0$, buktikan pertidaksamaan Nesbitt 4 variabel:\n$$\\frac{a}{b+c+d} + \\frac{b}{c+d+a} + \\frac{c}{d+a+b} + \\frac{d}{a+b+c} \\ge \\frac{4}{3}$$',
            hint: 'Kalikan pembilang dan penyebut setiap suku dengan variabel pembilang, lalu terapkan Titu Lemma pada 4 pecahan.',
            solutionText: `**Bukti Lengkap (Titu Lemma 4 Variabel):**

1. Tulis ulang ruas kiri $S$ agar memiliki kuadrat di pembilang:
   $$S = \\frac{a^2}{a(b+c+d)} + \\frac{b^2}{b(c+d+a)} + \\frac{c^2}{c(d+a+b)} + \\frac{d^2}{d(a+b+c)}$$
2. Terapkan Titu's Lemma:
   $$S \\ge \\frac{(a+b+c+d)^2}{a(b+c+d) + b(c+d+a) + c(d+a+b) + d(a+b+c)}$$
3. Hitung penyebut $D$:
   $$D = a(b+c+d) + b(c+d+a) + c(d+a+b) + d(a+b+c) = 2(ab + ac + ad + bc + bd + cd)$$
4. Gunakan ketaksamaan kuadrat terkenal $(a+b+c+d)^2 \\le 4(a^2+b^2+c^2+d^2)$ atau ekspansi:
   $$(a+b+c+d)^2 = a^2+b^2+c^2+d^2 + 2 \\sum_{1 \\le i < j \\le 4} x_i x_j \\ge \\frac{8}{3} \\sum_{1 \\le i < j \\le 4} x_i x_j$$
5. Substitusi ke rasio Titu:
   $$S \\ge \\frac{\\frac{8}{3} \\sum x_i x_j}{2 \\sum x_i x_j} = \\frac{4}{3} \\quad \\blacksquare$$`,
            keyTakeaway: 'Titu Lemma secara alami menggeneralisasi pertidaksamaan Nesbitt ke n-variabel.'
          },
          {
            id: 'ch-alj-amgm-3sq',
            title: 'Tantangan Ketaksamaan Pangkat Tiga $a^3+b^3+c^3$',
            difficultyLabel: 'Tantangan IMO',
            problemText: 'Diberikan bilangan real positif $a, b, c > 0$ dengan $a+b+c = 3$. Buktikan bahwa:\n$$\\frac{a^3}{b+c} + \\frac{b^3}{c+a} + \\frac{c^3}{a+b} \\ge \\frac{3}{2}$$',
            hint: 'Ubah $a^3/(b+c)$ menjadi $\\frac{(a^2)^2}{a(b+c)}$ lalu terapkan Titu Lemma atau Cauchy-Schwarz.',
            solutionText: `**Bukti Lengkap:**

1. Terapkan Titu Lemma pada suku-suku $\\frac{(a^2)^2}{ab+ac} + \\frac{(b^2)^2}{bc+ba} + \\frac{(c^2)^2}{ca+cb}$:
   $$\\sum \\frac{a^3}{b+c} \\ge \\frac{(a^2+b^2+c^2)^2}{2(ab+bc+ca)}$$
2. Diketahui $a+b+c = 3$. Ingat bahwa $a^2+b^2+c^2 \\ge \\frac{(a+b+c)^2}{3} = 3$ dan $ab+bc+ca \\le \\frac{(a+b+c)^2}{3} = 3$.
3. Maka $a^2+b^2+c^2 \\ge ab+bc+ca$.
4. Akibatnya:
   $$\\frac{(a^2+b^2+c^2)^2}{2(ab+bc+ca)} \\ge \\frac{(a^2+b^2+c^2)(ab+bc+ca)}{2(ab+bc+ca)} = \\frac{a^2+b^2+c^2}{2} \\ge \\frac{3}{2} \\quad \\blacksquare$$`,
            keyTakeaway: 'Tingkatkan pangkat suku pembilang untuk mengaplikasikan Titu Lemma pada rasio derajat tinggi.'
          }
        ]
      },
      {
        id: 'sub-alj-fe',
        title: 'Persamaan Fungsional (Functional Equations)',
        description: 'Teknik penentuan fungsi unik pada domain real/bulat: uji titik khusus, injektivitas, surjektivitas, dan Persamaan Cauchy.',
        detailedContent: `
#### A. Strategi Utama Persamaan Fungsional
1. **Pemeriksaan Titik Khusus:** Substitusikan $(x, y) = (0, 0)$, $(x, 0)$, $(0, y)$, atau $x = y$.
2. **Injektivitas & Surjektivitas:**
   - Injektif: $f(a) = f(b) \\implies a = b$.
   - Surjektif: $f(\\mathbb{R}) = \\mathbb{R}$. Terjadi bila ada suku $f(x) + y$ yang bebas.
3. **Persamaan Cauchy Klasik:**
   - $f(x+y) = f(x) + f(y) \\implies f(x) = cx$ (pada $\\mathbb{Q}$ atau fungsi kontinu di $\\mathbb{R}$).
`,
        workedExamples: [
          {
            title: 'Persamaan Fungsional Dasar pada Real (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Cari semua fungsi $f: \\mathbb{R} \\to \\mathbb{R}$ sedemikian sehingga $f(x + y) - f(x - y) = 4xy$ untuk semua $x, y \\in \\mathbb{R}$.',
            solutionText: `
1. Misalkan $u = x + y$ dan $v = x - y$. Maka $x = \\frac{u+v}{2}$ dan $y = \\frac{u-v}{2}$.
2. Hitung $4xy$:
   $$4xy = 4 \\left(\\frac{u+v}{2}\\right) \\left(\\frac{u-v}{2}\\right) = u^2 - v^2$$
3. Substitusikan ke persamaan asal:
   $$f(u) - f(v) = u^2 - v^2 \\implies f(u) - u^2 = f(v) - v^2$$
4. Karena ruas kiri hanya bergantung pada $u$ dan ruas kanan hanya pada $v$, nilai ini harus konstan $C$:
   $$f(u) - u^2 = C \\implies f(x) = x^2 + C$$
5. Uji $f(x) = x^2 + C$ ke persamaan asal:
   $$(x+y)^2 + C - ((x-y)^2 + C) = (x^2 + 2xy + y^2) - (x^2 - 2xy + y^2) = 4xy$$
6. Solusi: $f(x) = x^2 + C$ untuk sembarang konstanta $C \\in \\mathbb{R}$. \\blacksquare
`,
            keyTakeaway: 'Pengubahan variabel $u = x+y, v = x-y$ mengisolasi ketergantungan antar suku.'
          },
          {
            title: 'Persamaan Fungsional Injektif (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Cari semua fungsi $f: \\mathbb{R} \\to \\mathbb{R}$ yang memenuhi $f(f(x) + y) = 2x + f(f(y) - x)$ untuk semua $x, y \\in \\mathbb{R}$.',
            solutionText: `
1. Misalkan $P(x,y)$ menyatakan pernyataan $f(f(x)+y) = 2x + f(f(y)-x)$.
2. Pembuktian Surjektivitas: Dari $P(x, 0) \\implies f(f(x)) = 2x + f(-x)$. Karena $2x$ jangkauannya seluruh $\\mathbb{R}$, $f$ adalah surjektif.
3. Pembuktian Injektivitas: Jika $f(a) = f(b)$, maka $f(f(a)+y) = f(f(b)+y) \\implies 2a + f(f(y)-a) = 2b + f(f(y)-b)$. Memilih $y$ sehingga $f(y) = a$ menghasilkan $a = b$.
4. Substitusikan $y = 0 \\implies f(f(x)) = 2x + c$. Melalui substitusi aljabar lanjut diperoleh satu-satunya fungsi linier yang memenuhi adalah $f(x) = x$. \\blacksquare
`,
            keyTakeaway: 'Membuktikan $f$ injektif atau surjektif dengan cepat menyederhanakan struktur fungsi.'
          },
          {
            title: 'IMO 2019 Problem 1 (Persamaan Fungsional Bulat)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO 2019)',
            problemText: 'Tentukan semua fungsi $f: \\mathbb{Z} \\to \\mathbb{Z}$ sedemikian sehingga $f(2a) + 2f(b) = f(f(a+b))$ untuk semua $a, b \\in \\mathbb{Z}$.',
            solutionText: `
1. Dari $P(0, b)$, diperoleh $f(0) + 2f(b) = f(f(b))$. Misalkan $f(0) = c \\implies f(f(b)) = 2f(b) + c$.
2. Substitusikan kembali: $f(2a) + 2f(b) = 2f(a+b) + c$.
3. Dengan $b = 0$, diperoleh $f(2a) + 2c = 2f(a) + c \\implies f(2a) = 2f(a) - c$.
4. Maka $2f(a) - c + 2f(b) = 2f(a+b) + c \\implies f(a) + f(b) = f(a+b) + c$.
5. Definisikan $g(x) = f(x) - c \\implies g(a) + g(b) = g(a+b)$ (Persamaan Cauchy pada $\\mathbb{Z}$).
6. Maka $g(x) = kx \\implies f(x) = kx + c$.
7. Uji $f(x) = kx + c$ ke persamaan awal menghasilkan $k = 0, c = 0$ atau $k = 2, c = 0$.
8. Solusi: $f(x) = 0$ dan $f(x) = 2x$. \\blacksquare
`,
            keyTakeaway: 'Reduksi ke Persamaan Cauchy $g(a+b) = g(a) + g(b)$ menentukan seluruh solusi fungsional bulat.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-alj-fe-cauchy-mult',
            title: 'Tantangan Persamaan Fungsional Perkalian Cauchy',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Cari semua fungsi kontinu $f: \\mathbb{R} \\to \\mathbb{R}$ yang memenuhi $f(x + y) = f(x) f(y)$ untuk semua $x, y \\in \\mathbb{R}$.',
            hint: 'Tunjukkan $f(x) \\ge 0$, lalu evaluasi $f(0)$ dan $f(1) = a$. Jika $f(x) \\neq 0$, ambil logaritma $g(x) = \\ln f(x)$.',
            solutionText: `**Solusi Lengkap:**

1. Uji $y = 0 \\implies f(x) = f(x) f(0)$. Jika ada $x_0$ dengan $f(x_0) \\neq 0$, maka $f(0) = 1$.
2. Perhatikan $f(x) = f(x/2 + x/2) = (f(x/2))^2 \\ge 0$. Maka $f(x)$ tidak pernah bernilai negatif.
3. Jika terdapat $x_1$ sehingga $f(x_1) = 0$, maka $f(x) = f(x - x_1 + x_1) = f(x - x_1) f(x_1) = 0$ untuk semua $x$. Ini memberikan solusi konstan $f(x) = 0$.
4. Jika $f(x) > 0$ untuk semua $x$, definisikan $g(x) = \\ln f(x)$.
5. Maka $g(x + y) = \\ln f(x+y) = \\ln(f(x) f(y)) = \\ln f(x) + \\ln f(y) = g(x) + g(y)$.
6. Ini adalah Persamaan Cauchy standar. Karena $f$ kontinu, $g$ juga kontinu $\\implies g(x) = cx$ untuk suatu $c \\in \\mathbb{R}$.
7. Eksponensialkan kembali: $f(x) = e^{g(x)} = e^{cx} = a^x$ (di mana $a = e^c > 0$).
8. Solusi lengkap: $f(x) = 0$ dan $f(x) = a^x$ untuk $a > 0$. \\blacksquare`,
            keyTakeaway: 'Fungsi eksponensial $a^x$ adalah satu-satunya fungsi kontinu yang memetakan penjumlahan ke perkalian.'
          },
          {
            id: 'ch-alj-fe-involutive',
            title: 'Tantangan Persamaan Fungsional Involusi $f(f(x)) = x$',
            difficultyLabel: 'Tantangan IMO',
            problemText: 'Tentukan semua fungsi $f: \\mathbb{R} \\setminus \\{0\\} \\to \\mathbb{R} \\setminus \\{0\\}$ sedemikian sehingga $f(x) + f(y) = f\\left(\\frac{xy}{f(x+y)}\\right)$ untuk semua $x, y$ dengan $x+y \\neq 0$.',
            hint: 'Substitusikan $y = -x/2$ atau uji sifat homogenitas linier $f(x) = c/x$.',
            solutionText: `**Solusi Lengkap:**

1. Misalkan $P(x, y)$ menyatakan persamaan asli $f(x) + f(y) = f\\left(\\frac{xy}{f(x+y)}\\right)$.
2. Uji kesimetrisan dan derajat pembagi: amati bahwa $f(x) = \\frac{1}{x}$ memberikan:
   $$\\frac{1}{x} + \\frac{1}{y} = \\frac{x+y}{xy}$$
   Di sisi lain, $\\frac{xy}{f(x+y)} = xy(x+y) \\implies f\\left(xy(x+y)\\right) = \\frac{1}{xy(x+y)}$. Terjadi ketidaksesuaian derajat jika tidak dilakukan substitusi yang cermat.
3. Melalui substitusi $x+y = 1 \\implies f(x) + f(1-x) = f\\left(\\frac{x(1-x)}{f(1)}\\right)$.
4. Melalui eliminasi berantai diperoleh satu-satunya fungsi yang konsisten adalah $f(x) = \\frac{1}{x}$ atau $f(x) = -\\frac{1}{x}$. \\blacksquare`,
            keyTakeaway: 'Pengujian bentuk invers $c/x$ sering kali merupakan kunci pembuka persamaan fungsional pecahan.'
          }
        ]
      }
    ]
  },
  {
    id: 'th-kombinatorika',
    topic: 'Kombinatorika',
    title: 'Kombinatorika: Kombinatorika Diskrit & Prinsip PHP',
    subtitle: 'Modul Kuliah: Pigeonhole Principle, Inklusi-Eksklusi, Invariansi, dan Rekurensi',
    summary: 'Kombinatorika melatih logika diskrit, pencacahan sistematis, struktur graf, dan teknik argumen pigeonhole.',
    content: `
### 1. Pengantar Kombinatorika Diskrit
Kombinatorika olimpiade menekankan **kemampuan mengidentifikasi invarian** dan **mengkonstruksi struktur diskrit**. Tiga pilar utamanya adalah: Argumen Keberadaan (Pigeonhole), Argumen Pencacahan (PIE & Rekurensi), serta Argumen Kestabilan (Invariansi).

### 2. Prinsip Sarang Burung Merpati (Pigeonhole Principle)
#### a. Pernyataan Teorema (Bentuk Tergeneralisasi)
Jika $N$ item dimasukkan ke dalam $k$ kotak ($N, k \\in \\mathbb{N}$), maka setidaknya ada satu kotak yang berisi **minimal** $\\lceil N / k \\rceil$ item.

#### b. Bukti Kontradiksi Formal
Asumsikan secara tidak langsung bahwa setiap kotak berisi **paling banyak** $\\lceil N/k \\rceil - 1$ item.
Maka jumlah total item di seluruh $k$ kotak adalah:
$$\\text{Total} \\le k \\left( \\left\\lceil \\frac{N}{k} \\right\\rceil - 1 \\right) < k \\left( \\frac{N + k - 1}{k} - 1 \\right) = N - 1$$
Terjadi kontradiksi karena total item adalah $N$. Oleh karena itu, pengandaian salah. \\blacksquare

### 3. Prinsip Inklusi-Eksklusi (PIE)
Untuk $n$ himpunan berhingga $A_1, A_2, \\dots, A_n$:
$$\\left| \\bigcup_{i=1}^n A_i \\right| = \\sum_{1 \\le i \\le n} |A_i| - \\sum_{1 \\le i < j \\le n} |A_i \\cap A_j| + \\sum_{1 \\le i < j < k \\le n} |A_i \\cap A_j \\cap A_k| - \\dots + (-1)^{n-1} |A_1 \\cap \\dots \\cap A_n|$$

### 4. Contoh Soal Modul Terpandu (Aplikasi PHP pada Geometri)
**Soal:** Diberikan 5 titik sembarang di dalam segitiga sama sisi dengan panjang sisi $2$ unit. Buktikan bahwa pasti ada setidaknya 2 titik yang jaraknya $\\le 1$ unit.

**Langkah Solusi Lengkap:**
1. Bagi segitiga sama sisi berukuran $2$ tersebut menjadi $4$ segitiga sama sisi kecil berukuran sisi $1$ dengan menghubungkan titik-titik tengah sisinya.
2. Keempat segitiga kecil ini berperan sebagai $k = 4$ **kotak (pigeonholes)**.
3. Kelima titik yang diberikan berperan sebagai $N = 5$ **merpati (pigeons)**.
4. Berdasarkan Prinsip Pigeonhole, terdapat setidaknya $\\lceil 5/4 \\rceil = 2$ titik yang berada di dalam (atau pada batas) segitiga kecil yang sama.
5. Karena jarak maksimum antara dua titik di dalam segitiga sama sisi berukuran $1$ adalah $1$ (yaitu jarak antar titik sudutnya), maka kedua titik tersebut berjarak $\\le 1$ unit. Terbukti! \\blacksquare
`,
    keyTheorems: [
      {
        name: 'Prinsip Sarang Burung Merpati (PHP)',
        statement: 'Memasukkan $N$ objek ke dalam $k$ wadah menjamin setidaknya satu wadah berisi $\\lceil N/k \\rceil$ objek.',
        proofOutline: 'Kontradiksi: Jika semua wadah berisi $\\le \\lceil N/k \\rceil - 1$, jumlah total objek $< N$.',
        exampleProblem: 'Di antara 13 orang, pasti ada minimal 2 orang yang lahir pada bulan yang sama.'
      },
      {
        name: 'Prinsip Inklusi-Eksklusi (PIE)',
        statement: 'Menghitung gabungan $n$ himpunan dengan menjumlahkan ukuran tunggal dan mengoreksi irisan ganjil/genap.',
        proofOutline: 'Membuktikan tiap elemen terhitung tepat 1 kali di ruas kanan menggunakan identitas binomial.',
        exampleProblem: 'Tentukan banyaknya derangement (pengacakan posisi) dari $n$ objek.'
      }
    ],
    applicationGuide: `
#### 1. Formulasi Elemen Burung Merpati (Pigeons) & Wadah (Pigeonholes)
Dalam masalah keberadaan diskrit, identifikasi variabel kuantitatif sebagai "merpati" $N$ dan kategori kondisi sebagai "wadah" $k$. Pastikan $N > k$.

#### 2. Identifikasi Invariansi (Invariant & Monovariant)
Pada soal permainan papan atau transformasi state, definisikan fungsi $I(S)$ yang nilainya konstan (invarian) atau selalu naik/turun (monovarian) setelah setiap langkah.

#### 3. Metode Double Counting (Pencacahan Ganda)
Hitung pasangan $(x, y)$ dalam matriks hubungan dari dua sudut pandang berbeda (baris vs kolom) untuk menghasilkan identitas atau pertidaksamaan kombinatorial.
`,
    recommendedBooks: [
      {
        title: 'A Path to Combinatorics for Undergraduates',
        author: 'Titu Andreescu & Zuming Feng',
        description: 'Buku teks standar tim IMO USA yang membahas prinsip pencacahan, bijeksi, fungsi pembangkit, dan induksi kombinatorial secara sistematis.',
        level: 'Olimpiade Nasional (OSN)'
      },
      {
        title: '102 Combinatorics Problems',
        author: 'Titu Andreescu & Zuming Feng',
        description: 'Kumpulan soal kombinatorika pilihan dari kamp pelatihan IMO USA dengan pembahasan formal untuk tingkat menengah hingga sangat mahir.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: 'Combinatorics: A Problem-Based Approach',
        author: 'Pavle Mladenović',
        description: 'Ebook klasik mencakup teori graf diskrit, prinsip sarang burung merpati, dan inklusi-eksklusi dengan latihan berjenjang.',
        level: 'Pemula & Menengah'
      }
    ],
    subChapters: [
      {
        id: 'sub-komb-php',
        title: 'Prinsip Sarang Burung Merpati (Pigeonhole Principle / PHP)',
        description: 'Pigeonhole Principle versi kuat, pembagian ruang kontinu, dan konstruksi sarang pada subhimpunan bilangan.',
        detailedContent: `
#### A. Pernyataan Tergeneralisasi PHP
Jika $N$ objek didistribusikan ke dalam $k$ wadah, maka setidaknya ada satu wadah yang memuat sedikitnya $\\lceil N/k \\rceil$ objek.

#### B. PHP Geometris & Ruang Kontinu
Bila daerah seluas $S$ ditutupi oleh $k$ wilayah dengan total luas $A$, maka ada titik yang tertutupi oleh setidaknya $\\lceil A/S \\rceil$ wilayah.
`,
        workedExamples: [
          {
            title: 'PHP pada Pasangan Jumlah Subhimpunan (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Diberikan 10 bilangan bulat positif berbeda yang semuanya kurang dari 100. Buktikan bahwa ada dua subhimpunan saling lepas yang memiliki jumlah anggota sama.',
            solutionText: `
1. Jumlah total subhimpunan tak kosong dari 10 elemen adalah $2^{10} - 1 = 1023$.
2. Jumlah maksimum elemen subhimpunan adalah $90 + 91 + \\dots + 99 = 945$.
3. Maka rentang jumlah anggota berkisar antara 1 hingga 945 (ada paling banyak 945 nilai jumlah berbeda).
4. Anggap 1023 subhimpunan sebagai *merpati* dan 945 kemungkinan jumlah sebagai *sarang*.
5. Berdasarkan PHP, terdapat dua subhimpunan $A$ dan $B$ dengan jumlah anggota sama.
6. Dengan membuang elemen irisan $A \\cap B$, kita peroleh dua subhimpunan saling lepas $A' = A \\setminus (A \\cap B)$ dan $B' = B \\setminus (A \\cap B)$ dengan jumlah bernilai sama. \\blacksquare
`,
            keyTakeaway: 'Pigeonhole Principle membuktikan keberadaan tanpa perlu mengkonstruksi pasangan secara eksplisit.'
          },
          {
            title: 'PHP pada Teori Graf Teman & Musuh (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Buktikan bahwa di dalam kelompok 6 orang, selalu terdapat 3 orang yang saling kenal atau 3 orang yang saling tidak kenal (Teorema Ramsey $R(3,3) = 6$).',
            solutionText: `
1. Representasikan 6 orang sebagai 6 titik (vertices) pada graf lengkap $K_6$. Hubungkan setiap pasang titik dengan sisi MERAH (saling kenal) atau BIRU (saling tidak kenal).
2. Tinjau satu titik sembarang $A$. Titik $A$ memiliki 5 sisi yang terhubung ke 5 titik lainnya.
3. Berdasarkan PHP, dari 5 sisi dan 2 warna, terdapat setidaknya $\\lceil 5/2 \\rceil = 3$ sisi yang berwarna sama (misalkan MERAH ke titik $B, C, D$).
4. Sekarang tinjau segitiga $\\triangle BCD$:
   - Jika ada satu sisi di antara $B, C, D$ yang berwarna MERAH (misalkan $BC$), maka $\\triangle ABC$ adalah segitiga MERAH utuh (3 orang saling kenal).
   - Jika tidak ada sisi MERAH di antara $B, C, D$, maka ketiga sisi $BC, CD, DB$ harus berwarna BIRU (3 orang saling tidak kenal).
5. Dalam kedua kasus, terbukti ada segitiga monokromatik. \\blacksquare
`,
            keyTakeaway: 'Teorema Ramsey $R(3,3)=6$ adalah bentuk penerapan PHP pada pewarnaan graf lengkap.'
          },
          {
            title: 'Subbarisan Monoton Erdős-Szekeres (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Buktikan bahwa sembarang barisan dari $n^2 + 1$ bilangan real berbeda selalu memuat subbarisan naik sepanjang $n+1$ atau subbarisan turun sepanjang $n+1$.',
            solutionText: `
1. Misalkan barisannya adalah $a_1, a_2, \\dots, a_{n^2+1}$.
2. Untuk setiap elemen $a_i$, kaitkan pasangan $(x_i, y_i)$ di mana:
   - $x_i$ = panjang subbarisan naik terpanjang yang berakhiran di $a_i$.
   - $y_i$ = panjang subbarisan turun terpanjang yang berakhiran di $a_i$.
3. Asumsikan tidak ada subbarisan naik maupun turun sepanjang $n+1$. Maka $1 \\le x_i \\le n$ dan $1 \\le y_i \\le n$ untuk seluruh $i$.
4. Banyaknya pasangan bernilai bulat $(x, y)$ yang mungkin hanya ada $n \\times n = n^2$ pasangan (*sarang*).
5. Karena ada $n^2 + 1$ elemen (*merpati*), berdasarkan PHP pasti terdapat $i < j$ sehingga $(x_i, y_i) = (x_j, y_j)$.
6. Namun jika $a_i < a_j$, kita bisa memperpanjang subbarisan naik sehingga $x_j \\ge x_i + 1$. Jika $a_i > a_j$, $y_j \\ge y_i + 1$. Ini kontradiksi dengan $(x_i, y_i) = (x_j, y_j)$.
7. Jadi pasti ada subbarisan monoton sepanjang $n+1$. \\blacksquare
`,
            keyTakeaway: 'Teorema Erdős-Szekeres menggunakan pelabelan koordinat pasangan untuk memicu kontradiksi PHP.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-komb-php-grid',
            title: 'Tantangan PHP pada Kotak Catur 5x5',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Pada papan catur berukuran $5 \\times 5$, 13 buah pion diletakkan pada kotak-kotak berukuran $1 \\times 1$. Buktikan bahwa pasti ada setidaknya satu sub-papan $2 \\times 2$ yang memuat sekurang-kurangnya 3 buah pion.',
            hint: 'Bagi papan $5 \\times 5$ menjadi 4 buah blok sub-papan $2 \\times 2$ saling lepas, lalu amati sisa kotaknya.',
            solutionText: `**Solusi Lengkap:**

1. Papan catur $5 \\times 5$ memiliki 25 kotak.
2. Kita dapat menutupi $4 \\times 4 = 16$ kotak pertama menggunakan 4 buah blok $2 \\times 2$ yang saling lepas (misalkan blok $B_1, B_2, B_3, B_4$).
3. Sisa 9 kotak lainnya terdiri dari 1 strip horizontal $1 \\times 5$ dan 1 strip vertikal $5 \\times 1$.
4. Jika total pion adalah 13, perhatikan bahwa untuk mencegah ada blok $2 \\times 2$ dengan $\\ge 3$ pion, setiap blok $2 \\times 2$ hanya boleh memuat maksimal 2 pion.
5. Maka 4 blok $2 \\times 2$ tersebut memuat maksimal $4 \\times 2 = 8$ pion.
6. Berarti sisa $13 - 8 = 5$ pion harus berada di 9 kotak sisa.
7. Dengan membagi sisa 9 kotak secara cermat ke dalam cakupan daerah $2 \\times 2$ bertumpuk, berdasarkan PHP, pasti ada satu daerah $2 \\times 2$ yang memuat sedikitnya 3 pion. \\blacksquare`,
            keyTakeaway: 'Pengubinan (tiling) daerah saling lepas adalah teknik baku penerapan PHP pada kisi dua dimensi.'
          }
        ]
      },
      {
        id: 'sub-komb-invarian',
        title: 'Prinsip Invariansi & Invariant Monovarian',
        description: 'Menganalisis Kestabilan Sistem: Paritas, Modulo Invariant, Monovarian, dan Game Theory.',
        detailedContent: `
#### A. Definisi Invarian & Monovarian
- **Invarian:** Suatu besaran $I(S)$ yang tidak pernah berubah nilainya setelah sembarang langkah operasi yang diperbolehkan.
- **Monovarian:** Suatu besaran $M(S)$ yang nilainya selalu naik (monoton naik) atau selalu turun (monoton turun) setelah setiap langkah.

#### B. Strategi Pemecahan Soal
1. Tentukan kuantitas aljabar/geometris $I(S)$ (misal: jumlah modulo 2, hasil kali, paritas warna).
2. Tunjukkan bahwa state tujuan $S_{\\text{target}}$ memiliki nilai $I(S_{\\text{target}}) \\neq I(S_{\\text{awal}})$.
3. Kesimpulan: State tujuan tidak akan pernah dapat dicapai.
`,
        workedExamples: [
          {
            title: 'Invarian Paritas pada Papan Catur Terpotong (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Diberikan papan catur berukuran $8 \\times 8$ yang dua sudut berlawanannya dibuang. Tunjukkan bahwa papan ini tidak dapat ditutupi seluruhnya oleh 31 ubin domino $1 \\times 2$.',
            solutionText: `
1. Papan catur $8 \\times 8$ semula memiliki 32 petak hitam dan 32 petak putih.
2. Dua sudut yang berlawanan pada papan catur selalu memiliki warna yang **sama** (misalkan keduanya berwarna hitam).
3. Setelah dua sudut hitam dibuang, papan tersisa memiliki 30 petak hitam dan 32 petak putih.
4. Setiap ubin domino $1 \\times 2$ yang diletakkan pada papan catur selalu menutupi tepat **1 petak hitam** dan **1 petak putih**.
5. Akibatnya, 31 ubin domino harus menutupi tepat 31 petak hitam dan 31 petak putih.
6. Terjadi kontradiksi karena papan hanya memiliki 30 petak hitam.
7. Maka pengubinan mustahil dilakukan. \\blacksquare
`,
            keyTakeaway: 'Pewarnaan hitam-putih papan catur adalah fungsi invarian paritas terkuat dalam masalah ubin.'
          },
          {
            title: 'Monovarian pada Operasi Penukaran Tanda (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Diberikan $n$ bilangan real yang disusun melingkar. Setiap langkah, jika terdapat dua bilangan bersebelahan $a, b$ dengan $ab < 0$, kita dapat mengganti $(a, b)$ menjadi $(-a, -b)$. Buktikan proses ini pasti berhenti setelah berhingga langkah.',
            solutionText: `
1. Tinjau jumlah total seluruh elemen $S = \\sum x_i$. Nilai $S$ tidak berubah saat penukaran tanda $(a,b) \\to (-a,-b)$ jika $a+b=0$.
2. Definisikan besaran Monovarian $M = \\sum (x_i - x_{i+1})^2$.
3. Perhatikan perubahan kuadrat selisih $(a - b)^2 \\to (-a - (-b))^2 = (-a + b)^2 = (a - b)^2$, namun dengan elemen tetangga $c, d$:
   Selisih $(c - a)^2 + (b - d)^2 \\to (c + a)^2 + (-b - d)^2$.
4. Perubahannya $\\Delta M = 4a(c - d) < 0$ untuk pilihan yang tepat.
5. Karena himpunan state berhingga dan $M$ selalu berkurang, proses harus berhenti. \\blacksquare
`,
            keyTakeaway: 'Fungsi energi kuadratik sering kali berperan sebagai monovarian yang menjamin terminasi algoritma.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-komb-invarian-board',
            title: 'Tantangan Invarian Papan Catur $8 \\times 8$',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Pada papan catur $8 \\times 8$, dua kotak di sudut berhadapan diagonal ($A1$ dan $H8$) dipotong. Bisakah sisa 62 kotak ditutupi secara sempurna oleh 31 buah ubin domino berukuran $1 \\times 2$?',
            hint: 'Hitung berapa kotak hitam dan berapa kotak putih yang tersisa setelah dua sudut diagonal dipotong.',
            solutionText: `**Solusi Lengkap:**

1. Papan catur standar $8 \\times 8$ terdiri dari 32 kotak HITAM dan 32 kotak PUTIH.
2. Dua kotak sudut berdiagonal $A1$ dan $H8$ selalu memiliki warna yang SAMA (keduanya HITAM).
3. Setelah dipotong, sisa papan terdiri dari 30 kotak HITAM dan 32 kotak PUTIH.
4. Setiap ubin domino $1 \\times 2$ jika diletakkan di papan pasti menutupi TEPAT 1 kotak HITAM dan 1 kotak PUTIH.
5. Oleh karena itu, 31 ubin domino pasti menutupi tepat 31 kotak HITAM dan 31 kotak PUTIH.
6. Karena sisa papan hanya memiliki 30 kotak HITAM, terjadi kontradiksi ($30 \\neq 31$).
7. Jadi, sisa papan TIDAK BISA ditutupi oleh 31 ubin domino. \\blacksquare`,
            keyTakeaway: 'Invarian warna hitam-putih membatasi secara mutlak kemungkinan pengubinan domino.'
          }
        ]
      }
    ],
    tips: [
      'Gunakan pewarnaan papan catur untuk masalah ubin domino.',
      'Definisikan graf dengan simpul sebagai objek dan sisi sebagai hubungan antar objek.'
    ]
  },
  {
    id: 'th-geometri',
    topic: 'Geometri',
    title: 'Geometri Olimpiade: Geometri Klasik & Lingkaran',
    subtitle: 'Modul Kuliah: Teorema Ceva, Menelaus, Kuasa Titik, dan Angle Chasing',
    summary: 'Geometri IMO menuntut ketajaman analisis sudut (angle chasing), sifat segiempat siklik, dan pembuktian kekongruenan garis.',
    content: `
### 1. Pengantar Geometri Sintetis
Geometri olimpiade modern berfokus pada **konfigurasi titik-titik istimewa** pada segitiga dan lingkaran. Dua keahlian utama yang wajib dikuasai adalah *Angle Chasing* (mencari kesamaan sudut pada segiempat tali busur) dan *Cevian Concurrency* (pembuktian garis berpotongan di satu titik).

### 2. Teorema Kekongruenan Garis & Kolinearitas
#### a. Teorema Ceva (Bentuk Panjang)
Garis cevian $AD, BE, CF$ dari titik-titik sudut $\\triangle ABC$ berpotongan di satu titik (konkuren) jika dan hanya jika:
$$\\frac{BD}{DC} \\cdot \\frac{CE}{EA} \\cdot \\frac{AF}{FB} = 1$$

#### b. Teorema Menelaus
Titik $D, E, F$ berturut-turut pada garis $BC, CA, AB$ terletak pada satu garis lurus (kolinear) jika dan hanya jika:
$$\\frac{BD}{DC} \\cdot \\frac{CE}{EA} \\cdot \\frac{AF}{FB} = 1 \\quad (\\text{rasio panjang berarah } -1)$$

### 3. Kuasa Titik (Power of a Point) & Sumbu Radikal
Untuk titik $P$ dan lingkaran $\\omega$ berpusat $O$ jari-jari $R$:
$$\\text{Pow}_{\\omega}(P) = OP^2 - R^2$$
Jika garis melalui $P$ memotong $\\omega$ di $A$ dan $B$, maka $PA \\cdot PB = |OP^2 - R^2|$.
Sumbu Radikal dari dua lingkaran adalah tempat kedudukan titik-titik yang memiliki kuasa sama terhadap kedua lingkaran.

### 4. Contoh Soal Modul Terpandu
**Soal:** Buktikan bahwa ketiga garis berat (median) dari sembarang segitiga $ABC$ selalu berpotongan di satu titik (Centroid $G$).

**Langkah Solusi Lengkap:**
1. Misalkan $D, E, F$ berturut-turut adalah titik tengah sisi $BC, CA, AB$.
2. Maka $BD = DC \\implies \\frac{BD}{DC} = 1$.
3. Demikian pula $CE = EA \\implies \\frac{CE}{EA} = 1$, dan $AF = FB \\implies \\frac{AF}{FB} = 1$.
4. Hitung hasil kali ketiga rasio cevian:
   $$\\frac{BD}{DC} \\cdot \\frac{CE}{EA} \\cdot \\frac{AF}{FB} = 1 \\cdot 1 \\cdot 1 = 1$$
5. Berdasarkan Teorema Ceva, ketiga garis berat $AD, BE, CF$ terbukti berpotongan di satu titik $G$. \\blacksquare
`,
    keyTheorems: [
      {
        name: 'Teorema Ceva',
        statement: 'Tiga garis cevian berpotongan di satu titik jika dan hanya jika hasil kali rasio pembagian sisinya sama dengan 1.',
        proofOutline: 'Menggunakan perbandingan luas segitiga $\\triangle ABD / \\triangle ADC$.',
        exampleProblem: 'Buktikan bahwa ketiga garis tinggi segitiga lancip berpotongan di satu titik (Ortosenter).'
      },
      {
        name: 'Teorema Sumbu Radikal',
        statement: 'Sumbu radikal dari tiga lingkaran yang pusatnya tidak segaris berpotongan di satu titik (Pusat Radikal).',
        proofOutline: 'Sistem persamaan garis tempat kedudukan kuasa titik yang sama.',
        exampleProblem: 'Buktikan bahwa tiga tali busur persekutuan dari tiga lingkaran berpotongan di satu titik.'
      }
    ],
    tips: [
      'Cari segiempat tali busur (siklik) untuk memindahkan sudut dengan mudah.',
      'Manfaatkan Teorema Sinus untuk mengubah rasio panjang menjadi rasio sudut.'
    ],
    applicationGuide: `
#### 1. Angle Chasing (Lacak Sudut Modulo 180°)
Konstruksi segiempat siklik pembantu. Sudut keliling yang menghadap busur sama adalah kunci utama memindahkan informasi sudut ke seluruh bagian diagram.

#### 2. Identifikasi Titik Istimewa & Tali Busur Persekutuan
Cari titik potong lingkaran (titik Miquel / pusat radikal) untuk membuktikan garis-garis berpotongan di satu titik (konkuren) via Teorema Ceva atau Sumbu Radikal.

#### 3. Transformasi Koordinat Kompleks / Barycentric
Jika pendekatan sintetis sulit, tetapkan lingkaran luar sebagai lingkaran satuan $|z|=1$ pada bidang kompleks atau gunakan koordinat barisentrik untuk memverifikasi kolinearitas.
`,
    recommendedBooks: [
      {
        title: 'Euclidean Geometry in Mathematical Olympiads (EGMO)',
        author: 'Evan Chen',
        description: 'Buku standar emas geometri IMO modern. Mengupas lengkap angle chasing, kuasa titik, koordinat kompleks, barisentrik, dan inversi lingkaran.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: 'Geometry Revisited',
        author: 'H.S.M. Coxeter & S.L. Greitzer',
        description: 'Karya klasik luar biasa yang memperkenalkan keindahan geometri Euclidean, sembilan titik, Ceva, Menelaus, dan transformasi isometri.',
        level: 'Pemula & Menengah'
      },
      {
        title: '108 Geometry Problems from the AwesomeMath Year-Round Program',
        author: 'Titu Andreescu & Oleg Mushkarov',
        description: 'Pelatihan geometri olimpiade terstruktur dengan klasifikasi teknik pembuktian dari tingkat kompetisi daerah hingga IMO Shortlist.',
        level: 'Olimpiade Nasional (OSN)'
      }
    ],
    subChapters: [
      {
        id: 'sub-geo-ceva-menelaus',
        title: 'Teorema Ceva, Menelaus, & Kolinearitas Garis',
        description: 'Membahas pembuktian garis cevian berpotongan di satu titik (konkurensi) dan titik-titik terletak segaris (kolinearitas) menggunakan rasio luas dan Ceva Bentuk Sinus.',
        diagramType: 'ceva-menelaus',
        detailedContent: `
#### A. Teorema Ceva (Bentuk Rasio Panjang)
Diberikan $\\triangle ABC$ dan titik $D, E, F$ berturut-turut pada sisi $BC, CA, AB$. Garis cevian $AD, BE, CF$ berpotongan di satu titik $P$ (konkuren) jika dan hanya jika:
$$\\frac{AF}{FB} \\cdot \\frac{BD}{DC} \\cdot \\frac{CE}{EA} = 1$$

**Bukti Formal via Rasio Luas Segitiga:**
1. Perhatikan bahwa $\\frac{BD}{DC} = \\frac{[ABD]}{[ADC]} = \\frac{[PBD]}{[PDC]}$.
2. Menggunakan sifat pecahan $\\frac{u}{v} = \\frac{x}{y} = \\frac{u-x}{v-y}$, kita peroleh:
   $$\\frac{BD}{DC} = \\frac{[ABD] - [PBD]}{[ADC] - [PDC]} = \\frac{[PAB]}{[PCA]}$$
3. Secara serupa, $\\frac{CE}{EA} = \\frac{[PBC]}{[PAB]}$ dan $\\frac{AF}{FB} = \\frac{[PCA]}{[PBC]}$.
4. Mengalikan ketiga persamaan rasio ini:
   $$\\frac{AF}{FB} \\cdot \\frac{BD}{DC} \\cdot \\frac{CE}{EA} = \\frac{[PCA]}{[PBC]} \\cdot \\frac{[PAB]}{[PCA]} \\cdot \\frac{[PBC]}{[PAB]} = 1 \\quad \\blacksquare$$

#### B. Teorema Ceva Bentuk Trigonometri (Trigonometric Ceva)
Garis $AD, BE, CF$ berpotongan di satu titik jika dan hanya jika:
$$\\frac{\\sin \\angle BAD}{\\sin \\angle DAC} \\cdot \\frac{\\sin \\angle CBE}{\\sin \\angle EBA} \\cdot \\frac{\\sin \\angle ACF}{\\sin \\angle FCB} = 1$$

#### C. Teorema Menelaus untuk Kolinearitas
Titik $D$ pada $BC$, $E$ pada $AC$, dan $F$ pada $AB$ terletak pada satu garis lurus (kolinear) jika dan hanya jika:
$$\\frac{AF}{FB} \\cdot \\frac{BD}{DC} \\cdot \\frac{CE}{EA} = -1 \\quad (\\text{panjang berarah})$$
`,
        workedExamples: [
          {
            title: 'Konkurensi Garis Tinggi (Ortosenter)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Pada segitiga lancip $ABC$, garis tinggi $AD, BE, CF$ ditarik ke sisi seberang. Buktikan bahwa $AD, BE, CF$ berpotongan di satu titik $H$ (Ortosenter).',
            solutionText: `
1. Perhatikan segitiga siku-siku $\\triangle ABD$ dan $\\triangle ACD$:
   $$BD = c \\cos B, \\quad DC = b \\cos C \\implies \\frac{BD}{DC} = \\frac{c \\cos B}{b \\cos C}$$
2. Demikian pula untuk garis tinggi $BE$ dan $CF$:
   $$\\frac{CE}{EA} = \\frac{a \\cos C}{c \\cos A}, \\quad \\frac{AF}{FB} = \\frac{b \\cos A}{a \\cos B}$$
3. Kalikan ketiga rasio tersebut:
   $$\\frac{AF}{FB} \\cdot \\frac{BD}{DC} \\cdot \\frac{CE}{EA} = \\frac{b \\cos A}{a \\cos B} \\cdot \\frac{c \\cos B}{b \\cos C} \\cdot \\frac{a \\cos C}{c \\cos A} = \\frac{abc \\cos A \\cos B \\cos C}{abc \\cos A \\cos B \\cos C} = 1$$
4. Berdasarkan Teorema Ceva, $AD, BE, CF$ terbukti berpotongan di satu titik $H$. $\\blacksquare$
`,
            keyTakeaway: 'Rasio trigonometri pada segitiga siku-siku sangat efisien dikombinasikan dengan Teorema Ceva.'
          },
          {
            title: 'Kolinearitas Garis Singgung Luar (Teorema Menelaus)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Pada $\\triangle ABC$, lingkaran dalam (incircle) bersinggungan dengan $BC, CA, AB$ di $D, E, F$. Garis $EF$ memotong perpanjangan $BC$ di $P$. Buktikan bahwa $\\frac{BP}{PC} = \\frac{s-b}{s-c}$ dan $P, E, F$ kolinear dengan rasio Menelaus.',
            solutionText: `
1. Berdasarkan sifat tangen lingkaran: $AF = AE = s-a$, $BD = BF = s-b$, dan $CD = CE = s-c$.
2. Terapkan Teorema Menelaus pada $\\triangle ABC$ dengan garis transversal $P-F-E$:
   $$\\frac{AF}{FB} \\cdot \\frac{BP}{PC} \\cdot \\frac{CE}{EA} = 1$$
3. Substitusikan panjang tangen:
   $$\\frac{s-a}{s-b} \\cdot \\frac{BP}{PC} \\cdot \\frac{s-c}{s-a} = 1 \\implies \\frac{s-c}{s-b} \\cdot \\frac{BP}{PC} = 1 \\implies \\frac{BP}{PC} = \\frac{s-b}{s-c}$$
4. Ini membuktikan titik potong $P$ membagi $BC$ secara eksternal dengan rasio $(s-b)/(s-c)$. $\\blacksquare$
`,
            keyTakeaway: 'Garis transversal yang memotong 2 sisi dan perpanjangan sisi ke-3 adalah konfigurasi standar Teorema Menelaus.'
          },
          {
            title: 'Konkurensi Garis Simedian (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Garis simedian adalah cerminan dari garis berat (median) terhadap garis bagi sudut. Buktikan bahwa ketiga garis simedian dari $\\triangle ABC$ berpotongan di satu titik $K$ (Titik Lemoine).',
            solutionText: `
1. Misalkan $AD$ adalah garis berat dan $AD'$ adalah garis simedian dari sudut $A$.
2. Karena $AD'$ adalah cerminan $AD$ terhadap garis bagi sudut $A$, maka $\\angle BAD' = \\angle CAD$ dan $\\angle CAD' = \\angle BAD$.
3. Berdasarkan rumus luas segitiga, rasio Ceva Trigonometri untuk $AD'$ adalah:
   $$\\frac{\\sin \\angle BAD'}{\\sin \\angle CAD'} = \\frac{\\sin \\angle CAD}{\\sin \\angle BAD}$$
4. Menggunakan aturan sinus pada $\\triangle ABD$ dan $\\triangle ADC$ (dengan $BD = DC$):
   $$\\frac{\\sin \\angle CAD}{\\sin \\angle BAD} = \\frac{c}{b}$$
5. Maka untuk ketiga garis simedian $AD', BE', CF'$:
   $$\\frac{\\sin \\angle BAD'}{\\sin \\angle CAD'} \\cdot \\frac{\\sin \\angle CBE'}{\\sin \\angle ABE'} \\cdot \\frac{\\sin \\angle ACF'}{\\sin \\angle BCF'} = \\frac{c}{b} \\cdot \\frac{a}{c} \\cdot \\frac{b}{a} = 1$$
6. Berdasarkan Ceva Bentuk Trigonometri, ketiga garis simedian terbukti berpotongan di satu titik $K$. $\\blacksquare$
`,
            keyTakeaway: 'Teorema Ceva Trigonometri mempermudah pembuktian untuk garis-garis yang didefinisikan melalui sudut seperti simedian dan konjugat isogonal.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-geo-ceva-trig',
            title: 'Tantangan Ceva Trigonometri pada Garis Tinggi',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Pada $\\triangle ABC$ lancip, $D, E, F$ adalah kaki-kaki garis tinggi pada $BC, CA, AB$. Buktikan menggunakan Ceva Bentuk Trigonometri bahwa $AD, BE, CF$ berpotongan di satu titik.',
            hint: 'Hitung $\\sin \\angle BAD / \\sin \\angle CAD$ menggunakan segitiga siku-siku $\\triangle ABD$ dan $\\triangle ACD$.',
            solutionText: `**Solusi Lengkap:**

1. Pada $\\triangle ABD$ siku-siku di $D$: $\\angle BAD = 90^\\circ - B$.
2. Pada $\\triangle ACD$ siku-siku di $D$: $\\angle CAD = 90^\\circ - C$.
3. Maka $\\frac{\\sin \\angle BAD}{\\sin \\angle CAD} = \\frac{\\sin(90^\\circ - B)}{\\sin(90^\\circ - C)} = \\frac{\\cos B}{\\cos C}$.
4. Lakukan hal yang sama untuk garis tinggi $BE$ dan $CF$:
   $$\\frac{\\sin \\angle CBE}{\\sin \\angle ABE} = \\frac{\\cos C}{\\cos A}, \\quad \\frac{\\sin \\angle ACF}{\\sin \\angle BCF} = \\frac{\\cos A}{\\cos B}$$
5. Kalikan ketiga rasio trigonometri:
   $$\\frac{\\cos B}{\\cos C} \\cdot \\frac{\\cos C}{\\cos A} \\cdot \\frac{\\cos A}{\\cos B} = 1$$
6. Berdasarkan Ceva Trigonometri, $AD, BE, CF$ terbukti konkuren di Ortosenter $H$. \\blacksquare`,
            keyTakeaway: 'Ceva Trigonometri sangat fleksibel untuk cevian yang ditentukan oleh sudut interior.'
          }
        ]
      },
      {
        id: 'sub-geo-cyclic-quad',
        title: 'Segiempat Siklik, Angle Chasing, & Teorema Ptolemy',
        description: 'Menganalisis sifat sudut keliling yang menghadap busur sama, segiempat tali busur (siklik), dan pertidaksamaan Ptolemy.',
        diagramType: 'cyclic-quad',
        detailedContent: `
#### A. Syarat-Syarat Segiempat Siklik
Empat titik $A, B, C, D$ terletak pada satu lingkaran (siklik) jika dan hanya jika memenuhi salah satu dari syarat ekuivalen berikut:
1. **Sudut Keliling Menghadap Busur Sama:** $\\angle ABD = \\angle ACD$.
2. **Sudut Berhadapan Saling Berpelurus:** $\\angle A + \\angle C = 180^\\circ$ atau $\\angle B + \\angle D = 180^\\circ$.
3. **Sudut Luar Sama dengan Sudut Dalam Berhadapan:** Sudut luar di $C$ sama dengan $\\angle A$.
4. **Kuasa Titik Potong Diagonal:** Jika diagonal $AC$ dan $BD$ berpotongan di $P$, maka $PA \\cdot PC = PB \\cdot PD$.

#### B. Teorema Ptolemy
Untuk segiempat siklik $ABCD$ dengan panjang sisi $a, b, c, d$ dan diagonal $p, q$:
$$p \\cdot q = a c + b d \\quad \\iff \\quad AC \\cdot BD = AB \\cdot CD + AD \\cdot BC$$
*Pertidaksamaan Ptolemy:* Untuk 4 titik acak pada bidang, $AC \\cdot BD \\le AB \\cdot CD + AD \\cdot BC$, dengan kesamaan jika dan hanya jika $ABCD$ siklik.
`,
        workedExamples: [
          {
            title: 'Angle Chasing pada Tiga Lingkaran',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Diberikan segiempat siklik $ABCD$. Garis $AB$ dan $DC$ berpotongan di $E$. Buktikan bahwa $\\triangle EAD \\sim \\triangle ECB$.',
            solutionText: `
1. Karena $ABCD$ segiempat siklik, sudut berhadapan $\\angle ABC + \\angle ADC = 180^\\circ$.
2. Karena $E, D, C$ segaris, sudut lurus $\\angle EDC + \\angle EDA = 180^\\circ \\implies \\angle EDA = 180^\\circ - \\angle ADC = \\angle ABC = \\angle EBC$.
3. Perhatikan $\\triangle EAD$ dan $\\triangle ECB$:
   - $\\angle E$ adalah sudut bersama (common angle).
   - $\\angle EDA = \\angle EBC$ (dari langkah 2).
4. Berdasarkan kriteria sudut-sudut (AA similarity), terbukti $\\triangle EAD \\sim \\triangle ECB$. $\\blacksquare$
`,
            keyTakeaway: 'Segiempat siklik mengubah sudut luar menjadi sudut dalam berhadapan, memicu kesebangunan segitiga secara instan.'
          },
          {
            title: 'Pembuktian Garis Simson (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Diberikan titik $P$ pada lingkaran luar $\\triangle ABC$. Misalkan $D, E, F$ adalah proyeksi tegak lurus $P$ pada sisi $BC, CA, AB$. Buktikan bahwa $D, E, F$ terletak pada satu garis lurus (Garis Simson).',
            solutionText: `
1. Karena $\\angle PEA = \\angle PFA = 90^\\circ$, segiempat $AFPE$ adalah siklik pada lingkaran berdiameter $AP$. Maka $\\angle AFE = \\angle APE$.
2. Karena $\\angle PDC = \\angle PEC = 90^\\circ$, segiempat $CDPE$ adalah siklik pada lingkaran berdiameter $PC$. Maka $\\angle CDE = \\angle CPE$.
3. Karena $A, B, C, P$ siklik pada lingkaran luar segitiga, $\\angle PAC = \\angle PBC$.
4. Dari $\\triangle APE$ dan $\\triangle BPF$ siku-siku: $\\angle APE = 90^\\circ - \\angle PAC = 90^\\circ - \\angle PBC = \\angle BPF$.
5. Gabungkan kesamaan sudut tersebut untuk membuktikan $\\angle BFD + \\angle AFE = 180^\\circ$, sehingga $D, E, F$ terbukti kolinear. $\\blacksquare$
`,
            keyTakeaway: 'Membuktikan segiempat-segiempat pembantu siklik adalah kunci utama metode Angle Chasing.'
          },
          {
            title: 'Aplikasi Teorema Ptolemy pada Pentagon Reguler (IMO)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Diberikan segi-5 beraturan $ABCDE$ dengan panjang sisi $s$ dan panjang diagonal $d$. Buktikan bahwa $\\frac{d}{s} = \\frac{1 + \\sqrt{5}}{2}$ (Rasio Emas / Golden Ratio).',
            solutionText: `
1. Empat titik $A, B, C, D$ terletak pada lingkaran luar segi-5 beraturan, sehingga $ABCD$ membentuk segiempat siklik.
2. Panjang sisi $AB = BC = CD = s$.
3. Panjang diagonal $AC = BD = AD = d$.
4. Terapkan Teorema Ptolemy pada segiempat siklik $ABCD$:
   $$AC \\cdot BD = AB \\cdot CD + AD \\cdot BC \\implies d \\cdot d = s \\cdot s + d \\cdot s \\implies d^2 = s^2 + d s$$
5. Bagi kedua ruas dengan $s^2$ dan misalkan $x = d/s$:
   $$x^2 - x - 1 = 0$$
6. Gunakan rumus kuadratik untuk nilai $x > 0$:
   $$x = \\frac{1 + \\sqrt{5}}{2} = \\phi \\quad \\blacksquare$$
`,
            keyTakeaway: 'Teorema Ptolemy menghubungkan panjang diagonal dan sisi pada poligon siklik beraturan.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-geo-ptolemy-equilateral',
            title: 'Tantangan Ptolemy pada Segitiga Sama Sisi',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Diberikan segitiga sama sisi $ABC$ dan titik $P$ pada busur kecil $BC$ dari lingkaran luarnya. Buktikan bahwa $PA = PB + PC$.',
            hint: 'Terapkan Teorema Ptolemy pada segiempat siklik $ABPC$ dengan panjang sisi $AB = BC = CA = s$.',
            solutionText: `**Solusi Lengkap:**

1. Karena $P$ pada busur $BC$ dari lingkaran luar $\\triangle ABC$, empat titik $A, B, P, C$ membentuk segiempat siklik $ABPC$.
2. Panjang sisi segitiga sama sisi: $AB = BC = CA = s$.
3. Terapkan Teorema Ptolemy pada segiempat siklik $ABPC$:
   $$PA \\cdot BC = PB \\cdot AC + PC \\cdot AB$$
4. Substitusikan $BC = AC = AB = s$:
   $$PA \\cdot s = PB \\cdot s + PC \\cdot s$$
5. Karena $s > 0$, bagi kedua ruas dengan $s$:
   $$PA = PB + PC \\quad \\blacksquare$$`,
            keyTakeaway: 'Teorema Ptolemy langsung menyederhanakan hubungan jarak pada lingkaran luar segitiga sama sisi.'
          }
        ]
      },
      {
        id: 'sub-geo-power-of-point',
        title: 'Kuasa Titik (Power of a Point) & Sumbu Radikal',
        description: 'Mempelajari besaran konstan kuasa titik terhadap lingkaran, sumbu radikal dua lingkaran, dan titik radikal tiga lingkaran.',
        diagramType: 'power-of-point',
        detailedContent: `
#### A. Teorema Kuasa Titik (Power of a Point Theorem)
Diberikan lingkaran $\\omega$ berpusat $O$ dengan jari-jari $R$, dan titik $P$.
Kuasa titik $P$ terhadap $\\omega$ didefinisikan sebagai:
$$\\text{Pow}_{\\omega}(P) = OP^2 - R^2$$

**Tiga Kasus Kuasa Titik:**
1. **Garis Potong (Secant Lines):** Jika dua garis melalui $P$ memotong $\\omega$ di $(A, B)$ dan $(C, D)$, maka:
   $$PA \\cdot PB = PC \\cdot PD = |OP^2 - R^2|$$
2. **Garis Singgung (Tangent Line):** Jika $PT$ bersinggungan dengan $\\omega$ di $T$, maka:
   $$PT^2 = PA \\cdot PB = OP^2 - R^2$$
3. **Titik Dalam Lingkaran:** Jika $P$ di dalam lingkaran, $PA \\cdot PB = R^2 - OP^2$.

#### B. Sumbu Radikal & Pusat Radikal
- **Sumbu Radikal:** Tempat kedudukan titik-titik $X$ yang memiliki kuasa sama terhadap dua lingkaran $\\omega_1, \\omega_2$. Sumbu radikal selalu berupa **garis lurus** yang **tegak lurus** terhadap garis yang menghubungkan kedua pusat lingkaran $O_1 O_2$.
- **Pusat Radikal:** Diberikan 3 lingkaran dengan pusat tidak segaris. Sumbu radikal dari ketiga pasang lingkaran tersebut berpotongan di **satu titik tunggal** (Pusat Radikal).
`,
        workedExamples: [
          {
            title: 'Menghitung Kuasa Titik pada Lingkaran (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Titik $P$ berjarak $13$ cm dari pusat lingkaran $\\omega$ yang berjari-jari $5$ cm. Garis secant melalui $P$ memotong lingkaran di $A$ dan $B$. Jika $PA = 9$ cm, hitung panjang $AB$.',
            solutionText: `
1. Hitung kuasa titik $P$ terhadap lingkaran $\\omega$:
   $$\\text{Pow}_{\\omega}(P) = OP^2 - R^2 = 13^2 - 5^2 = 169 - 25 = 144$$
2. Berdasarkan Teorema Kuasa Titik:
   $$PA \\cdot PB = \\text{Pow}_{\\omega}(P) = 144$$
3. Karena $PA = 9$, maka $9 \\cdot PB = 144 \\implies PB = 16$ cm.
4. Karena $A$ dan $B$ pada sinar $PB$, maka $PB = PA + AB \\implies 16 = 9 + AB \\implies AB = 7$ cm. $\\blacksquare$
`,
            keyTakeaway: 'Kuasa titik memberikan hubungan perkalian segmen garis secant tanpa perlu mengetahui sudut.'
          },
          {
            title: 'Pembuktian Titik Radikal Tiga Lingkaran (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Tiga lingkaran $\\omega_1, \\omega_2, \\omega_3$ saling memotong. Tali busur persekutuan $\\omega_1 \\cap \\omega_2$ adalah $L_1$, $\\omega_2 \\cap \\omega_3$ adalah $L_2$, dan $\\omega_3 \\cap \\omega_1$ adalah $L_3$. Buktikan bahwa $L_1, L_2, L_3$ berpotongan di satu titik $K$.',
            solutionText: `
1. Garis $L_1$ adalah tali busur persekutuan $\\omega_1$ dan $\\omega_2$, sehingga setiap titik di $L_1$ memiliki kuasa sama terhadap $\\omega_1$ dan $\\omega_2$. Maka $L_1$ adalah sumbu radikal $\\omega_1, \\omega_2$.
2. Demikian pula $L_2$ adalah sumbu radikal $\\omega_2, \\omega_3$, dan $L_3$ adalah sumbu radikal $\\omega_3, \\omega_1$.
3. Misalkan $K$ adalah titik potong $L_1$ dan $L_2$:
   - Karena $K \\in L_1 \\implies \\text{Pow}_{\\omega_1}(K) = \\text{Pow}_{\\omega_2}(K)$.
   - Karena $K \\in L_2 \\implies \\text{Pow}_{\\omega_2}(K) = \\text{Pow}_{\\omega_3}(K)$.
4. Dari transitivitas kesamaan: $\\text{Pow}_{\\omega_1}(K) = \\text{Pow}_{\\omega_3}(K)$.
5. Ini berarti $K$ terletak pada sumbu radikal $L_3$.
6. Terbukti ketiga tali busur persekutuan berpotongan di satu titik $K$ (Pusat Radikal). $\\blacksquare$
`,
            keyTakeaway: 'Sumbu radikal adalah teknik geometris terkuat untuk membuktikan perpotongan 3 garis tali busur.'
          },
          {
            title: 'Konstruksi Kuasa Titik pada Soal IMO Shortlist',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Pada $\\triangle ABC$, $AD$ adalah garis tinggi. Lingkaran berdiameter $AB$ dan $AC$ memotong $AD$ berturut-turut di $P$ dan $Q$. Buktikan bahwa $AD$ adalah sumbu radikal kedua lingkaran dan hitung posisi $P$ dan $Q$.',
            solutionText: `
1. Misalkan $\\omega_1$ adalah lingkaran berdiameter $AB$ dan $\\omega_2$ berdiameter $AC$.
2. Karena $\\angle ADB = 90^\\circ$, titik $D$ terletak pada $\\omega_1$.
3. Karena $\\angle ADC = 90^\\circ$, titik $D$ juga terletak pada $\\omega_2$.
4. Jadi $D$ adalah titik potong kedua lingkaran $\\omega_1 \\cap \\omega_2$.
5. Titik $A$ jelas terletak pada kedua lingkaran.
6. Maka garis $AD$ adalah tali busur persekutuan dari $\\omega_1$ dan $\\omega_2$, yang otomatis merupakan sumbu radikalnya.
7. Oleh karena itu, untuk sembarang titik $X \\in AD$, kuasanya terhadap $\\omega_1$ dan $\\omega_2$ adalah sama. $\\blacksquare$
`,
            keyTakeaway: 'Lingkaran berdiameter sisi segitiga selalu memotong kaki garis tinggi karena sudut siku-siku Thales.'
          }
        ],
        challengeProblems: [
          {
            id: 'ch-geo-power-tangent',
            title: 'Tantangan Garis Singgung Persekutuan Dua Lingkaran',
            difficultyLabel: 'Tantangan OSN-P',
            problemText: 'Dua lingkaran $\\omega_1$ dan $\\omega_2$ saling bersinggungan luar di titik $T$. Garis singgung persekutuan luar menyentuh $\\omega_1$ di $A$ dan $\\omega_2$ di $B$. Buktikan bahwa garis singgung persekutuan dalam melalui $T$ membagi dua segmen $AB$.',
            hint: 'Misalkan garis singgung persekutuan dalam memotong $AB$ di titik $P$. Gunakan sifat panjang segmen garis singgung dari titik $P$ ke lingkaran.',
            solutionText: `**Solusi Lengkap:**

1. Misalkan garis singgung persekutuan dalam melalui $T$ memotong segmen $AB$ di titik $P$.
2. Perhatikan titik $P$:
   - $PA$ adalah garis singgung dari $P$ ke lingkaran $\\omega_1$.
   - $PT$ adalah garis singgung dari $P$ ke lingkaran $\\omega_1$.
   - Maka $PA = PT$.
3. Perhatikan lingkaran $\\omega_2$:
   - $PB$ adalah garis singgung dari $P$ ke lingkaran $\\omega_2$.
   - $PT$ adalah garis singgung dari $P$ ke lingkaran $\\omega_2$.
   - Maka $PB = PT$.
4. Dari $PA = PT$ dan $PB = PT$, kita peroleh $PA = PB$.
5. Ini membuktikan bahwa $P$ adalah titik tengah segmen $AB$. \\blacksquare`,
            keyTakeaway: 'Sifat kesamaan panjang dua segmen garis singgung dari satu titik luar adalah teorema paling fundamental pada lingkaran.'
          }
        ]
      },
      {
        id: 'sub-geo-incircle-excircle',
        title: 'Lingkaran Dalam (Incircle), Lingkaran Luar, & Tangency',
        description: 'Menganalisis sifat-sifat Incenter $I$, Inradius $r$, Excenters $I_A, I_B, I_C$, panjang segmen tangen, dan Rumus Jarak Euler $OI^2 = R^2 - 2Rr$.',
        diagramType: 'incircle-excircle',
        detailedContent: `
#### A. Parameter Utama Lingkaran Dalam & Luar
Untuk $\\triangle ABC$ dengan panjang sisi $a, b, c$, setengah keliling $s = \\frac{a+b+c}{2}$, dan luas $K$:
1. **Jari-Jari Lingkaran Dalam (Inradius):** $r = \\frac{K}{s} = \\sqrt{\\frac{(s-a)(s-b)(s-c)}{s}}$.
2. **Panjang Segmen Tangen:** Misalkan incircle bersinggungan dengan $BC, CA, AB$ di $D, E, F$:
   $$AF = AE = s - a, \\quad BD = BF = s - b, \\quad CD = CE = s - c$$
3. **Jari-Jari Lingkaran Singgung Luar (Exradius):**
   $$r_a = \\frac{K}{s-a}, \\quad r_b = \\frac{K}{s-b}, \\quad r_c = \\frac{K}{s-c}$$
   *Identitas Kunci:* $\\frac{1}{r} = \\frac{1}{r_a} + \\frac{1}{r_b} + \\frac{1}{r_c}$.

#### B. Rumus Jarak Euler
Jarak antara Pusat Lingkaran Luar $O$ dan Pusat Lingkaran Dalam $I$ memenuhi:
$$OI^2 = R^2 - 2 R r$$
*Ketaksamaan Euler:* $R \\ge 2r$, dengan kesamaan jika dan hanya jika segitiga sama sisi.
`,
        workedExamples: [
          {
            title: 'Menghitung Jari-Jari Lingkaran Dalam (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Diberikan segitiga dengan panjang sisi $13, 14, 15$. Hitung jari-jari lingkaran dalam $r$ dan jari-jari lingkaran luar $R$.',
            solutionText: `
1. Hitung setengah keliling $s$:
   $$s = \\frac{13 + 14 + 15}{2} = 21$$
2. Hitung luas $K$ menggunakan Rumus Heron:
   $$K = \\sqrt{s(s-a)(s-b)(s-c)} = \\sqrt{21 \\cdot (21-13) \\cdot (21-14) \\cdot (21-15)} = \\sqrt{21 \\cdot 8 \\cdot 7 \\cdot 6} = 84$$
3. Hitung inradius $r$:
   $$r = \\frac{K}{s} = \\frac{84}{21} = 4$$
4. Hitung circumradius $R$:
   $$R = \\frac{a b c}{4 K} = \\frac{13 \\cdot 14 \\cdot 15}{4 \\cdot 84} = \\frac{2730}{336} = \\frac{65}{8} = 8.125 \\quad \\blacksquare$$
`,
            keyTakeaway: 'Rumus Heron dan rasio luas adalah pondasi kalkulasi metrik segitiga.'
          },
          {
            title: 'Titik Singgung Excircle & Sisi Segitiga (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Misalkan $D$ adalah titik singgung incircle pada $BC$, dan $D\'$ adalah titik singgung $A$-excircle pada $BC$. Buktikan bahwa $BD = CD\' = s - b$ dan $D, D\'$ simetris terhadap titik tengah $BC$.',
            solutionText: `
1. Misalkan $A$-excircle bersinggungan dengan perpanjangan $AB$ di $X$ dan $AC$ di $Y$.
2. Berdasarkan sifat tangen dari $A$: $AX = AY$.
3. Keliling $\\triangle ABC = AB + BC + CA = AB + (BD' + D'C) + CA = (AB + BX) + (AC + CY) = AX + AY = 2 AX$.
4. Maka $AX = s \\implies BX = s - c$.
5. Karena $BD' = BX = s - c$, dan $CD' = BC - BD' = a - (s - c) = s - b$.
6. Ingat bahwa titik singgung incircle $D$ memberikan $BD = s - b$.
7. Maka $BD = CD\' = s - b$, sehingga $D$ dan $D\'$ simetris terhadap titik tengah $BC$. $\\blacksquare$
`,
            keyTakeaway: 'Incircle dan Excircle membagi sisi segitiga secara simetris terhadap titik tengahnya.'
          },
          {
            title: 'Pembuktian Ketaksamaan Euler $R \\ge 2r$ (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Gunakan Rumus Jarak Euler $OI^2 = R^2 - 2Rr$ untuk membuktikan bahwa $R \\ge 2r$ pada sembarang segitiga.',
            solutionText: `
1. Diketahui bahwa jarak kuadrat antara dua titik nyata pada bidang Euclidean tidak mungkin negatif:
   $$OI^2 \\ge 0$$
2. Substitusikan Rumus Jarak Euler ke dalam pertidaksamaan:
   $$R^2 - 2 R r \\ge 0$$
3. Karena $R > 0$ (jari-jari lingkaran luar selalu positif), bagi kedua ruas dengan $R$:
   $$R - 2r \\ge 0 \\implies R \\ge 2r$$
4. Kesamaan $OI^2 = 0 \\iff O = I$. Pusat lingkaran luar dan dalam berimpit jika dan hanya jika segitiga tersebut sama sisi (equilateral). $\\blacksquare$
`,
            keyTakeaway: 'Rumus Euler $OI^2 = R^2 - 2Rr$ memberikan bukti terpendek dan paling elegan untuk ketaksamaan $R \\ge 2r$.'
          }
        ]
      },
      {
        id: 'sub-geo-euler-line',
        title: 'Garis Euler, Ortosenter, & Lingkaran 9 Titik',
        description: 'Mempelajari hubungan segaris (kolinearitas) Pusat $O, G, N, H$ pada Garis Euler dan sifat Lingkaran Sembilan Titik (Feuerbach).',
        diagramType: 'euler-line',
        detailedContent: `
#### A. Garis Euler (Euler Line)
Pada sembarang segitiga tak-sama sisi, **Pusat Lingkaran Luar $O$**, **Titik Berat (Centroid) $G$**, **Pusat Lingkaran Sembilan Titik $N$**, dan **Ortosenter $H$** terletak pada satu garis lurus yang sama (Garis Euler).

**Hubungan Rasio Panjang Kolinear:**
$$OG : GH = 1 : 2 \\implies HG = 2 \\cdot GO$$
$$N \\text{ adalah titik tengah segmen } OH \\implies ON = NH = \\frac{1}{2} OH$$

#### B. Lingkaran Sembilan Titik (Nine-Point Circle)
Lingkaran Sembilan Titik dari $\\triangle ABC$ melintasi 9 titik khusus berikut:
1. **3 Titik Tengah Sisi:** Titik tengah $BC, CA, AB$.
2. **3 Kaki Garis Tinggi:** Kaki garis tinggi dari $A, B, C$ pada $BC, CA, AB$.
3. **3 Titik Euler:** Titik tengah segmen $AH, BH, CH$ (antara Ortosenter dan titik sudut).

*Sifat Kunci Lingkaran 9 Titik:*
- Pusatnya $N$ adalah titik tengah $OH$.
- Jari-jarinya $R_N = \\frac{1}{2} R$ (setengah dari jari-jari lingkaran luar segitiga).
- **Teorema Feuerbach:** Lingkaran Sembilan Titik bersinggungan dalam dengan Incircle dan bersinggungan luar dengan ketiga Excircles!
`,
        workedExamples: [
          {
            title: 'Kolinearitas Titik-Titik Euler (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Pada $\\triangle ABC$, $O$ adalah pusat lingkaran luar dan $H$ adalah ortosenter. Jika jarak $OH = 12$ cm, hitung jarak $OG$ (di mana $G$ adalah centroid) dan jarak $ON$ (di mana $N$ pusat sembilan titik).',
            solutionText: `
1. Berdasarkan Teorema Garis Euler, $O, G, N, H$ segaris dalam urutan $O - G - N - H$.
2. Rasio titik berat membagi $OH$ dengan rasio $OG : GH = 1 : 2$.
   $$OG = \\frac{1}{1 + 2} \\cdot OH = \\frac{1}{3} \\cdot 12 = 4 \\text{ cm}$$
3. Titik $N$ (pusat lingkaran sembilan titik) adalah titik tengah segmen $OH$:
   $$ON = \\frac{1}{2} \\cdot OH = \\frac{1}{2} \\cdot 12 = 6 \\text{ cm} \\quad \\blacksquare$$
`,
            keyTakeaway: 'Rasio konstan $OG : GH = 1 : 2$ dan $N$ sebagai titik tengah $OH$ mempermudah kalkulasi jarak Euler.'
          },
          {
            title: 'Pembuktian Lingkaran 9 Titik Melalui Dilatasi (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Buktikan bahwa jari-jari lingkaran sembilan titik sama dengan setengah dari jari-jari lingkaran luar $R_N = \\frac{1}{2} R$ menggunakan dilatasi (homoteti).',
            solutionText: `
1. Pertimbangkan homoteti $h$ berpusat di Centroid $G$ dengan faktor skala $k = -1/2$.
2. Homoteti ini memetakan setiap titik sudut $A, B, C$ ke titik tengah sisi seberangnya $M_a, M_b, M_c$.
3. Oleh karena itu, homoteti ini memetakan lingkaran luar $\\Omega$ (berpusat di $O$, jari-jari $R$) ke lingkaran baru $\\Omega'$ yang melalui ketiga titik tengah sisi $M_a, M_b, M_c$.
4. Lingkaran $\\Omega'$ ini tidak lain adalah Lingkaran Sembilan Titik!
5. Karena faktor skala dilatasi adalah $|k| = 1/2$, maka jari-jari Lingkaran Sembilan Titik adalah:
   $$R_N = |k| \\cdot R = \\frac{1}{2} R \\quad \\blacksquare$$
`,
            keyTakeaway: 'Dilatasi berpusat di Centroid $G$ dengan rasio $-1/2$ secara ajaib memetakan Lingkaran Luar ke Lingkaran Sembilan Titik.'
          },
          {
            title: 'Persamaan Jarak Euler Kompleks (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Sajikan pembuktian analitik koordinat kompleks untuk vektor posisi Ortosenter $h = a + b + c$ jika Lingkaran Luar ditetapkan sebagai Lingkaran Satuan berpusat di asal ($o = 0$).',
            solutionText: `
1. Setel lingkaran luar $\\triangle ABC$ sebagai lingkaran satuan $|a| = |b| = |c| = 1$, dengan pusat $o = 0$.
2. Maka konjugat kompleksnya memenuhi $\\bar{a} = 1/a, \\bar{b} = 1/b, \\bar{c} = 1/c$.
3. Vektor posisi titik berat $G$ adalah $g = \\frac{a + b + c}{3}$.
4. Karena Garis Euler menyatakan $h - o = 3(g - o)$ dengan $o = 0$:
   $$h = 3 g = 3 \\cdot \\frac{a + b + c}{3} = a + b + c$$
5. Untuk membuktikan $H$ adalah ortosenter, kita harus memeriksa ketegaklurusan $AH \\perp BC$:
   $$\\frac{h - a}{b - c} = \\frac{b + c}{b - c}$$
6. Hitung konjugat kompleks dari rasio ini:
   $$\\overline{\\left(\\frac{b + c}{b - c}\\right)} = \\frac{\\bar{b} + \\bar{c}}{\\bar{b} - \\bar{c}} = \\frac{1/b + 1/c}{1/b - 1/c} = \\frac{(c + b)/(bc)}{(c - b)/(bc)} = \\frac{b + c}{c - b} = -\\frac{b + c}{b - c}$$
7. Karena rasio ini bernilai imajiner murni ($\\bar{z} = -z$), maka garis $AH \\perp BC$.
8. Terbukti $h = a + b + c$ adalah representasi kompleks ortosenter $H$. $\\blacksquare$
`,
            keyTakeaway: 'Trik Lingkaran Satuan Kompleks mengubah pembuktian geometri klasik menjadi manipulasi aljabar pecahan sederhana.'
          }
        ]
      },
      {
        id: 'sub-geo-miquel-theorem',
        title: 'Teorema Miquel (Pivot Theorem) & Titik Miquel',
        description: 'Menganalisis perpotongan tiga lingkaran luar pembantu di satu titik Miquel M dan aplikasinya pada geometri olimpiade.',
        diagramType: 'miquel-theorem',
        detailedContent: `
#### A. Pernyataan Teorema Pivot Miquel
Diberikan $\\triangle ABC$ dan tiga titik $D, E, F$ berturut-turut pada sisi $BC, CA, AB$. Tiga lingkaran luar $\\Omega_1 = \\triangle AEF$, $\\Omega_2 = \\triangle BFD$, dan $\\Omega_3 = \\triangle CDE$ selalu berpotongan di satu titik tunggal $M$ yang disebut **Titik Miquel (Miquel Point)**.

#### B. Sifat-Sifat Penting Titik Miquel $M$
1. **Titik Tunggal Konkuren:** Perpotongan ketiga lingkaran $\\Omega_1, \\Omega_2, \\Omega_3$ selalu tunggal untuk sembarang posisi $D, E, F$ pada sisi segitiga.
2. **Keserupaan Spiral (Spiral Similarity):** Titik $M$ berfungsi sebagai pusat keserupaan spiral yang memetakan $\\triangle AEF$ ke $\\triangle BFD$ dan $\\triangle CDE$.
3. **Segiempat Siklik Pembantu:** $AFME$, $BDMF$, dan $CEMD$ ketiganya adalah segiempat tali busur (siklik).
`,
        workedExamples: [
          {
            title: 'Pembuktian Konkurensi Lingkaran Miquel (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Diberikan $\\triangle ABC$ dan titik $D, E, F$ pada $BC, CA, AB$. Misalkan lingkaran luar $\\triangle AEF$ dan $\\triangle BFD$ berpotongan di $M \\neq F$. Buktikan bahwa $M$ juga terletak pada lingkaran luar $\\triangle CDE$.',
            solutionText: `
1. Karena $AFME$ segiempat siklik: $\\angle AME = 180^\circ - \\angle A$.
2. Karena $BDMF$ segiempat siklik: $\\angle BMD = 180^\circ - \\angle B$.
3. Jumlah sudut di sekitar titik $M$: $\\angle DME = 360^\circ - (\\angle AME + \\angle BMD + \\angle EMF)$.
4. Lakukan angle chasing: $\\angle DME = 180^\circ - \\angle C$.
5. Karena $\\angle DME + \\angle C = 180^\circ$, maka $CEMD$ adalah segiempat siklik.
6. Terbukti $M$ terletak pada lingkaran luar $\\triangle CDE$. $\\blacksquare$
`,
            keyTakeaway: 'Angle chasing sederhana pada dua segiempat siklik membuktikan keberadaan Titik Miquel.'
          },
          {
            title: 'Aplikasi Titik Miquel pada OSN SMA 2023 Problem 2',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN 2023)',
            problemText: 'Diberikan $\\triangle ABC$ dengan lingkar luar $\\omega$. Garis sejajar $AB$ melalui $D \\in BC$ memotong $AC$ di $E$. Lingkaran luar $\\triangle CDE$ memotong $\\omega$ kembali di $P$. Buktikan bahwa $\\angle APB = \\angle DPE$.',
            solutionText: `
1. $ABCP$ siklik pada $\\omega \implies \\angle APB = \\angle ACB = \\angle C$.
2. $CDEP$ siklik pada lingkaran luar $\\triangle CDE \implies \\angle DPE = \\angle DCE = \\angle C$.
3. Maka $\\angle APB = \\angle DPE = \\angle C$. $\\blacksquare$
`,
            keyTakeaway: 'Sifat sudut keliling pada dua lingkaran berpotongan langsung menyelesaikan soal OSN.'
          },
          {
            title: 'Miquel Point & Pusat Inversi (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Buktikan bahwa jika $D, E, F$ kolinear (garis Menelaus), maka Titik Miquel $M$ terletak pada lingkaran luar $\\triangle ABC$.',
            solutionText: `
1. Jika $D, E, F$ kolinear, maka $A, B, C, D, E, F$ membentuk complete quadrilateral.
2. Keempat lingkaran luar segitiga $\\triangle AEF, \\triangle BFD, \\triangle CDE, \\triangle ABC$ semuanya berpotongan di satu titik $M$ (Miquel Point of Complete Quadrilateral).
3. Terbukti $M$ terletak pada lingkaran luar $\\triangle ABC$. $\\blacksquare$
`,
            keyTakeaway: 'Complete quadrilateral memiliki Miquel point yang berada di lingkaran luar segitiga utama.'
          }
        ]
      },
      {
        id: 'sub-geo-simson-line',
        title: 'Garis Simson & Proyeksi Tegak Lurus Titik Lingkaran Luar',
        description: 'Membuktikan bahwa proyeksi ortogonal titik P pada lingkaran luar segitiga ke ketiga sisinya selalu membentuk satu garis lurus.',
        diagramType: 'simson-line',
        detailedContent: `
#### A. Teorema Garis Simson (Simson Line Theorem)
Misalkan $P$ adalah titik pada lingkaran luar $\\triangle ABC$. Kaki-kaki garis tegak lurus dari $P$ ke garis $BC, CA, AB$ (berturut-turut $X, Y, Z$) selalu **terletak pada satu garis lurus** (Garis Simson dari $P$ terhadap $\\triangle ABC$).

#### B. Kebalikan Teorema Simson
Jika proyeksi ortogonal titik $P$ ke ketiga sisi segitiga $ABC$ kolinear, maka $P$ **harus terletak pada lingkaran luar** $\\triangle ABC$.
`,
        workedExamples: [
          {
            title: 'Pembuktian Garis Simson via Angle Chasing (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Buktikan bahwa kaki proyeksi $X, Y, Z$ dari $P$ pada lingkaran luar $\\triangle ABC$ segaris.',
            solutionText: `
1. Segiempat $PYCZ$ dan $PXBY$ siklik karena sudut-sudut siku-siku $90^\circ$.
2. $\\angle CYX = \\angle CPX$ dan $\\angle AYZ = \\angle APZ$.
3. Karena $ABCP$ siklik, $\\angle CPB = 180^\circ - \\angle A$.
4. Angle chasing menunjukkan $\\angle XYZ = 180^\circ$, sehingga $X, Y, Z$ segaris. $\\blacksquare$
`,
            keyTakeaway: 'Angle chasing pada 2 segiempat siklik turunan membuktikan kolinearitas garis Simson.'
          },
          {
            title: 'Properti Sudut Antara Dua Garis Simson (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Diberikan dua titik $P, Q$ pada lingkaran luar $\\triangle ABC$. Buktikan bahwa sudut antara Garis Simson $P$ dan Garis Simson $Q$ sama dengan setengah sudut busur $PQ$.',
            solutionText: `
1. Letak Garis Simson berubah secara linier terhadap rotasi $P$ pada lingkaran luar.
2. Sudut rotasi garis Simson adalah $\\frac{1}{2} \\angle POQ = \\frac{1}{2} \\widehat{PQ}$. $\\blacksquare$
`,
            keyTakeaway: 'Sudut arah garis Simson berotasi dengan setengah kecepatan sudut rotasi titik P.'
          },
          {
            title: 'Garis Simson Membagi Dua Segmen Ortosenter (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Buktikan bahwa Garis Simson dari titik $P$ membagi dua (bisects) segmen garis $PH$, di mana $H$ adalah ortosenter $\\triangle ABC$.',
            solutionText: `
1. Refleksikan $P$ terhadap ketiga sisi $BC, CA, AB$ menghasilkan $P_1, P_2, P_3$.
2. $P_1, P_2, P_3$ kolinear pada garis refleks Simson.
3. Garis ini melalui Ortosenter $H$. Maka Garis Simson membagi dua segmen $PH$ di Lingkaran 9 Titik. $\\blacksquare$
`,
            keyTakeaway: 'Titik tengah segmen PH selalu terletak pada Garis Simson dan Lingkaran 9 Titik.'
          }
        ]
      },
      {
        id: 'sub-geo-pascal-theorem',
        title: 'Teorema Pascal (Hexagrammum Mysticum)',
        description: 'Membuktikan bahwa titik potong tiga pasang sisi berhadapan dari segi-6 pada konik/lingkaran selalu kolinear (Garis Pascal).',
        diagramType: 'pascal-theorem',
        detailedContent: `
#### A. Pernyataan Teorema Pascal
Diberikan 6 titik $P_1, P_2, P_3, P_4, P_5, P_6$ pada suatu irisan kerucut (konik / lingkaran). Tiga titik potong dari pasang sisi berhadapan:
$$X = P_1 P_2 \\cap P_4 P_5, \\quad Y = P_2 P_3 \\cap P_5 P_6, \\quad Z = P_3 P_4 \\cap P_6 P_1$$
selalu **terletak pada satu garis lurus** (Garis Pascal / Pascal Line).

#### B. Teorema Brianchon (Dual dari Pascal)
Jika segi-6 memuat lingkaran dalam (incircle), ketiga diagonal utamanya memotong di satu titik tunggal (konkuren).
`,
        workedExamples: [
          {
            title: 'Aplikasi Teorema Pascal pada Lingkaran (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Diberikan titik $A, B, C, D, E, F$ pada lingkaran. Tunjukkan bahwa perpotongan $AB \\cap DE$, $BC \\cap EF$, dan $CD \\cap FA$ kolinear.',
            solutionText: `
1. Terapkan Teorema Pascal langsung pada segi-6 $ABCDEF$ yang terinscribsi dalam lingkaran.
2. Titik potong $X = AB \\cap DE$, $Y = BC \\cap EF$, $Z = CD \\cap FA$ memenuhi Teorema Pascal.
3. Maka $X, Y, Z$ kolinear pada Garis Pascal. $\\blacksquare$
`,
            keyTakeaway: 'Teorema Pascal adalah alat paling ampuh untuk membuktikan kolinearitas 3 titik potong sisi.'
          },
          {
            title: 'Pembuktian Teorema Pappus sebagai Kasus Degenerat Pascal (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Jika $A, B, C$ pada garis $L_1$ dan $D, E, F$ pada garis $L_2$, buktikan $AE \\cap BD$, $AF \\cap CD$, dan $BF \\cap CE$ kolinear (Teorema Pappus).',
            solutionText: `
1. Garis $L_1$ dan $L_2$ dapat dipandang sebagai konik terdegenerasi (sepasang garis lurus).
2. Berdasarkan Teorema Pascal pada konik terdegenerasi ini, ketiga titik potong tersebut selalu kolinear. $\\blacksquare$
`,
            keyTakeaway: 'Teorema Pappus adalah kasus khusus Teorema Pascal saat konik meluruh menjadi 2 garis.'
          },
          {
            title: 'Konstruksi Tangen Lingkaran via Pascal Degenerat (IMO Shortlist)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO Shortlist)',
            problemText: 'Misalkan $A, B, C$ tiga titik pada lingkaran dan $T_A, T_B, T_C$ garis singgungnya. Buktikan titik potong $T_A \\cap BC$, $T_B \\cap CA$, $T_C \\cap AB$ kolinear.',
            solutionText: `
1. Terapkan Teorema Pascal pada segi-6 terdegenerasi $AABBCC$ (di mana sisi $AA$ adalah garis singgung $T_A$).
2. Pasangan sisi berhadapan: $AA \\cap BC$, $BB \\cap CA$, $CC \\cap AB$.
3. Berdasarkan Teorema Pascal, ketiga titik potong ini terbukti kolinear. $\\blacksquare$
`,
            keyTakeaway: 'Mengizinkan titik berimpit ($AA$) mengubah sisi menjadi garis singgung dalam Teorema Pascal.'
          }
        ]
      }
    ]
  },
  {
    id: 'th-teori-bilangan',
    topic: 'Teori Bilangan',
    title: 'Teori Bilangan: Modulo, Fermat, Euler & LTE',
    subtitle: 'Modul Kuliah: Keterbagian, Residu Kuadratik, Persamaan Diophantine, dan $v_p(n)$',
    summary: 'Teori Bilangan menguji pemahaman sifat-sifat bilangan bulat, faktor prima, kongruensi modulo, dan teknik p-adic.',
    content: `
### 1. Pengantar Aritmetika Modulo
Teori bilangan olimpiade berpusat pada **struktur keterbagian** dan **sifat keprimaan**. Dua perkakas terpenting untuk menyelesaikan persamaan Diophantine adalah analisis keterbagian modulo $m$ dan evaluasi kepangkatan prima via valuasi $p$-adic.

### 2. Teorema Utama Aritmetika Modulo
#### a. Teorema Kecil Fermat (Fermat's Little Theorem)
Jika $p$ adalah bilangan prima dan $\\gcd(a, p) = 1$, maka:
$$a^{p-1} \\equiv 1 \\pmod{p}$$

#### b. Teorema Euler (Euler's Totient Theorem)
Untuk setiap $a, n \\in \\mathbb{N}$ dengan $\\gcd(a, n) = 1$:
$$a^{\\phi(n)} \\equiv 1 \\pmod{n}$$
di mana $\\phi(n) = n \\prod_{p \\mid n} \\left(1 - \\frac{1}{p}\\right)$ adalah fungsi Totient Euler.

#### c. Lifting the Exponent Lemma (LTE)
Misalkan $p$ adalah prima ganjil, $a, b \\in \\mathbb{Z}$ dengan $p \\nmid a, p \\nmid b$, dan $p \\mid (a - b)$. Maka untuk setiap $n \\in \\mathbb{N}$:
$$v_p(a^n - b^n) = v_p(a - b) + v_p(n)$$

### 3. Contoh Soal Modul Terpandu
**Soal:** Tentukan seluruh pasangan bilangan bulat positif $(n, p)$ dengan $p$ prima sedemikian sehingga $n^p + 1$ habis dibagi oleh $p^n$.

**Langkah Solusi Lengkap:**
1. Untuk $p = 2$: $n^2 + 1$ habis dibagi $2^n$. Uji $n = 1 \implies 2 \mid 2$ (berlaku). Untuk $n \ge 2$, $2^n > n^2 + 1$, sehingga tidak ada solusi lain.
2. Untuk $p > 2$ (prima ganjil):
   Karena $p \mid (n^p + 1)$, berdasarkan Teorema Kecil Fermat $n^p \equiv n \pmod p$, maka $n + 1 \equiv 0 \pmod p \implies p \mid (n + 1)$.
3. Terapkan LTE Lemma pada $v_p(n^p + 1) = v_p(n^p - (-1)^p)$:
   $$v_p(n^p + 1) = v_p(n + 1) + v_p(p) = v_p(n + 1) + 1$$
4. Karena $p^n \mid (n^p + 1)$, maka $v_p(n^p + 1) \ge n \implies v_p(n + 1) + 1 \ge n$.
5. Pertidaksamaan ini hanya dipenuhi jika $n$ sangat kecil ($n = 1$ atau $n = 2$). Uji $n=1, p=3 \implies 2 \mid 3$ (salah). Uji $n=2, p=3 \implies 3^2 = 9 \mid (2^3 + 1) = 9$ (berlaku!).
6. Kesimpulan: Solusi pasangannya adalah $(1, 2)$ dan $(2, 3)$. \\blacksquare
`,
    keyTheorems: [
      {
        name: 'Teorema Kecil Fermat',
        statement: '$a^{p-1} \\equiv 1 \\pmod p$ jika $p \\nmid a$.',
        proofOutline: 'Diperoleh dari memeriksa himpunan sisa hasil bagi $\\{a, 2a, 3a, \\dots, (p-1)a\\} \\pmod p$.',
        exampleProblem: 'Buktikan $n^7 - n$ selalu habis dibagi $42$ untuk setiap bilangan bulat $n$.'
      },
      {
        name: 'LTE Lemma',
        statement: '$v_p(a^n - b^n) = v_p(a - b) + v_p(n)$ untuk $p \\mid (a - b)$ dan $p \\nmid ab$.',
        proofOutline: 'Ekspansi binomial $b = a + kp$ dan evaluasi modulo $p^2$.',
        exampleProblem: 'Cari semua $n$ sehingga $2^n + 1$ habis dibagi $n^2$.'
      }
    ],
    tips: [
      'Uji persamaan Diophantine dengan memeriksa modulo $3, 4, 8, p$.',
      'Gunakan LTE Lemma ketika menemukan bentuk kepangkatan $a^n \pm b^n$ yang melibatkan faktor prima.'
    ],
    applicationGuide: `
#### 1. Reduksi Modulo $m$ (Uji Kasus Keterbagian)
Periksa persamaan Diophantine modulo $3, 4, 8, 9, p$ untuk membatasi nilai yang mungkin atau membuktikan ketidakmungkinan solusi (no-solution proof).

#### 2. Evaluasi Valuasi $p$-adic & LTE Lemma
Saat menemukan suku berbentuk $a^n \\pm b^n$ dengan pembagi prima $p$, gunakan $v_p(a^n - b^n) = v_p(a - b) + v_p(n)$ untuk mengontrol eksponen kepangkatan.

#### 3. Vieta Jumping (Root Flipping) & Infinite Descent
Jika persamaan simetris berderajat dua muncul, ubah menjadi persamaan kuadrat $x^2 - S x + P = 0$. Gunakan hubungan akar Vieta untuk membuat solusi terkecil baru hingga kontradiksi.
`,
    recommendedBooks: [
      {
        title: 'Modern Olympiad Number Theory',
        author: 'Aditya Khurmi',
        description: 'Ebook teori bilangan paling lengkap dan modern untuk IMO. Menyajikan pembahasan terinci tentang LTE, order elemen, residu kuadratik, dan persamaan Diophantine.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: '104 Number Theory Problems',
        author: 'Titu Andreescu, Dorin Andrica, & Zuming Feng',
        description: 'Latihan soal teori bilangan terstruktur lengkap dari tingkat nasional hingga olimpiade internasional dengan pembahasan formal.',
        level: 'Olimpiade Nasional (OSN)'
      },
      {
        title: 'Number Theory: Structures, Examples, and Problems',
        author: 'Titu Andreescu & Dorin Andrica',
        description: 'Buku teks komprehensif mengulas fungsi aritmetika, kongruensi, persamaan Diophantine, dan teori pecahan berlanjut.',
        level: 'Pemula & Menengah'
      }
    ],
    subChapters: [
      {
        id: 'sub-nt-modulo-fermat',
        title: 'Aritmetika Modulo, Teorema Fermat, & Euler Totient',
        description: 'Teknik dasar dan lanjut aritmetika modulo, Teorema Kecil Fermat, Teorema Euler, dan Teorema Sisa Cina (CRT).',
        detailedContent: `
#### A. Prinsip Kongruensi Modulo
Dua bilangan $a, b \\in \\mathbb{Z}$ dikatakan kongruen modulo $m$ ($a \\equiv b \\pmod m$) jika $m \\mid (a - b)$.
- Sifat Perkalian: Jika $a \\equiv b \\pmod m$ dan $c \\equiv d \\pmod m$, maka $ac \\equiv bd \\pmod m$.
- Sifat Kepangkatan: $a^k \\equiv b^k \\pmod m$.

#### B. Teorema Utama
1. **Teorema Kecil Fermat:** Jika $p$ prima dan $\\gcd(a, p) = 1$, $a^{p-1} \\equiv 1 \\pmod p$.
2. **Teorema Euler:** Untuk $\\gcd(a, n) = 1$, $a^{\\phi(n)} \\equiv 1 \\pmod n$.
`,
        workedExamples: [
          {
            title: 'Keterbagian Polinomial Modulo 42 (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Buktikan bahwa $n^7 - n$ selalu habis dibagi oleh $42$ untuk setiap bilangan bulat $n$.',
            solutionText: `
1. Faktorkan pembagi $42 = 2 \\times 3 \\times 7$. Karena 2, 3, 7 prima relatif sepasang, kita cukup membuktikan $n^7 - n$ habis dibagi 2, 3, dan 7 secara terpisah.
2. Modulo 2: Berdasarkan Fermat Kecil $n^2 \\equiv n \\pmod 2 \\implies n^7 \\equiv n \\pmod 2$.
3. Modulo 3: Berdasarkan Fermat Kecil $n^3 \\equiv n \\pmod 3 \\implies n^7 = (n^3)^2 \\cdot n \\equiv n^2 \\cdot n = n^3 \\equiv n \\pmod 3$.
4. Modulo 7: Berdasarkan Fermat Kecil $n^7 \\equiv n \\pmod 7$.
5. Karena $2 \\mid (n^7-n)$, $3 \\mid (n^7-n)$, dan $7 \\mid (n^7-n)$, maka $2 \\times 3 \\times 7 = 42 \\mid (n^7-n)$. \\blacksquare
`,
            keyTakeaway: 'Memecah pembagi komposit menjadi faktor prima sepasang mengizinkan penerapan Teorema Kecil Fermat.'
          },
          {
            title: 'Pengaplikasian Teorema Sisa Cina / CRT (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Cari bilangan bulat positif terkecil $x$ yang memenuhi sistem kongruensi:\n$$x \\equiv 2 \\pmod 3$$\n$$x \\equiv 3 \\pmod 5$$\n$$x \\equiv 2 \\pmod 7$$',
            solutionText: `
1. Modulo $M = 3 \\times 5 \\times 7 = 105$.
2. Hitung $M_1 = 35, M_2 = 21, M_3 = 15$.
3. Cari invers modulo:
   - $35 y_1 \\equiv 1 \\pmod 3 \\implies 2 y_1 \\equiv 1 \\implies y_1 = 2$.
   - $21 y_2 \\equiv 1 \\pmod 5 \\implies 1 y_2 \\equiv 1 \\implies y_2 = 1$.
   - $15 y_3 \\equiv 1 \\pmod 7 \\implies 1 y_3 \\equiv 1 \\implies y_3 = 1$.
4. Solusi $x = a_1 M_1 y_1 + a_2 M_2 y_2 + a_3 M_3 y_3 \\pmod M$:
   $$x = 2(35)(2) + 3(21)(1) + 2(15)(1) = 140 + 63 + 30 = 233$$
5. Modulo 105: $233 \\equiv 23 \\pmod{105}$.
6. Nilai positif terkecil adalah $x = 23$. \\blacksquare
`,
            keyTakeaway: 'Teorema Sisa Cina (CRT) memberikan solusi unik modulo perkalian faktor prima sepasang.'
          }
        ]
      },
      {
        id: 'sub-nt-lte-vieta-jumping',
        title: 'Lifting The Exponent Lemma (LTE) & Vieta Jumping',
        description: 'Teknik Tingkat Mahir IMO: Evaluasi Valuasi $v_p(n)$ via LTE Lemma dan Penurunan Tak Hingga via Root Flipping.',
        detailedContent: `
#### A. Lifting The Exponent Lemma (LTE)
Misalkan $p$ prima ganjil, $a, b \\in \\mathbb{Z}$, $p \\nmid a, p \\nmid b$, dan $p \\mid (a - b)$. Maka untuk setiap $n \\in \\mathbb{N}$:
$$v_p(a^n - b^n) = v_p(a - b) + v_p(n)$$

#### B. Teknik Vieta Jumping (Root Flipping)
Digunakan pada persamaan Diophantine kuadrat simetris $\\frac{a^2 + b^2}{ab + 1} = k$.
1. Anggap $a, b$ adalah solusi bulat dengan $a + b$ sekecil mungkin.
2. Tuliskan sebagai persamaan kuadrat dalam $x$: $x^2 - (kb)x + (b^2 - k) = 0$.
3. Gunakan Teorema Vieta untuk mengonstruksi akar kedua $x_2 = kb - a = \\frac{b^2 - k}{a}$.
4. Tunjukkan $x_2$ menghasilkan solusi baru yang lebih kecil, memicu kontradiksi penurunan tak hingga.
`,
        workedExamples: [
          {
            title: 'Pembagian Kepangkatan Prima via LTE Lemma (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Cari semua bilangan bulat positif $n$ sedemikian sehingga $3^n - 1$ habis dibagi oleh $2^n$.',
            solutionText: `
1. Tinjau valuasi $v_2(3^n - 1) = v_2(3 - 1) + v_2(3 + 1) + v_2(n) - 1 = 1 + 2 + v_2(n) - 1 = v_2(n) + 2$ untuk $n$ genap.
2. Syarat $2^n \\mid (3^n - 1) \\implies v_2(3^n - 1) \\ge n$.
3. Maka $v_2(n) + 2 \\ge n$.
4. Karena $v_2(n) \\le \\log_2(n)$, pertidaksamaan $\\log_2(n) + 2 \\ge n$ hanya berlaku untuk $n \\le 4$.
5. Uji kasus $n = 1$: $2^1 \\mid 2$ (berlaku).
6. Uji kasus $n = 2$: $2^2 = 4 \\mid 8$ (berlaku).
7. Uji kasus $n = 4$: $2^4 = 16 \\mid (81 - 1) = 80$ (berlaku).
8. Solusi: $n = 1, 2, 4$. \\blacksquare
`,
            keyTakeaway: 'LTE Lemma mengonversi keterbagian eksponensial menjadi pertidaksamaan linier valuasi.'
          },
          {
            title: 'IMO 1988 Problem 6 (Vieta Jumping)',
            level: 'Hard',
            levelLabel: 'Level Hard (IMO 1988)',
            problemText: 'Misalkan $a, b \\in \\mathbb{N}^+$ sedemikian rupa sehingga $ab + 1 \\mid (a^2 + b^2)$. Buktikan bahwa $\\frac{a^2 + b^2}{ab + 1}$ adalah kuadrat sempurna.',
            solutionText: `
1. Misalkan $\\frac{a^2 + b^2}{ab + 1} = k$. Ingin dibuktikan $k$ kuadrat sempurna.
2. Bentuk persamaan kuadrat $x^2 - (kb)x + (b^2 - k) = 0$.
3. Asumsikan $k$ bukan kuadrat sempurna, dan pilih solusi minimal $(a, b)$ dengan $a \\ge b$.
4. Akar kedua $x_2 = kb - a = \\frac{b^2 - k}{a}$.
5. Karena $k$ bukan kuadrat sempurna, $b^2 - k \\neq 0 \\implies x_2 \\neq 0$.
6. Dapat ditunjukkan $0 < x_2 < a$, sehingga pasangan $(x_2, b)$ adalah solusi bulat positif baru dengan $x_2 + b < a + b$.
7. Kontradiksi dengan minimalitas $a + b$.
8. Kesimpulan: $k$ haruslah kuadrat sempurna. \\blacksquare
`,
            keyTakeaway: 'Vieta Jumping adalah mahakarya bukti kontradiksi penurunan tak hingga pada IMO.'
          }
        ]
      }
    ]
  },
  {
    id: 'th-aljabar-polinomial',
    topic: 'Aljabar',
    title: 'Polinomial Olimpiade & Hubungan Akar-Koefisien',
    subtitle: 'Modul Kuliah: Teorema Vieta, Teorema Sisa, Kriteria Eisenstein, dan Jumlah Newton',
    summary: 'Polinomial adalah topik aljabar klasik di OSN dan IMO. Pemahaman mendalam tentang akar-akar kompleks/real, faktorisasi, dan keterbagian polinomial sangat krusial.',
    content: `
### 1. Teorema Vieta (Hubungan Akar dan Koefisien)
Misalkan $P(x) = a_n x^n + a_{n-1} x^{n-1} + \\dots + a_1 x + a_0$ memiliki akar-akar $r_1, r_2, \\dots, r_n$.
- $\\sum r_i = -\\frac{a_{n-1}}{a_n}$
- $\\sum_{i < j} r_i r_j = \\frac{a_{n-2}}{a_n}$
- $r_1 r_2 \\dots r_n = (-1)^n \\frac{a_0}{a_n}$

### 2. Identitas Sum Newton (Newton's Sums)
Misalkan $S_k = r_1^k + r_2^k + \\dots + r_n^k$. Untuk polinomial monik $x^n + a_{n-1}x^{n-1} + \\dots + a_0 = 0$, berlaku hubungan rekursif:
$$S_k + a_{n-1}S_{k-1} + a_{n-2}S_{k-2} + \\dots = 0$$

### 3. Kriteria Eisenstein (Ketakdapatfaktoran / Irreducibility)
Polinomial $P(x) = a_n x^n + \\dots + a_0$ dengan koefisien bulat tidak dapat difaktorkan atas $\\mathbb{Q}[x]$ jika terdapat bilangan prima $p$ sehingga:
1. $p \\nmid a_n$
2. $p \\mid a_{n-1}, a_{n-2}, \\dots, a_0$
3. $p^2 \\nmid a_0$
`,
    keyTheorems: [
      {
        name: 'Teorema Vieta',
        statement: 'Jumlah dan hasil kali simetris dari akar-akar polinomial sama dengan rasio koefisien-koefisiennya.',
        proofOutline: 'Ekspansi bentuk faktor $P(x) = a_n(x - r_1)(x - r_2)\\dots(x - r_n)$ dan samakan koefisien tingkat $x^k$.',
        exampleProblem: 'Jika $x^3 - x + 1 = 0$ memiliki akar $a, b, c$, tentukan nilai $a^5 + b^5 + c^5$.'
      },
      {
        name: 'Kriteria Eisenstein',
        statement: 'Memberikan syarat cukup ketakdapatfaktoran polinomial koefisien bulat atas bilangan rasional.',
        proofOutline: 'Menggunakan kontradiksi melalui pengurangan modulo $p$.',
        exampleProblem: 'Buktikan bahwa $x^n - p$ tidak dapat difaktorkan atas $\\mathbb{Q}[x]$ untuk setiap prima $p$.'
      }
    ],
    applicationGuide: `
#### 1. Identitas Jumlah Newton (Newton's Sums)
Saat diminta menghitung jumlah pangkat akar $S_k = r_1^k + \\dots + r_n^k$, gunakan hubungan rekursif $S_k + a_{n-1}S_{k-1} + \\dots = 0$ daripada mengekspansi secara manual.

#### 2. Kriteria Eisenstein & Shift Polinomial $P(x+c)$
Untuk membuktikan $P(x)$ tak dapat difaktorkan over $\\mathbb{Q}$, jika $P(x)$ belum memenuhi Eisenstein, uji transformasi $Q(x) = P(x+1)$ atau $Q(x) = P(x+p)$.

#### 3. Teorema Akar Rasional & Teorema Sisa
Gunakan $P(a) - P(b)$ habis dibagi $(a - b)$ untuk seluruh $a, b \\in \\mathbb{Z}$ dalam analisis keterbagian polinomial bulat.
`,
    recommendedBooks: [
      {
        title: 'Polynomials',
        author: 'E.J. Barbeau',
        description: 'Buku klasik paling komprehensif tentang teori polinomial, akar-akar kompleks, faktorisasi, dan polinomial Chebyshev.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: '103 Trigonometry Problems & Polynomials',
        author: 'Titu Andreescu & Zuming Feng',
        description: 'Membahas hubungan mendalam antara polinomial, rumus Vieta, dan identitas trigonometri untuk olimpiade.',
        level: 'Olimpiade Nasional (OSN)'
      },
      {
        title: 'Polynomials in Mathematical Olympiads',
        author: 'Navid Safaei',
        description: 'Kumpulan teknik dan strategi menyelesaikan soal polinomial berjenjang dari OSN hingga IMO Shortlist.',
        level: 'Pemula & Menengah'
      }
    ],
    subChapters: [
      {
        id: 'sub-poly-vieta-newton',
        title: 'Teorema Vieta & Identitas Newton (Sums of Powers)',
        description: 'Menghitung simetris akar $S_k = \\sum r_i^k$, hubungan koefisien-akar, dan formulasi polinomial monik.',
        detailedContent: `
#### A. Teorema Vieta untuk Polinomial Derajat $n$
Jika $P(x) = a_n x^n + a_{n-1} x^{n-1} + \\dots + a_0$ memiliki akar-akar $r_1, r_2, \\dots, r_n$:
- $r_1 + r_2 + \\dots + r_n = -\\frac{a_{n-1}}{a_n}$
- $\\sum_{i < j} r_i r_j = \\frac{a_{n-2}}{a_n}$
- $r_1 r_2 \\dots r_n = (-1)^n \\frac{a_0}{a_n}$

#### B. Rumus Rekursif Newton
Untuk polinomial $x^n + a_{n-1} x^{n-1} + \\dots + a_0 = 0$ dengan $S_k = r_1^k + \\dots + r_n^k$:
$$S_k + a_{n-1} S_{k-1} + a_{n-2} S_{k-2} + \\dots + a_0 S_{k-n} = 0 \\quad (\\text{untuk } k \\ge n)$$
`,
        workedExamples: [
          {
            title: 'Kalkulasi Pangkat Akar via Newton Sums (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Misalkan $a, b, c$ adalah akar-akar dari $x^3 - x - 1 = 0$. Hitung nilai dari $a^5 + b^5 + c^5$.',
            solutionText: `
1. Koefisien polinomial: $a_3 = 1, a_2 = 0, a_1 = -1, a_0 = -1$.
2. Berdasarkan Vieta:
   - $S_1 = a + b + c = 0$.
   - $ab + bc + ca = -1$.
3. Hitung $S_2 = a^2 + b^2 + c^2 = (a+b+c)^2 - 2(ab+bc+ca) = 0 - 2(-1) = 2$.
4. Karena $x^3 = x + 1$, maka $S_3 = S_1 + 3 = 0 + 3 = 3$.
5. Gunakan Newton Sums $S_k = S_{k-2} + S_{k-3}$:
   - $S_4 = S_2 + S_1 = 2 + 0 = 2$.
   - $S_5 = S_3 + S_2 = 3 + 2 = 5$.
6. Kesimpulan: $a^5 + b^5 + c^5 = 5$. \\blacksquare
`,
            keyTakeaway: 'Rekursi Newton $S_k = S_{k-2} + S_{k-3}$ menghindari pengerjaan pemangkatan aljabar yang rumit.'
          },
          {
            title: 'Faktorisasi & Kriteria Eisenstein dengan Shift (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Buktikan bahwa polinomial $P(x) = x^4 + x^3 + x^2 + x + 1$ tidak dapat difaktorkan atas bilangan rasional $\\mathbb{Q}[x]$.',
            solutionText: `
1. Perhatikan bahwa $P(x) = \\frac{x^5 - 1}{x - 1}$.
2. Kriteria Eisenstein langsung pada $P(x)$ gagal karena koefisiennya semua 1.
3. Lakukan substitusi shift $x = y + 1$:
   $$Q(y) = P(y+1) = \\frac{(y+1)^5 - 1}{y} = y^4 + 5y^3 + 10y^2 + 10y + 5$$
4. Tinjau koefisien dari $Q(y)$: $a_4 = 1, a_3 = 5, a_2 = 10, a_1 = 10, a_0 = 5$.
5. Pilih bilangan prima $p = 5$:
   - $5 \\nmid a_4 = 1$.
   - $5 \\mid a_3, a_2, a_1, a_0$ ($5, 10, 10, 5$ semuanya habis dibagi 5).
   - $5^2 = 25 \\nmid a_0 = 5$.
6. Berdasarkan Kriteria Eisenstein, $Q(y)$ tak dapat difaktorkan over $\\mathbb{Q}[x]$.
7. Akibatnya $P(x)$ juga tak dapat difaktorkan over $\\mathbb{Q}[x]$. \\blacksquare
`,
            keyTakeaway: 'Transformasi $P(y+1)$ membuka jalan penggunaan Kriteria Eisenstein pada Polinomial Siklotomik.'
          }
        ]
      }
    ],
    tips: [
      'Gunakan substitusi $x = y + k$ jika ingin menghilangkan suku tingkat $n-1$.',
      'Manfaatkan akar persatuan (roots of unity) $\\omega = e^{2\\pi i / n}$ untuk mengevaluasi jumlah berbobot.'
    ]
  },
  {
    id: 'th-persamaan-fungsional',
    topic: 'Aljabar',
    title: 'Persamaan Fungsional & Teknik Substitusi Cauchy',
    subtitle: 'Modul Kuliah: $f(x)$ pada Domain Real/Bulat, Injektivitas, Surjektivitas, dan Titik Tetap',
    summary: 'Persamaan fungsional menguji kemampuan manipulasi simbolik, analisis domain/kodomain, dan penentuan sifat fungsional unik.',
    content: `
### 1. Pengantar Persamaan Fungsional
Dalam olimpiade matematika, persamaan fungsional meminta kita menemukan seluruh fungsi $f: D \to C$ yang memenuhi suatu identitas untuk seluruh elemen domain $D$.

### 2. Langkah Strategis Utama
1. **Substitusi Nilai Khusus:** Uji $x=0, y=0, x=y, x=1$.
2. **Analisis Injektivitas:** Tunjukkan bahwa $f(a) = f(b) \implies a = b$.
3. **Analisis Surjektivitas:** Tunjukkan bahwa untuk setiap $y \in C$, ada $x \in D$ sehingga $f(x) = y$.
4. **Persamaan Cauchy:** $f(x+y) = f(x) + f(y) \implies f(x) = cx$ (pada $\mathbb{Q}$ atau $\mathbb{R}$ dengan sifat kontinu/monoton).

### 3. Contoh Soal Terpandu
**Soal:** Cari semua fungsi $f: \mathbb{R} \to \mathbb{R}$ yang memenuhi $f(x + y) = f(x) + f(y) + 2xy$ untuk semua $x, y \in \mathbb{R}$.

**Langkah Solusi Lengkap:**
1. Definisikan $g(x) = f(x) - x^2$. Maka $f(x) = g(x) + x^2$.
2. Substitusikan ke dalam persamaan asal:
   $$g(x+y) + (x+y)^2 = g(x) + x^2 + g(y) + y^2 + 2xy$$
   $$g(x+y) + x^2 + 2xy + y^2 = g(x) + g(y) + x^2 + y^2 + 2xy$$
   $$g(x+y) = g(x) + g(y)$$
3. Ini adalah Persamaan Fungsional Cauchy! Maka $g(x) = cx$ untuk suatu konstanta $c \in \mathbb{R}$.
4. Maka $f(x) = x^2 + cx$. Uji kembali ke persamaan awal untuk memastikan konsistensi. Terbukti! \\blacksquare
`,
    keyTheorems: [
      {
        name: 'Persamaan Fungsional Cauchy',
        statement: '$f(x+y) = f(x) + f(y) \\implies f(x) = cx$ untuk $x \\in \\mathbb{Q}$.',
        proofOutline: 'Induksi pada bilangan bulat positif, ekstensi ke negatif, lalu rasional $p/q$.',
        exampleProblem: 'Cari semua fungsi kontinu $f(x+y) = f(x)f(y)$.'
      }
    ],
    applicationGuide: `
#### 1. Uji Nilai Khusus & Titik Tetap (Fixed Points)
Substitusikan $x=0, y=0, x=y, x=1$ untuk mengevaluasi $f(0), f(1)$, atau mencari $c$ sedemikian rupa sehingga $f(c) = c$.

#### 2. Bukti Injektivitas & Surjektivitas
- **Injektivitas:** Jika $f(a) = f(b) \\implies a = b$. Berguna untuk membatasi ekspresi di dalam $f(\\dots)$.
- **Surjektivitas:** Jika $f(\\mathbb{R}) = \\mathbb{R}$, maka ada $a$ sedemikian rupa sehingga $f(a) = 0$ atau $f(a) = 1$.

#### 3. Reduksi ke Persamaan Fungsional Standar
Lakukan transformasi variabel $g(x) = f(x) - x$ atau $g(x) = f(x)/x$ untuk mengubah persamaan menjadi bentuk Cauchy $g(x+y) = g(x) + g(y)$ atau d\'Alembert.
`,
    recommendedBooks: [
      {
        title: 'Functional Equations and How to Solve Them',
        author: 'Christopher G. Small',
        description: 'Buku panduan terlengkap persamaan fungsional. Mengulas Cauchy, d\'Alembert, Pexider, involusi, dan teknik iterasi fungsi.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: 'Functional Equations in Mathematical Olympiads',
        author: 'B.J. Venkatachala',
        description: 'Panduan langkah demi langkah membedah persamaan fungsional untuk olimpiade matematika dari pemula hingga OSN.',
        level: 'Olimpiade Nasional (OSN)'
      },
      {
        title: '107 Functional Equations Problems',
        author: 'Titu Andreescu & Iurie Boreico',
        description: 'Kumpulan 107 soal persamaan fungsional pilihan dari kompetisi dunia dengan teknik penyelesaian formal yang anggun.',
        level: 'Pemula & Menengah'
      }
    ],
    subChapters: [
      {
        id: 'sub-fe-cauchy',
        title: 'Persamaan Fungsional Cauchy & Reduksi Linier',
        description: 'Menyelesaikan $f(x+y) = f(x) + f(y)$ pada domain $\\mathbb{Q}$ dan $\\mathbb{R}$ dengan syarat kontinuitas atau monotonisitas.',
        detailedContent: `
#### A. Persamaan Cauchy Standar
Bentuk dasar $f(x+y) = f(x) + f(y)$ untuk seluruh $x, y \\in \\mathbb{R}$.
- Pada domain bilangan rasional $\\mathbb{Q}$, solusinya **selalu** $f(x) = cx$ di mana $c = f(1)$.
- Pada domain real $\\mathbb{R}$, solusi unik $f(x) = cx$ dijamin jika $f$ memenuhi setidaknya satu syarat berikut:
  1. $f$ kontinu di setidaknya satu titik.
  2. $f$ monoton (naik/turun).
  3. $f$ terbatas pada suatu interval $(a, b)$.
`,
        workedExamples: [
          {
            title: 'Reduksi ke Cauchy via Substitusi Polinomial (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Cari seluruh fungsi $f: \\mathbb{R} \\to \\mathbb{R}$ yang memenuhi $f(x+y) = f(x) + f(y) + 3xy(x+y)$ untuk seluruh $x, y \\in \\mathbb{R}$.',
            solutionText: `
1. Ingat identitas kubik: $(x+y)^3 = x^3 + y^3 + 3xy(x+y) \\implies (x+y)^3 - x^3 - y^3 = 3xy(x+y)$.
2. Definisikan fungsi penolong $g(x) = f(x) - x^3$. Maka $f(x) = g(x) + x^3$.
3. Substitusikan $f(x) = g(x) + x^3$ ke persamaan awal:
   $$g(x+y) + (x+y)^3 = g(x) + x^3 + g(y) + y^3 + 3xy(x+y)$$
   $$g(x+y) + x^3 + y^3 + 3xy(x+y) = g(x) + g(y) + x^3 + y^3 + 3xy(x+y)$$
   $$g(x+y) = g(x) + g(y)$$
4. Ini adalah Persamaan Cauchy! Karena $g$ diturunkan dari polinomial kontinu, maka $g(x) = cx$.
5. Maka $f(x) = x^3 + cx$ untuk sembarang konstanta $c \\in \\mathbb{R}$.
6. Uji kembali ke persamaan asal: $(x+y)^3 + c(x+y) = x^3 + cx + y^3 + cy + 3xy(x+y)$ (konsisten!). \\blacksquare
`,
            keyTakeaway: 'Pengurangan $g(x) = f(x) - x^3$ mengeliminasi suku silang $3xy(x+y)$ dan mereduksi ke Cauchy.'
          },
          {
            title: 'Injektivitas & Involusi Fungsi (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Cari seluruh fungsi $f: \\mathbb{R} \\to \\mathbb{R}$ yang memenuhi $f(f(x) + y) = 2x + f(f(y) - x)$ untuk seluruh $x, y \\in \\mathbb{R}$.',
            solutionText: `
1. Misalkan $P(x, y)$ menyatakan substitusi ke dalam persamaan.
2. $P(x, 0) \\implies f(f(x)) = 2x + f(f(0) - x)$.
3. Pembuktian Surjektivitas: Ruas kanan $2x + \\dots$ dapat menghasilkan nilai real sembarang, sehingga $f$ surjektif.
4. Karena $f$ surjektif, terdapat titik $a$ sedemikian rupa sehingga $f(a) = 0$.
5. $P(a, y) \\implies f(y) = 2a + f(f(y) - a)$.
6. Melalui manipulasi substitusi dan pengisolasian variabel, diperoleh calon solusi linier $f(x) = x + c$ atau $f(x) = -x + c$.
7. Uji kembali ke persamaan awal menghasilkan solusi tunggal $f(x) = x$. \\blacksquare
`,
            keyTakeaway: 'Membuktikan surjektivitas $f(\\mathbb{R}) = \\mathbb{R}$ memungkinkan pemilihan titik nol $f(a) = 0$.'
          }
        ]
      }
    ],
    tips: [
      'Selalu cek kembali seluruh calon solusi $f(x)$ ke persamaan awal!',
      'Gunakan sifat involusi $f(f(x)) = x$ untuk mengisolasi variabel.'
    ]
  },
  {
    id: 'th-aljabar-ineq-advanced',
    topic: 'Aljabar',
    title: 'Ketaksamaan Lanjut: Jensen, Karamata & Majorisasi',
    subtitle: 'Konveksitas Fungsi, Pengurutan Variabel, dan Teorema Muirhead',
    summary: 'Materi ketaksamaan tingkat lanjut IMO yang mengandalkan sifat geometris fungsi konveks/konkaf serta teknik pembanding susunan variabel.',
    content: `
### 1. Pertidaksamaan Jensen
Misalkan $f: I \\to \\mathbb{R}$ adalah fungsi **konveks** ($f''(x) \\ge 0$). Untuk sembarang $x_1, x_2, \\dots, x_n \\in I$ dan bobot $w_1, \\dots, w_n > 0$ dengan $\\sum w_i = 1$:
$$f\\left(\\sum_{i=1}^n w_i x_i\\right) \\le \\sum_{i=1}^n w_i f(x_i)$$
Jika $f$ konkaf ($f''(x) \\le 0$), tanda pertidaksamaan berbalik.

### 2. Majorisasi & Teorema Karamata
Vektor $A = (a_1, a_2, \\dots, a_n)$ **memajorisasi** $B = (b_1, b_2, \\dots, b_n)$ (ditulis $A \\succ B$) jika:
1. $a_1 \\ge a_2 \\ge \\dots \\ge a_n$ dan $b_1 \\ge b_2 \\ge \\dots \\ge b_n$
2. $\\sum_{i=1}^k a_i \\ge \\sum_{i=1}^k b_i$ untuk $k = 1, 2, \\dots, n-1$
3. $\\sum_{i=1}^n a_i = \\sum_{i=1}^n b_i$

**Teorema Karamata:** Jika $f$ konveks dan $A \\succ B$, maka:
$$\\sum_{i=1}^n f(a_i) \\ge \\sum_{i=1}^n f(b_i)$$
`,
    keyTheorems: [
      {
        name: 'Jensen Inequality',
        statement: 'Nilai fungsi dari rata-rata berbobot selalu $\\le$ rata-rata berbobot dari nilai fungsi jika fungsi konveks.',
        proofOutline: 'Dibuktikan dengan induksi matematika pada jumlah variabel $n$.',
        exampleProblem: 'Buktikan $\\sin A + \\sin B + \\sin C \\le \\frac{3\\sqrt{3}}{2}$ pada segitiga $ABC$.'
      },
      {
        name: 'Karamata Inequality',
        statement: 'Generalisasi pertidaksamaan Jensen menggunakan konsep majorisasi urutan vektor.',
        proofOutline: 'Menggunakan transformasi Abel (summation by parts) dan sifat konveksitas turunan pertama.',
        exampleProblem: 'Buktikan $a^a b^b c^c \\ge (abc)^{(a+b+c)/3}$ untuk $a,b,c > 0$.'
      }
    ],
    applicationGuide: `
#### 1. Uji Konveksitas via Turunan Kedua $f''(x)$
Tentukan interval di mana $f''(x) \\ge 0$ (konveks) atau $f''(x) \\le 0$ (konkaf). Pastikan seluruh variabel berada di dalam interval tersebut sebelum menerapkan Pertidaksamaan Jensen.

#### 2. Konstruksi Majorisasi $(a_1, \\dots, a_n) \\succ (b_1, \\dots, b_n)$
Urutkan variabel $x_1 \\ge x_2 \\ge \\dots \\ge x_n$. Bandingkan jumlah parsial $\\sum_{i=1}^k a_i \\ge \\sum_{i=1}^k b_i$ untuk menerapkan Teorema Karamata.

#### 3. Teorema Muirhead & Homogenisasi
Untuk pertidaksamaan simetris $P(x, y, z) \\ge 0$, nyatakan dalam bentuk jumlah simetris $\\sum_{\\text{sym}} x^a y^b z^c$ dan periksa kondisi majorisasi eksponen $(a_1, a_2, a_3) \\succ (b_1, b_2, b_3)$.
`,
    recommendedBooks: [
      {
        title: 'Secrets in Inequalities (Volume 1 & 2)',
        author: 'Pham Kim Hung',
        description: 'Buku mahakarya ketaksamaan olimpiade. Mengupas tuntas Jensen, Karamata, SOS (Sum of Squares), AB-Method, dan Tangent Line Method.',
        level: 'Tingkat IMO / Internasional'
      },
      {
        title: 'Inequalities: A Mathematical Olympiad Approach',
        author: 'Radmila Bulajich Manfrino, J.A. Ortega, & R.B. Delgado',
        description: 'Ebook terstruktur yang sangat rapi menyajikan ketaksamaan Cauchy-Schwarz, AM-GM, Holder, Jensen, dan Karamata dengan bukti lengkap.',
        level: 'Olimpiade Nasional (OSN)'
      },
      {
        title: 'Old and New Inequalities',
        author: 'Titu Andreescu, Vasile Cîrtoaje, Gabriel Dospinescu, & Mircea Lascu',
        description: 'Kumpulan 200+ soal pertidaksamaan pilihan IMO Shortlist dengan pembahasan multi-metode yang elegan.',
        level: 'Pemula & Menengah'
      }
    ],
    subChapters: [
      {
        id: 'sub-ineq-jensen-karamata',
        title: 'Pertidaksamaan Jensen & Karamata Majorisasi',
        description: 'Menganalisis konveksitas fungsi $f\'\'(x) \\ge 0$, evaluasi sudut segitiga, dan majorisasi susunan variabel.',
        detailedContent: `
#### A. Pertidaksamaan Jensen
Misalkan $f: I \\to \\mathbb{R}$ konveks ($f''(x) \\ge 0$). Untuk $x_1, \\dots, x_n \\in I$ dan bobot $\\sum w_i = 1$:
$$f\\left(\\sum_{i=1}^n w_i x_i\\right) \\le \\sum_{i=1}^n w_i f(x_i)$$

#### B. Teorema Karamata
Jika $f$ konveks dan vektor $A = (a_1, \\dots, a_n)$ memajorisasi $B = (b_1, \\dots, b_n)$ ($A \\succ B$):
$$\\sum_{i=1}^n f(a_i) \\ge \\sum_{i=1}^n f(b_i)$$
`,
        workedExamples: [
          {
            title: 'Maksimum Jumlah Sinus Sudut Segitiga via Jensen (OSN-K)',
            level: 'Intermediate',
            levelLabel: 'Level Intermediate (OSN-K)',
            problemText: 'Pada sembarang segitiga $ABC$, buktikan bahwa $\\sin A + \\sin B + \\sin C \\le \\frac{3\\sqrt{3}}{2}$.',
            solutionText: `
1. Tinjau fungsi $f(x) = \\sin x$ pada interval $x \\in (0, \\pi)$.
2. Hitung turunan kedua: $f'(x) = \\cos x \\implies f''(x) = -\\sin x < 0$ untuk $x \\in (0, \\pi)$.
3. Karena $f''(x) < 0$, maka $f(x) = \\sin x$ adalah fungsi **konkaf** pada $(0, \\pi)$.
4. Terapkan Pertidaksamaan Jensen (bentuk konkaf):
   $$\\frac{\\sin A + \\sin B + \\sin C}{3} \\le \\sin\\left(\\frac{A + B + C}{3}\\right)$$
5. Karena $A + B + C = \\pi$, maka $\\frac{A+B+C}{3} = \\frac{\\pi}{3} = 60^\\circ$.
6. Maka $\\sin A + \\sin B + \\sin C \\le 3 \\cdot \\sin(60^\\circ) = 3 \\cdot \\frac{\\sqrt{3}}{2} = \\frac{3\\sqrt{3}}{2}$.
7. Kesamaan terjadi jika dan hanya jika $A = B = C = 60^\\circ$ (segitiga sama sisi). \\blacksquare
`,
            keyTakeaway: 'Sifat konkaf $f\'\'(x) = -\\sin x < 0$ membuktikan batas maksimum $3\\sqrt{3}/2$ secara instan.'
          },
          {
            title: 'Pertidaksamaan Karamata pada Variabel Terurut (OSN-P)',
            level: 'Medium',
            levelLabel: 'Level Medium (OSN-P)',
            problemText: 'Untuk $a, b, c > 0$, buktikan bahwa $a^a b^b c^c \\ge (abc)^{(a+b+c)/3}$.',
            solutionText: `
1. Ambil logaritma natural pada kedua ruas:
   $$\\ln(a^a b^b c^c) = a \\ln a + b \\ln b + c \\ln c$$
   $$\\ln\\left((abc)^{(a+b+c)/3}\\right) = \\frac{a+b+c}{3} (\\ln a + \\ln b + \\ln c)$$
2. Tinjau fungsi $f(x) = x \\ln x$ untuk $x > 0$.
3. Hitung turunan kedua: $f'(x) = 1 + \\ln x \\implies f''(x) = \\frac{1}{x} > 0$. Maka $f(x)$ **konveks**.
4. Tanpa mengurangi keumuman (WLOG), urutkan $a \\ge b \\ge c$.
5. Vektor $(a, b, c)$ memajorisasi $\\left(\\frac{a+b+c}{3}, \\frac{a+b+c}{3}, \\frac{a+b+c}{3}\\right)$.
6. Berdasarkan Karamata/Jensen:
   $$f(a) + f(b) + f(c) \\ge 3 f\\left(\\frac{a+b+c}{3}\\right)$$
   $$a \\ln a + b \\ln b + c \\ln c \\ge (a+b+c) \\ln\\left(\\frac{a+b+c}{3}\\right)$$
7. Eksponensialkan kembali untuk memperoleh hasil yang diinginkan. \\blacksquare
`,
            keyTakeaway: 'Konveksitas $f(x) = x \\ln x$ adalah teknik standar menyelesaikan pertidaksamaan berpangkat variabel.'
          }
        ]
      }
    ],
    tips: [
      'Turunan kedua $f\'\'(x) > 0$ memastikan fungsi konveks murni.',
      'Periksa apakah batas variabel dapat diurutkan tanpa mengurangi keumuman (WLOG).'
    ]
  },
  {
    id: 'th-komb-ekstremal',
    topic: 'Kombinatorika',
    title: 'Prinsip Ekstremal & Teori Graf Lanjut',
    subtitle: 'Elemen Terkecil/Terbesar, Teorema Turán, Ramsey, dan Pewarnaan',
    summary: 'Prinsip Ekstremal mengajarkan kita untuk mempertimbangkan objek dengan ukuran ekstrem (maksimum atau minimum) guna menyederhanakan masalah kombinatorik yang rumit.',
    content: `
### 1. Metode Ekstremal (Extremal Principle)
Langkah kunci:
1. Pilih elemen dengan nilai parameter tertentu yang **maksimum** atau **minimum** (misal: jarak terpendek, derajat terbesar, subhimpunan terbesar).
2. Tunjukkan bahwa sifat ekstremal ini memaksa struktur lokal tertentu yang memicu kontradiksi atau membuktikan klaim.

### 2. Teorema Turán (Teori Graf Ekstremal)
Misalkan $G$ adalah graf sederhana dengan $n$ simpul yang tidak mengandung klik $K_{r+1}$ (subgraf lengkap ukuran $r+1$). Banyaknya sisi maksimum pada $G$ adalah:
$$|E(G)| \\le \\frac{r-1}{2r} n^2$$
Graf yang mencapai batas ini adalah Graf Turán $T_r(n)$ (graf $r$-partit seimbang).

### 3. Teorema Ramsey
Untuk setiap pasangan bilangan bulat $r, s \\ge 2$, terdapat bilangan bulat terpencil $R(r, s)$ sedemikian rupa sehingga setiap pewarnaan merah/biru pada sisi-sisi $K_N$ ($N \\ge R(r, s)$) pasti mengandung $K_r$ merah atau $K_s$ biru.
Contoh klasik: $R(3, 3) = 6$.
`,
    keyTheorems: [
      {
        name: 'Teorema Mantel',
        statement: 'Banyak sisi maksimum pada graf $n$ simpul tanpa segitiga ($K_3$) adalah $\\lfloor n^2 / 4 \\rfloor$.',
        proofOutline: 'Merupakan kasus khusus $r=2$ dari Teorema Turán, dibuktikan dengan induksi atau pertidaksamaan Cauchy-Schwarz.',
        exampleProblem: 'Tunjukkan bahwa dalam komunitas $2n$ orang dengan setidaknya $n^2 + 1$ hubungan pertemanan, pasti ada $3$ orang yang saling kenal.'
      }
    ],
    tips: [
      'Asumsikan konfigurasinya memiliki segmen garis terpendek atau simpul berderajat tertinggi.',
      'Gunakan analisis kontraposisi jika membuktikan keberadaan struktur.'
    ]
  },
  {
    id: 'th-aljabar-linear-recurrence',
    topic: 'Aljabar',
    title: 'Barisan Rekursi Linear & Persamaan Karakteristik',
    subtitle: 'Homogeneous Recurrence, Eksponensiasi Matriks, dan Jumlah Newton',
    summary: 'Teknik aljabar mendalam untuk menentukan rumus eksplisit suku ke-n barisan rekursif, menganalisis keterbagian suku rekursif, dan menghitung kecepatan konvergensi.',
    content: `
### 1. Barisan Rekursif Linear Homogen
Barisan $a_n$ yang memenuhi rekursi order $k$:
$$a_n + c_1 a_{n-1} + c_2 a_{n-2} + \\dots + c_k a_{n-k} = 0$$
Memiliki **persamaan karakteristik**:
$$\\lambda^k + c_1 \\lambda^{k-1} + c_2 \\lambda^{k-2} + \\dots + c_k = 0$$

Jika persamaan ini memiliki akar-akar $r_1, r_2, \\dots, r_k$ yang saling berbeda, bentuk umum solusinya adalah:
$$a_n = A_1 r_1^n + A_2 r_2^n + \\dots + A_k r_k^n$$
Di mana konstanta $A_i$ ditentukan oleh nilai-nilai awal.

### 2. Formulasi Eksponensiasi Matriks $O(\\log n)$
Rekursi linear dapat dinyatakan dalam bentuk perkalian matriks:
$$\\begin{pmatrix} a_{n} \\\\ a_{n-1} \\end{pmatrix} = \\begin{pmatrix} c_1 & c_2 \\\\ 1 & 0 \\end{pmatrix}^{n-1} \\begin{pmatrix} a_1 \\\\ a_0 \\end{pmatrix}$$
Menggunakan algoritma Binary Exponentiation, $a_n$ dapat dihitung dalam kompleksitas $O(k^3 \\log n)$.

### 3. Aplikasi Keterbagian Barisan Fibonacci & Lucas
- $\\gcd(F_m, F_n) = F_{\\gcd(m, n)}$
- $F_m \\mid F_n \\iff m \\mid n$
`,
    keyTheorems: [
      {
        name: 'Teorema Binet Fibonacci',
        statement: '$F_n = \\frac{\\phi^n - \\psi^n}{\\sqrt{5}}$ di mana $\\phi = \\frac{1+\\sqrt{5}}{2}$ dan $\\psi = \\frac{1-\\sqrt{5}}{2}$.',
        proofOutline: 'Akar karakteristik $x^2 - x - 1 = 0$ adalah $\\phi$ dan $\\psi$. Tentukan konstanta $A_1, A_2$ dengan $F_0=0, F_1=1$.',
        exampleProblem: 'Buktikan bahwa $F_{2n+1} = F_n^2 + F_{n+1}^2$ untuk semua $n \\ge 0$.'
      }
    ],
    tips: [
      'Gunakan matriks ketika ditanyakan nilai modulo $m$ untuk suku ke-n yang sangat besar.',
      'Jika ada akar berulang $\\lambda$ dengan multiplisitas $m$, sertakan suku $(c_0 + c_1 n + \\dots + c_{m-1} n^{m-1}) \\lambda^n$.'
    ]
  },
  {
    id: 'th-komb-double-counting',
    topic: 'Kombinatorika',
    title: 'Prinsip Penghitungan Ganda & Matriks Insidensi',
    subtitle: 'Double Counting, Handshaking Lemma, Pasangan Matriks $(v, b, r, k, \\lambda)$, dan Fano Plane',
    summary: 'Double Counting adalah teknik menghitung ukuran suatu himpunan pasangan $(x, y)$ dengan dua cara berbeda untuk memperoleh identitas aljabar atau pertidaksamaan kombinatorik yang canggih.',
    content: `
### 1. Prinsip Penghitungan Ganda (Double Counting)
Misalkan $R$ adalah matriks insidensi $0-1$ berukuran $m \\times n$:
$$\\sum_{i=1}^m (\\text{jumlah elemen baris } i) = \\sum_{j=1}^n (\\text{jumlah elemen kolom } j)$$

### 2. Handshaking Lemma pada Graf
Untuk sembarang graf $G = (V, E)$:
$$\\sum_{v \\in V} \\text{deg}(v) = 2 |E|$$
Akibatnya, banyaknya simpul yang berderajat ganjil pasti genap.

### 3. Ketaksamaan Cauchy-Schwarz Kombinatorik
Diberikan $n$ himpunan $S_1, S_2, \\dots, S_n$. Jumlah pasangan elemen yang muncul di dua himpunan bersama-sama memenuhi:
$$\\sum_{1 \\le i < j \\le n} |S_i \\cap S_j| \\ge \\frac{\\left(\\sum |S_i|\\right)^2}{2n} - \\frac{\\sum |S_i|}{2}$$
`,
    keyTheorems: [
      {
        name: 'Ketaksamaan Fisher (Block Design)',
        statement: 'Dalam sistem blok seimbang $(v, b, r, k, \\lambda)$, banyaknya blok $b$ selalu $\\ge$ banyaknya elemen $v$.',
        proofOutline: 'Menggunakan determinan dari matriks insidensi $N N^T$ yang bernilai positif definit.',
        exampleProblem: 'Buktikan bahwa pada bidang proyektif Fano $v = b = 7$.'
      }
    ],
    tips: [
      'Definisikan relasi $R(x,y)$ sebagai "elemen $x$ berada di subhimpunan $y$".',
      'Manfaatkan Cauchy-Schwarz untuk menghitung rata-rata derajat keterhubungan.'
    ]
  },
  {
    id: 'th-geo-barycentric-trilinear',
    topic: 'Geometri',
    title: 'Titik-Titik Istimewa Segitiga & Teorema Feuerbach',
    subtitle: 'Symmedian, Lemoine Point, Konjugat Isogonal, Isotomic, dan Pusat Lingkaran Sembilan Titik',
    summary: 'Eksplorasi geometri tingkat tinggi seputar transformasi isogonal, simedian, dan lingkaran Feuerbach yang sering muncul pada nomor 3 atau 6 IMO.',
    content: `
### 1. Konjugat Isogonal (Isogonal Conjugate)
Diberikan titik $P$ di interior $\\triangle ABC$. Cerminkan garis $AP, BP, CP$ terhadap garis bagi sudut $A, B, C$. Ketiga garis cerminan tersebut berpotongan di satu titik $P^*$ yang disebut **Konjugat Isogonal dari $P$**.
- Konjugat Isogonal dari Pusat Lingkaran Luar $O$ adalah **Ortosenter $H$**.
- Konjugat Isogonal dari Titik Berat $G$ adalah **Titik Lemoine / Symmedian $K$**.

### 2. Sifat-Sifat Garis Simedian (Symmedian)
Garis simedian adalah cerminan dari garis berat terhadap garis bagi sudut.
- Garis simedian dari $A$ memotong $BC$ di $D$ dengan rasio: $\\frac{BD}{DC} = \\frac{c^2}{b^2}$.
- Titik potong garis singgung lingkaran luar di $B$ dan $C$ terletak pada garis simedian dari $A$.

### 3. Teorema Feuerbach
Lingkaran sembilan titik (Nine-Point Circle) dari suatu segitiga **bersinggungan dalam** dengan lingkaran dalam (incircle) dan **bersinggungan luar** dengan ketiga lingkaran singgung luar (excircles).
`,
    keyTheorems: [
      {
        name: 'Teorema Feuerbach',
        statement: 'Lingkaran Sembilan Titik bersinggungan dengan Incircle di Titik Feuerbach $F$.',
        proofOutline: 'Menggunakan Inversi Lingkaran berpusat di titik tengah sisi atau koordinat kompleks.',
        exampleProblem: 'Buktikan titik singgung lingkaran dalam dan sembilan titik segaris dengan pusat-pusatnya.'
      }
    ],
    tips: [
      'Gunakan sifat garis simedian ketika ada dua garis singgung lingkaran luar yang berpotongan.',
      'Sifat konjugat isogonal sangat ampuh dikombinasikan dengan Teorema Ceva bentuk Sinus.'
    ]
  },
  {
    id: 'th-nt-analytic-dirichlet',
    topic: 'Teori Bilangan',
    title: 'Polinomial Siklotomik & Rumus Inversi Möbius',
    subtitle: 'Cyclotomic Polynomials $\\Phi_n(x)$, Fungsi Inversi Möbius $\\mu(n)$, dan Inversi Dirichlet',
    summary: 'Struktur aljabar canggih dari bilangan bulat, pembagi prima, dan akar persatuan yang membentuk fondasi teori bilangan modern.',
    content: `
### 1. Polinomial Siklotomik $\\Phi_n(x)$
Polinomial monik yang akar-akarnya adalah seluruh akar persatuan primitif ke-$n$ (primitive $n$-th roots of unity):
$$\\Phi_n(x) = \\prod_{\\gcd(k,n)=1, 1 \\le k \\le n} \\left(x - e^{2\\pi i k / n}\\right)$$
Sifat Kunci:
- $x^n - 1 = \\prod_{d \\mid n} \\Phi_d(x)$
- $\\Phi_n(x)$ selalu berkoefisien bulat dan tidak dapat difaktorkan atas $\\mathbb{Z}[x]$ (irreducible).

### 2. Fungsi Möbius $\\mu(n)$ & Inversi Möbius
Didefinisikan sebagai:
$$\\mu(n) = \\begin{cases} 1 & \\text{jika } n = 1 \\\\ (-1)^k & \\text{jika } n \\text{ adalah perkalian } k \\text{ prima berbeda} \\\\ 0 & \\text{jika } n \\text{ memiliki faktor kuadrat} \\end{cases}$$

**Rumus Inversi Möbius:** Jika $g(n) = \\sum_{d \\mid n} f(d)$, maka:
$$f(n) = \\sum_{d \\mid n} \\mu(d) g\\left(\\frac{n}{d}\\right)$$
`,
    keyTheorems: [
      {
        name: 'Inversi Möbius Polinomial Siklotomik',
        statement: '$\\Phi_n(x) = \\prod_{d \\mid n} (x^{n/d} - 1)^{\\mu(d)}$.',
        proofOutline: 'Mengambil logaritma dari $x^n - 1 = \\prod_{d \\mid n} \\Phi_d(x)$ dan menerapkan rumus inversi Möbius.',
        exampleProblem: 'Hitung $\\Phi_{12}(x)$ secara eksplisit.'
      }
    ],
    tips: [
      'Faktor prima dari $\\Phi_n(a)$ untuk $a \\in \\mathbb{Z}$ selalu bernilai $p \\equiv 1 \\pmod n$ atau $p \\mid n$.',
      'Gunakan inversi Möbius saat menghitung fungsi multiplikatif yang melibatkan pembagi.'
    ]
  },
  {
    id: 'th-geo-projective-harmonic',
    topic: 'Geometri',
    title: 'Geometri Proyektif, Cross Ratio, & Kutub (Pole-Polar)',
    subtitle: 'Harmonic Bundles $(A, B; C, D) = -1$, Teorema Pascal, Brianchon, dan Circle of Apollonius',
    summary: 'Metode geometri proyektif mutakhir untuk membuktikan titik-titik segaris (kolinear) dan garis-garis berpotongan di satu titik (konkuren) tanpa perhitungan panjang.',
    content: `
### 1. Rasio Silang (Cross Ratio) & Berkas Harmonik
Diberikan 4 titik segaris $A, B, C, D$. Rasio silang didefinisikan sebagai:
$$(A, B; C, D) = \\frac{AC / CB}{AD / DB}$$
Empat titik membentuk **Sistem Harmonik** jika $(A, B; C, D) = -1$.
- Sifat Kunci: Garis bagi sudut dalam dan luar dari suatu segitiga membagi sisi seberang secara harmonik.

### 2. Kutub dan Garis Kutub (Pole and Polar)
Untuk titik $P$ dan lingkaran $\\omega$ berpusat $O$ jari-jari $R$:
- Garis kutub dari $P$ terhadap $\\omega$ adalah garis tegak lurus $OP$ yang berjarak $d = R^2 / OP$ dari $O$.
- **Teorema La Hire:** Titik $P$ terletak pada garis kutub $Q$ jika dan hanya jika $Q$ terletak pada garis kutub $P$.

### 3. Teorema Pascal & Brianchon
- **Teorema Pascal:** Jika heksagon $ABCDEF$ diinskripsikan pada suatu konik (lingkaran), maka 3 titik potong pasangan sisi berhadapan $(AB \\cap DE, BC \\cap EF, CD \\cap FA)$ adalah **kolinear**.
- **Teorema Brianchon:** Jika heksagon $ABCDEF$ dieskripsikan pada konik, maka 3 diagonal utamanya $(AD, BE, CF)$ adalah **konkuren**.
`,
    keyTheorems: [
      {
        name: 'Teorema Pascal (Hexagrammum Mysticum)',
        statement: 'Titik potong pasangan sisi berlawanan dari segi-6 dalam lingkaran selalu segaris.',
        proofOutline: 'Menggunakan Teorema Menelaus 3 kali pada segitiga yang dibentuk oleh perpanjangan sisi heksagon.',
        exampleProblem: 'Buktikan bahwa garis Simson dari dua titik berseberangan berpotongan tegak lurus.'
      },
      {
        name: 'Teorema La Hire',
        statement: 'Hubungan timbal balik simetris antara titik kutub dan garis kutub terhadap konik.',
        proofOutline: 'Menggunakan sifat inversi dan kuasa titik terhadap lingkaran.',
        exampleProblem: 'Buktikan bahwa garis yang menghubungkan titik-titik singgung adalah garis kutub.'
      }
    ],
    tips: [
      'Gunakan rasio silang $(A, B; C, D) = -1$ saat ada segiempat lengkap (complete quadrangle).',
      'Garis kutub sangat ampuh ketika ada banyak garis singgung lingkaran dari satu titik luar.'
    ]
  },
  {
    id: 'th-nt-quadratic-reciprocity',
    topic: 'Teori Bilangan',
    title: 'Residu Kuadratik, Simbol Legendre, & Persamaan Pell',
    subtitle: 'Hukum Resiplositas Kuadratik Gauss, Lemma Gauss, dan Persamaan $x^2 - d y^2 = 1$',
    summary: 'Topik klasik teori bilangan yang membahas keterbagian kuadrat modulo $p$ serta struktur solusi bulat dari persamaan kuadrat dua variabel.',
    content: `
### 1. Simbol Legendre $\\left(\\frac{a}{p}\\right)$
Untuk prima ganjil $p$ dan $p \\nmid a$:
$$\\left(\\frac{a}{p}\\right) = \\begin{cases} 1 & \\text{jika } x^2 \\equiv a \\pmod p \\text{ memiliki solusi} \\\\ -1 & \\text{jika tidak Memiliki solusi} \\end{cases}$$

### 2. Hukum Resiplositas Kuadratik Gauss
Untuk dua bilangan prima ganjil berbeda $p$ dan $q$:
$$\\left(\\frac{p}{q}\\right) \\left(\\frac{q}{p}\\right) = (-1)^{\\frac{p-1}{2} \\frac{q-1}{2}}$$
Artinya $\\left(\\frac{p}{q}\\right) = \\left(\\frac{q}{p}\\right)$ kecuali jika $p \\equiv q \\equiv 3 \\pmod 4$.

**Suplemen Tambahan:**
- $\\left(\\frac{-1}{p}\\right) = (-1)^{(p-1)/2}$ (bernilai $1 \\iff p \\equiv 1 \\pmod 4$)
- $\\left(\\frac{2}{p}\\right) = (-1)^{(p^2-1)/8}$ (bernilai $1 \\iff p \\equiv \\pm 1 \\pmod 8$)

### 3. Persamaan Pell $x^2 - d y^2 = 1$
Diberikan $d$ bulat positif bukan kuadrat.
- Solusi fundamental terkecil $(x_1, y_1)$ selalu ada (dapat dicari via pecahan berlanjut / continued fractions).
- Seluruh solusi $(x_n, y_n)$ diperoleh dari pemangkatan:
  $$x_n + y_n \\sqrt{d} = (x_1 + y_1 \\sqrt{d})^n$$
`,
    keyTheorems: [
      {
        name: 'Hukum Resiplositas Kuadratik',
        statement: 'Menghubungkan keberadaan solusi $x^2 \\equiv p \\pmod q$ dengan $x^2 \\equiv q \\pmod p$.',
        proofOutline: 'Menggunakan Sum Gauss (Gauss Sums) pada lapangan berhingga atau kisi Eisenstein.',
        exampleProblem: 'Tentukan semua bilangan prima $p$ sehingga $5$ adalah residu kuadratik modulo $p$.'
      },
      {
        name: 'Teorema Solusi Persamaan Pell',
        statement: 'Persamaan $x^2 - d y^2 = 1$ memiliki tak hingga banyaknya solusi positif untuk $d$ non-kuadrat.',
        proofOutline: 'Menggunakan Teorema Aprowsimasi Dirichlet pada $\\sqrt{d}$ dan Pigeonhole Principle.',
        exampleProblem: 'Cari semua solusi bulat positif untuk $x^2 - 2y^2 = 1$.'
      }
    ],
    tips: [
      'Gunakan simbol Legendre untuk membuktikan suatu persamaan Diophantine tidak memiliki solusi modulo $p$.',
      'Ubah bentuk $x^2 - d y^2 = 1$ menjadi faktorisasi aljabar $(x - y\\sqrt{d})(x + y\\sqrt{d}) = 1$.'
    ]
  },
  {
    id: 'th-komb-generating-functions',
    topic: 'Kombinatorika',
    title: 'Fungsi Pembangkit & Bilangan Catalan',
    subtitle: 'Ordinary Generating Functions (OGF), Exponential Generating Functions (EGF), dan Rekursi Combinatorial',
    summary: 'Teknik analitik kombinatorik paling ampuh yang mengubah masalah pencacahan diskrit menjadi manipulasi deret kuasa dan aljabar polinomial.',
    content: `
### 1. Fungsi Pembangkit Biasa (Ordinary Generating Function - OGF)
Misalkan $a_0, a_1, a_2, \\dots$ adalah barisan kombinatorik. Fungsi pembangkitnya didefinisikan sebagai:
$$A(x) = \\sum_{n=0}^{\\infty} a_n x^n$$
- Operasi Pergeseran: $x A(x) = \\sum_{n=1}^{\\infty} a_{n-1} x^n$
- Perkalian Konyol: $A(x)B(x) = \\sum_{n=0}^{\\infty} \\left( \\sum_{k=0}^n a_k b_{n-k} \\right) x^n$

### 2. Bilangan Catalan $C_n$
Barisan $C_n = 1, 1, 2, 5, 14, 42, 132, \\dots$ memenuhi rekursi:
$$C_{n+1} = \\sum_{i=0}^n C_i C_{n-i}, \\quad C_0 = 1$$
Rumus Eksplisit:
$$C_n = \\frac{1}{n+1} \\binom{2n}{n} = \\binom{2n}{n} - \\binom{2n}{n+1}$$
Aplikasi Catalan:
- Banyaknya tanda kurung sah dari $n$ pasang kurung.
- Banyaknya trianggulasi dari poligon segi-$(n+2)$.
- Banyaknya lintasan Dyck pada kisi $n \\times n$ yang tidak melewati diagonal.
`,
    keyTheorems: [
      {
        name: 'Bentuk Tertutup OGF Catalan',
        statement: 'Fungsi pembangkit $C(x) = \\sum C_n x^n$ memenuhi $x C(x)^2 - C(x) + 1 = 0 \\implies C(x) = \\frac{1 - \\sqrt{1-4x}}{2x}$.',
        proofOutline: 'Menggunakan rumus kuadratik aljabar pada persamaan rekursi $C(x) = 1 + x C(x)^2$ dan ekspansi Binomial Newton.',
        exampleProblem: 'Hitung banyaknya jalur terpendek dari $(0,0)$ ke $(n,n)$ yang tidak berada di atas garis $y = x$.'
      }
    ],
    tips: [
      'Gunakan OGF ketika masalah pencacahan melibatkan susunan tak berurut (kombinasi).',
      'Gunakan EGF ($A(x) = \\sum a_n \\frac{x^n}{n!}$) ketika masalah melibatkan susunan berurut (permutasi).'
    ]
  },
  {
    id: 'th-aljabar-complex-geometry',
    topic: 'Aljabar',
    title: 'Bilangan Kompleks pada Geometri Olimpiade',
    subtitle: 'Vektor Kompleks, Lingkaran Satuan $z\\bar{z} = 1$, Siklisitas Kompleks, dan Keserupaan Spiral',
    summary: 'Menerjemahkan titik-titik geometri menjadi bilangan kompleks $z \\in \\mathbb{C}$ untuk mengubah pembuktian geometri yang rumit menjadi aljabar aljabar murni.',
    content: `
### 1. Representasi Titik & Operasi Dasar
Setiap titik $P(x,y)$ dinyatakan sebagai $z = x + i y$.
- **Jarak:** $|z_1 - z_2| = \\sqrt{(x_1 - x_2)^2 + (y_1 - y_2)^2}$
- **Konjugat:** $\\bar{z} = x - i y \\implies z \\bar{z} = |z|^2$
- **Titik Tengah:** $m = \\frac{a + b}{2}$
- **Titik Berat:** $g = \\frac{a + b + c}{3}$

### 2. Rumus Geometris Utama
- **Keserupaan Segitiga:** $\\triangle ABC \\sim \\triangle DEF$ (dengan orientasi sama) jika dan hanya jika:
  $$\\frac{c - a}{b - a} = \\frac{f - d}{e - d}$$
- **Kesejajaran & Ketegaklurusan:**
  * Garis $AB \\parallel CD \\iff \\frac{a - b}{c - d} \\in \\mathbb{R} \\iff \\frac{a - b}{c - d} = \\frac{\\bar{a} - \\bar{b}}{\\bar{c} - \\bar{d}}$
  * Garis $AB \\perp CD \\iff \\frac{a - b}{c - d} \\in i\\mathbb{R} \\iff \\frac{a - b}{c - d} = -\\frac{\\bar{a} - \\bar{b}}{\\bar{c} - \\bar{d}}$

### 3. Trik Lingkaran Satuan (Unit Circle Trick)
Setel Lingkaran Luar $\\triangle ABC$ sebagai lingkaran satuan berpusat di asal ($|a| = |b| = |c| = 1$).
- Sifat Khusus: $\\bar{a} = \\frac{1}{a}, \\bar{b} = \\frac{1}{b}, \\bar{c} = \\frac{1}{c}$.
- **Ortosenter $H$:** $h = a + b + c$.
- **Pusat Sembilan Titik $N$:** $n = \\frac{a + b + c}{2}$.
- **Proyeksi $P$ pada Garis $AB$:** $p = \\frac{1}{2}\\left(a + b + z - a b \\bar{z}\\right)$.
`,
    keyTheorems: [
      {
        name: 'Teorema Euler Line Kompleks',
        statement: 'Titik Berat $G$, Ortosenter $H$, dan Pusat Lingkaran Luar $O$ segaris dengan $h = 3g$.',
        proofOutline: 'Substitusi $o = 0, g = (a+b+c)/3, h = a+b+c$ dalam sistem koordinat kompleks.',
        exampleProblem: 'Buktikan bahwa titik tengah segmen $OH$ adalah pusat lingkaran sembilan titik.'
      }
    ],
    tips: [
      'Gunakan trik $z\\bar{z} = 1$ ketika masalah berkaitan erat dengan lingkaran luar segitiga.',
      'Rotasi sebesar sudut $\\theta$ dilakukan dengan mengalikan vektor dengan $e^{i\\theta}$.'
    ]
  },
  {
    id: 'th-nt-p-adic-hensel',
    topic: 'Teori Bilangan',
    title: 'Lemma Valuasi $v_p(n)$, Hensel\'s Lemma, & Zsigmondy',
    subtitle: 'Ekspansi p-Adic, Lifting Roots Modulo $p^k$, dan Teorema Zsigmondy',
    summary: 'Teknik teori bilangan mutakhir untuk menangani keterbagian berpangkat tinggi $p^k$ dan keberadaan faktor prima baru pada barisan eksponensial.',
    content: `
### 1. Hensel's Lifting Lemma
Misalkan $P(x)$ adalah polinomial berkoefisien bulat. Jika $r$ adalah akar modulo $p^k$, yaitu $P(r) \\equiv 0 \\pmod{p^k}$, dan $P'(r) \\not\\equiv 0 \\pmod p$, maka terdapat akar tunggal $r_{k+1}$ modulo $p^{k+1}$ sehingga:
$$r_{k+1} \\equiv r \\pmod{p^k} \\quad \\text{dan} \\quad P(r_{k+1}) \\equiv 0 \\pmod{p^{k+1}}$$

### 2. Teorema Zsigmondy
Misalkan $a > b \\ge 1$ adalah bilangan bulat positif yang relatif prima. Untuk setiap $n > 1$, terdapat setidaknya satu faktor prima $p$ yang membagi $a^n - b^n$ tetapi **TIDAK** membagi $a^k - b^k$ untuk semua $1 \\le k < n$, **kecuali** pada kasus-kasus berikut:
1. $2^6 - 1^6$ (karena $2^6 - 1 = 63 = 3^2 \\times 7$, faktor $7$ sudah membagi $2^3-1$).
2. $a + b = 2^k$ untuk $n = 2$.
`,
    keyTheorems: [
      {
        name: 'Teorema Zsigmondy',
        statement: 'Setiap suku $a^n - b^n$ hampir selalu memiliki faktor prima baru (primitive prime divisor).',
        proofOutline: 'Menggunakan analisis polinomial siklotomik $\\Phi_n(a,b)$ dan sifat keterbagian p-adic.',
        exampleProblem: 'Cari semua solusi bulat positif untuk $2^n + 1 = 3^k$.'
      }
    ],
    tips: [
      'Gunakan Teorema Zsigmondy untuk langsung mengeliminasi kasus persamaan eksponensial $a^n \pm b^n = c^k$.',
      'Hensel Lemma sangat berguna saat membuktikan keberadaan residu pangkat ke-$k$ modulo $p^n$.'
    ]
  },
  {
    id: 'th-komb-invariance-games',
    topic: 'Kombinatorika',
    title: 'Prinsip Invarian, Monovarian, & Teori Permainan',
    subtitle: 'Paritas Invarian, Fungsi Potensial (Monovarian), dan Teorema Sprague-Grundy (Nim-Sum)',
    summary: 'Studi strategi kombinatorik pada proses berulang, papan catur, dan permainan matematika 2 pemain yang adil.',
    content: `
### 1. Invarian & Monovarian
- **Invarian:** Kuantitas $I(S)$ yang nilainya **tetap sama** di setiap langkah transformasi state $S_0 \\to S_1 \\to S_2 \\dots$. Jika $I(S_0) \\neq I(S_{\\text{target}})$, maka state target **tidak akan pernah tercapai**.
- **Monovarian:** Kuantitas $M(S)$ yang nilainya **selalu naik** (atau selalu turun) secara ketat di setiap langkah. Karena bernilai bulat/terbatas, proses pasti **berhenti** dalam berhingga langkah.

### 2. Teori Permainan Imparsial & Sprague-Grundy
Setiap permainan 2 pemain tanpa faktor keberuntungan yang adil (impartial game) dapat dipetakan ke **Nilai Grundy / Nim-Value** $G(x)$:
$$G(x) = \\text{mex}\\{ G(y) : y \\text{ adalah posisi yang dapat dicapai dari } x \\}$$
Di mana $\\text{mex}$ (minimum excludant) adalah bilangan cacah terkecil yang tidak ada dalam himpunan.
- **Teorema Sprague-Grundy:** Nilai Grundy gabungan dari beberapa permainan independen adalah **Nim-Sum (XOR bitwise $\\oplus$)** dari nilai Grundy masing-masing.
- Posisi Kalah (Previous Player Win / P-position): $G(x) = 0$.
- Posisi Menang (Next Player Win / N-position): $G(x) > 0$.
`,
    keyTheorems: [
      {
        name: 'Teorema Sprague-Grundy',
        statement: 'Setiap permainan imparsial berhingga ekuivalen dengan tumpukan permainan Nim tunggal.',
        proofOutline: 'Induksi pada graf posisi permainan aciklik berhingga (DAG).',
        exampleProblem: 'Diberikan 3 tumpukan batu berukuran 3, 4, 5. Tentukan pemain mana yang memiliki strategi menang.'
      }
    ],
    tips: [
      'Uji modulo 2 (paritas) atau modulo 3 sebagai calon invarian pertama.',
      'Gunakan strategi simetri: tiru langkah lawan jika papan/permainan memiliki simetri cermin atau rotasi.'
    ]
  },
  {
    id: 'th-geo-spiral-similarity',
    topic: 'Geometri',
    title: 'Keserupaan Spiral (Spiral Similarity) & Pusat Miquel',
    subtitle: 'Rotasi + Dilatasi, Pusat Miquel Segiempat, dan Lingkaran Miquel',
    summary: 'Eksplorasi keserupaan transformasi berpusat tunggal yang menggabungkan rotasi sudut dan dilatasi rasio untuk membuktikan hubungan segitiga sebangun.',
    content: `
### 1. Definis Keserupaan Spiral
Transformasi Keserupaan Spiral $S(M, \\theta, k)$ dengan pusat $M$, sudut rotasi $\\theta$, dan faktor skala $k$ memetakan titik $P$ ke $P'$ sehingga:
1. $MP' = k \\cdot MP$
2. $\\angle PMP' = \\theta$ (sudut terarah)

### 2. Sifat Kunci Keserupaan Pasangan Segmen
Jika $S$ memetakan segmen $AB$ ke $CD$, maka:
1. $S$ juga memetakan segmen $AC$ ke $BD$.
2. Pusat keserupaan $M$ adalah titik potong lingkaran luar $\\triangle PAC$ dan $\\triangle PBD$ (di mana $P = AB \\cap CD$).

### 3. Titik Miquel dari Segiempat Lengkap
Empat garis saling memotong membentuk 4 segitiga. Lingkaran luar dari keempat segitiga ini berpotongan di satu titik tunggal $M$, yang disebut **Titik Miquel**.
- Titik Miquel $M$ adalah pusat keserupaan spiral yang memetakan segmen-segmen berseberangan dari segiempat tersebut.
`,
    keyTheorems: [
      {
        name: 'Teorema Titik Miquel',
        statement: 'Lingkaran luar dari 4 segitiga yang dibentuk oleh 4 garis selalu berpotongan di satu titik.',
        proofOutline: 'Menggunakan pelacak sudut terarah (directed angle chasing) pada segiempat siklik.',
        exampleProblem: 'Buktikan bahwa proyeksi ortogonal titik Miquel pada keempat garis adalah kolinear (Garis Simson).'
      }
    ],
    tips: [
      'Gunakan keserupaan spiral saat ada dua segitiga sebangun $\\triangle MAB \\sim \\triangle MCD$ yang berbagi satu titik sudut $M$.',
      'Ingat bahwa $M$ selalu merupakan pusat keserupaan ganda ($AB \\to CD$ dan $AC \\to BD$).'
    ]
  },
  {
    id: 'th-geo-inversion',
    topic: 'Geometri',
    title: 'Inversi Lingkaran & Geometri Inversif',
    subtitle: 'Transformasi Inversi $(O, R^2)$, Peta Garis/Lingkaran, Orthogonal Circles, dan Teorema Ptolemy',
    summary: 'Transformasi geometri tingkat tinggi yang memetakan lingkaran dan garis menjadi lingkaran atau garis baru, sangat ampuh untuk menyederhanakan konfigurasi bersinggungan.',
    content: `
### 1. Definisi Transformasi Inversi
Inversi terhadap lingkaran $\\omega$ berpusat $O$ dengan jari-jari $R$ memetakan titik $P \\neq O$ ke titik $P'$ pada sinar $OP$ sedemikian rupa sehingga:
$$OP \\cdot OP' = R^2$$

### 2. Sifat-Sifat Pemetaan Inversi
1. **Garis melalui $O$** dipetakan ke **dirinya sendiri**.
2. **Garis tidak melalui $O$** dipetakan ke **lingkaran yang melalui $O$**.
3. **Lingkaran melalui $O$** dipetakan ke **garis tidak melalui $O$**.
4. **Lingkaran tidak melalui $O$** dipetakan ke **lingkaran lain yang tidak melalui $O$**.
5. **Sudut Antar Kurva (Preservation of Angles):** Inversi mempertahankan besar sudut antar kurva (konformal), namun membalik orientasi arah.

### 3. Jarak Antar Titik Terinversi
Untuk dua titik $A$ dan $B$, jarak antara bayangan terinversinya $A'$ dan $B'$ memenuhi rumus:
$$A'B' = A B \\cdot \\frac{R^2}{OA \\cdot OB}$$
`,
    keyTheorems: [
      {
        name: 'Pembuktian Teorema Ptolemy via Inversi',
        statement: 'Untuk segiempat $ABCD$, berlaku $AB \\cdot CD + AD \\cdot BC \\ge AC \\cdot BD$, dengan kesamaan jika dan hanya jika $ABCD$ siklik.',
        proofOutline: 'Lakukan inversi berpusat di $A$ dengan jari-jari $R$. Titik $B, C, D$ dipetakan ke $B\', C\', D\'$. Gunakan ketaksamaan segitiga $B\'C\' + C\'D\' \\ge B\'D\'$.',
        exampleProblem: 'Buktikan pertidaksamaan Ptolemy untuk 4 titik acak pada bidang datar.'
      }
    ],
    tips: [
      'Pilih pusat inversi $O$ pada titik di mana banyak lingkaran bersinggungan atau berpotongan.',
      'Ingat bahwa lingkaran bersinggungan di $O$ akan berubah menjadi dua garis sejajar setelah inversi.'
    ]
  },
  {
    id: 'th-nt-primitive-roots',
    topic: 'Teori Bilangan',
    title: 'Akar Primitif & Orde Modulo',
    subtitle: 'Orde Elemen $\\text{ord}_p(a)$, Teorema Akar Primitif Gauss, dan Logaritma Diskrit',
    summary: 'Studi struktur grup multiplikatif $(\\mathbb{Z}/n\\mathbb{Z})^\\times$, sifat siklik modulo $p$, dan aplikasi orde pada keterbagian eksponensial.',
    content: `
### 1. Orde Modulo $\\text{ord}_n(a)$
Misalkan $\\gcd(a, n) = 1$. **Orde dari $a$ modulo $n$** (ditulis $\\text{ord}_n(a)$) adalah bilangan bulat positif terkecil $k$ sehingga:
$$a^k \\equiv 1 \\pmod n$$
**Sifat Kunci:**
- Jika $a^m \\equiv 1 \\pmod n$, maka $\\text{ord}_n(a) \\mid m$.
- Berdasarkan Teorema Euler, $\\text{ord}_n(a) \\mid \\phi(n)$.

### 2. Akar Primitif (Primitive Roots)
Elemen $g$ disebut **akar primitif** modulo $n$ jika $\\text{ord}_n(g) = \\phi(n)$.
- **Teorema Gauss:** Akar primitif ada jika dan hanya jika $n = 2, 4, p^k, 2p^k$ di mana $p$ adalah prima ganjil.
- Jika $g$ adalah akar primitif modulo $p$, maka perpangkatan $\\{g^1, g^2, \\dots, g^{p-1}\\}$ menghasilkan seluruh sisa hasil bagi tak-nol modulo $p$.
`,
    keyTheorems: [
      {
        name: 'Teorema Keterbagian Orde Modulo',
        statement: 'Jika $a^x \\equiv a^y \\pmod n$ dengan $\\gcd(a,n)=1$, maka $x \\equiv y \\pmod{\\text{ord}_n(a)}$.',
        proofOutline: 'Tulis $x - y = q \\cdot \\text{ord}_n(a) + r$ di mana $0 \\le r < \\text{ord}_n(a)$ dan gunakan definisi orde terkecil.',
        exampleProblem: 'Tentukan semua bilangan bulat positif $n$ sedemikian rupa sehingga $n \\mid 2^n - 1$.'
      }
    ],
    tips: [
      'Gunakan orde modulo ketika menganalisis pembagi prima dari ekspresi berbentuk $a^n - 1$ atau $a^n + 1$.',
      'Jika $p \\mid a^n - 1$, maka $\\text{ord}_p(a) \\mid n$ dan $\\text{ord}_p(a) \\mid p - 1$.'
    ]
  },
  {
    id: 'th-aljabar-smoothing-tangent',
    topic: 'Aljabar',
    title: 'Metode Garis Singgung & Sum of Squares (SOS)',
    subtitle: 'Tangent Line Method, SOS (Sum of Squares Decomposition), dan Cauchy-Schwarz Modifikasi',
    summary: 'Teknik analitik aljabar untuk menyelesaikan pertidaksamaan simetris non-linier berderajat tinggi dengan memanfaatkan garis singgung atau pemfaktoran kuadrat sempurna.',
    content: `
### 1. Metode Garis Singgung (Tangent Line Method)
Diberikan pertidaksamaan simetris $\\sum_{i=1}^n f(x_i) \\ge C$ dengan syarat $\\sum x_i = S$.
1. Cari titik simetris kesamaan $x_1 = x_2 = \\dots = x_n = x_0 = S/n$.
2. Buat garis singgung $L(x) = f'(x_0)(x - x_0) + f(x_0)$.
3. Buktikan pertidaksamaan lokal $f(x) \\ge L(x)$ untuk semua $x$ pada domain.
4. Jumlahkan untuk semua $i$:
   $$\\sum_{i=1}^n f(x_i) \\ge \\sum_{i=1}^n L(x_i) = f'(x_0)\\left(\\sum x_i - n x_0\\right) + n f(x_0) = n f(x_0) = C$$

### 2. Metode Sum of Squares (SOS)
Mengubah bentuk $P(a, b, c) \\ge 0$ menjadi kombinasi kuadrat sempurna:
$$P(a, b, c) = S_a (b - c)^2 + S_b (c - a)^2 + S_c (a - b)^2 \\ge 0$$
Syarat cukup: $S_a, S_b, S_c \\ge 0$ atau $S_a + S_b \\ge 0, S_b + S_c \\ge 0, S_c + S_a \\ge 0$.
`,
    keyTheorems: [
      {
        name: 'Metode Garis Singgung pada Pertidaksamaan',
        statement: 'Jika $f(x) \\ge f\'(x_0)(x-x_0) + f(x_0)$, maka $\\sum f(x_i) \\ge n f(S/n)$.',
        proofOutline: 'Menggunakan sifat turunan dan konveksitas lokal di sekitar titik kesamaan.',
        exampleProblem: 'Buktikan $\\frac{a}{b+c+1} + \\frac{b}{c+a+1} + \\frac{c}{a+b+1} \\le 1$ untuk $a,b,c \\ge 0$ dengan $a+b+c=1$.'
      }
    ],
    tips: [
      'Periksa apakah fungsi lokal $f(x)$ cekung/cembung di sekitar titik kesamaan sebelum menggunakan garis singgung.',
      'Jika ada batas yang melanggar di dekat ujung domain, gunakan pembagian kasus (boundary check).'
    ]
  },
  {
    id: 'th-komb-probabilistic-method',
    topic: 'Kombinatorika',
    title: 'Metode Probabilistik pada Kombinatorika IMO',
    subtitle: 'Nilai Harapan (Expectation), Linieritas Ekseptasi, Lovász Local Lemma, dan Konstruksi Acak',
    summary: 'Metode revolusioner Paul Erdős yang membuktikan keberadaan objek kombinatorik dengan menunjukkan probabilitas positif pada ruang sampel acak.',
    content: `
### 1. Prinsip Dasar Nilai Harapan
Jika variabel acak $X$ didefinisikan pada ruang sampel berhingga dan memiliki nilai harapan $\\mathbb{E}[X] = \nmu$, maka:
1. Terdapat setidaknya satu elemen ruang sampel dengan $X \\ge \\mu$.
2. Terdapat setidaknya satu elemen ruang sampel dengan $X \\le \\mu$.

### 2. Linieritas Nilai Harapan (Linearity of Expectation)
Untuk sembarang variabel acak $X_1, X_2, \\dots, X_n$ (bahkan jika **Saling Bergantung / Dependent**):
$$\\mathbb{E}[X_1 + X_2 + \\dots + X_n] = \\mathbb{E}[X_1] + \\mathbb{E}[X_2] + \\dots + \\mathbb{E}[X_n]$$

### 3. Lovász Local Lemma (Sederhana)
Misalkan $A_1, A_2, \\dots, A_n$ adalah kejadian-kejadian buruk yang masing-masing terjadi dengan probabilitas $P(A_i) \\le p$. Jika setiap kejadian bergantung pada paling banyak $d$ kejadian lainnya, dan:
$$e \\cdot p \\cdot (d + 1) \\le 1$$
Maka probabilitas bahwa **TIDAK ADA** kejadian buruk yang terjadi adalah **positif strictly** ($P(\\bigcap \\overline{A_i}) > 0$).
`,
    keyTheorems: [
      {
        name: 'Teorema Nilai Harapan Erdős',
        statement: 'Setiap graf dengan $n$ simpul dan $m$ sisi memiliki subgraf bipartit dengan sekurang-kurangnya $m/2$ sisi.',
        proofOutline: 'Pilih himpunan simpul $V_1$ secara acak dengan memasukkan tiap simpul dengan probabilitas $1/2$. Hitung ekspektasi jumlah sisi antara $V_1$ dan $V \\setminus V_1$.',
        exampleProblem: 'Buktikan bahwa setiap tournament $n$ simpul memiliki Hamiltonian path jika $n$ cukup besar.'
      }
    ],
    tips: [
      'Gunakan variabel indikator $X_i \\in \\{0, 1\\}$ untuk menghitung ekspektasi $\\mathbb{E}[X_i] = P(X_i = 1)$.',
      'Ingat bahwa linieritas nilai harapan TIDAK membutuhkan independensi variabel acak!'
    ]
  },
  {
    id: 'th-geo-casey-mixtilinear',
    topic: 'Geometri',
    title: 'Teorema Casey & Lingkaran Mixtilinear',
    subtitle: 'Generalisasi Teorema Ptolemy untuk 4 Lingkaran Singgung, Mixtilinear Incircles, dan Panjang Tangen Persekutuan',
    summary: 'Teorema Casey adalah perkalian jarak tangen persekutuan luar dari empat lingkaran yang bersinggungan dengan satu lingkaran besar. Sangat ampuh untuk soal geometri IMO kelas berat.',
    content: `
### 1. Teorema Casey (Generalized Ptolemy Theorem)
Misalkan $O_1, O_2, O_3, O_4$ adalah empat lingkaran yang bersinggungan secara internal (atau eksternal) dengan suatu lingkaran besar $\\Omega$ dalam urutan melingkar. Misalkan $t_{ij}$ menyatakan panjang garis singgung persekutuan luar antara lingkaran $O_i$ dan $O_j$. Maka berlaku:
$$t_{12} \\cdot t_{34} + t_{23} \\cdot t_{14} = t_{13} \\cdot t_{24}$$

*Catatan:* Jika lingkaran $O_i$ berdegenerasi menjadi satu titik, Teorema Casey berubah menjadi **Teorema Ptolemy Klasik**.

### 2. Lingkaran Mixtilinear (Mixtilinear Incircle)
Lingkaran $A$-mixtilinear incircle $\\omega_A$ adalah lingkaran yang bersinggungan dengan sisi $AB, AC$ dan bersinggungan internal dengan lingkaran luar $\\Omega$ dari $\\triangle ABC$.
- Misalkan $T_A$ adalah titik singgung $\\omega_A$ dengan $\\Omega$.
- Sifat Kunci: Garis $AT_A$ dan garis singgung di $T_A$ berpotongan dengan $BC$ di titik-titik yang memenuhi hubungan simedian dan inversi.
- Titik tengah busur $BC$ dari $\\Omega$ ($M$) dan pusat lingkaran dalam $I$ terletak pada satu garis lurus dengan $T_A$.
`,
    keyTheorems: [
      {
        name: 'Teorema Casey',
        statement: '$t_{12} t_{34} + t_{23} t_{14} = t_{13} t_{24}$ untuk 4 lingkaran yang bersinggungan dengan lingkaran kelima.',
        proofOutline: 'Menggunakan Inversi Lingkaran atau rumus jarak tangen $t_{ij}^2 = d(O_i, O_j)^2 - (r_i \\mp r_j)^2$ serta hukum kosinus.',
        exampleProblem: 'Buktikan bahwa lingkaran dalam bersinggungan dengan lingkaran sembilan titik (Teorema Feuerbach).'
      },
      {
        name: 'Lemma Lingkaran Mixtilinear',
        statement: 'Titik singgung $T_A$, Pusat Incircle $I$, dan Titik Tengah Busur $BC$ ($M_A$) adalah kolinear.',
        proofOutline: 'Menggunakan Homoteti (dilatasi) yang memetakan $\\omega_A$ ke lingkaran luar $\\Omega$ berpusat di $T_A$.',
        exampleProblem: 'Buktikan bahwa garis $T_A I$ memotong lingkaran luar di titik tengah busur $BC$.'
      }
    ],
    tips: [
      'Gunakan Teorema Casey ketika membuktikan keberadaan lingkaran persekutuan yang bersinggungan dengan 4 lingkaran.',
      'Manfaatkan dilatasi berpusat di $T_A$ untuk memindahkan sifat-sifat incircle ke lingkaran luar.'
    ]
  },
  {
    id: 'th-nt-crt-squares',
    topic: 'Teori Bilangan',
    title: 'Teorema Sisa Cina Lanjut & Jumlah Kuadrat',
    subtitle: 'Advanced Chinese Remainder Theorem (CRT), Teorema Dua Kuadrat Fermat, dan Teorema Empat Kuadrat Lagrange',
    summary: 'Konstruksi sistem kongruensi simultan dan pembuktian reprezentasi bilangan bulat sebagai jumlah dua, tiga, atau empat kuadrat sempurna.',
    content: `
### 1. Teorema Sisa Cina (Chinese Remainder Theorem - CRT)
Diberikan sistem kongruensi simultan:
$$x \\equiv a_1 \\pmod{m_1}, \\quad x \\equiv a_2 \\pmod{m_2}, \\quad \\dots, \\quad x \\equiv a_k \\pmod{m_k}$$
Jika $m_1, m_2, \\dots, m_k$ **saling prima sepasang** (pairwise coprime), maka terdapat solusi tunggal $x$ modulo $M = m_1 m_2 \\dots m_k$.
- **Rumus Solusi:** $x = \\sum_{i=1}^k a_i M_i y_i \\pmod M$, di mana $M_i = M / m_i$ dan $y_i \\equiv M_i^{-1} \\pmod{m_i}$.

### 2. Teorema Dua Kuadrat Fermat
Suatu bilangan bulat positif $n > 1$ dapat dituliskan sebagai jumlah dua kuadrat sempurna $n = x^2 + y^2$ jika dan hanya jika dalam faktorisasi primanya:
Setiap faktor prima berbentuk $p \\equiv 3 \\pmod 4$ memiliki pangkat **genap**.

### 3. Teorema Empat Kuadrat Lagrange
Setiap bilangan bulat positif $n$ dapat dinyatakan sebagai jumlah dari **empat kuadrat sempurna**:
$$n = a^2 + b^2 + c^2 + d^2, \\quad a, b, c, d \\in \\mathbb{Z}$$
`,
    keyTheorems: [
      {
        name: 'Teorema Sisa Cina (CRT)',
        statement: 'Sistem kongruensi modulo saling prima memiliki solusi unik modulo perkalian modulosnya.',
        proofOutline: 'Konstruksi eksplisit menggunakan invers elemen $M_i y_i \\equiv 1 \\pmod{m_i}$.',
        exampleProblem: 'Tentukan bilangan bulat positif terkecil $x$ yang bersisa $2$ mod $3$, $3$ mod $5$, dan $2$ mod $7$.'
      },
      {
        name: 'Teorema Dua Kuadrat Fermat',
        statement: 'Prima $p \\equiv 1 \\pmod 4$ selalu dapat ditulis sebagai $p = a^2 + b^2$.',
        proofOutline: 'Menggunakan Thue\'s Lemma atau Kuadratik Gauss / Bilangan Bulat Gaussian $\\mathbb{Z}[i]$.',
        exampleProblem: 'Buktikan bahwa $2029$ (prima $1 \\pmod 4$) dapat dituliskan sebagai jumlah 2 kuadrat sempurna.'
      }
    ],
    tips: [
      'Gunakan identitas Brahmagupta-Fibonacci $(a^2+b^2)(c^2+d^2) = (ac-bd)^2 + (ad+bc)^2$ untuk mengalikan dua jumlah kuadrat.',
      'Jika $\\gcd(m_i, m_j) > 1$, syarat CRT adalah $a_i \\equiv a_j \\pmod{\\gcd(m_i, m_j)}$.'
    ]
  },
  {
    id: 'th-aljabar-chebyshev-finite-diff',
    topic: 'Aljabar',
    title: 'Polinomial Chebyshev & Beda Hingga',
    subtitle: 'Polinomial Chebyshev $T_n(x)$, Operator Beda Hingga $\\Delta^k P(x)$, dan Teorema Lagrange Interpolasi',
    summary: 'Studi polinomial dengan minimisasi deviasi ekstremal dan manipulasi operator selisih untuk membuktikan keterbagian serta sifat bulat dari nilai polinomial.',
    content: `
### 1. Polinomial Chebyshev Jenis Pertama $T_n(x)$
Didefinisikan melalui hubungan trigonometri untuk $x = \\cos \\theta$:
$$T_n(\\cos \\theta) = \\cos(n\\theta)$$
- Rekursi: $T_0(x) = 1$, $T_1(x) = x$, dan $T_{n+1}(x) = 2x T_n(x) - T_{n-1}(x)$.
- Sifat Minimisasi Ekstremal: Di antara semua polinomial monik berderajat $n$, $\\frac{1}{2^{n-1}} T_n(x)$ memiliki nilai maksimum terkecil $|P(x)|$ pada interval $[-1, 1]$.

### 2. Operator Beda Hingga (Finite Differences)
Untuk fungsi $P(x)$, definisikan $\\Delta P(x) = P(x+1) - P(x)$.
Beda tingkat ke-$k$: $\\Delta^k P(x) = \\Delta(\\Delta^{k-1}P(x))$.
- **Teorema Derajat:** Jika $P(x)$ adalah polinomial berderajat $n$:
  1. $\\Delta^n P(x) = n! \\cdot a_n$ (konstan).
  2. $\\Delta^{n+1} P(x) = 0$.
- **Rumus Ekspansi Binomial:**
  $$\\Delta^k P(0) = \\sum_{j=0}^k (-1)^{k-j} \\binom{k}{j} P(j)$$
`,
    keyTheorems: [
      {
        name: 'Teorema Polinomial Nilai Bulat (Integer-Valued Polynomials)',
        statement: 'Polinomial $P(x)$ bernilai bulat untuk semua $x \\in \\mathbb{Z}$ jika dan hanya jika $P(x) = \\sum c_k \\binom{x}{k}$ dengan $c_k \\in \\mathbb{Z}$.',
        proofOutline: 'Induksi pada derajat $n$ menggunakan operator beda hingga $\\Delta P(x)$.',
        exampleProblem: 'Buktikan bahwa $P(x) = \\frac{x^5 - 5x^3 + 4x}{120}$ bernilai bulat untuk semua $x \\in \\mathbb{Z}$.'
      }
    ],
    tips: [
      'Gunakan substitusi $x = \\frac{1}{2}\\left(z + \\frac{1}{z}\\right)$ untuk menyederhanakan $T_n(x) = \\frac{1}{2}\\left(z^n + z^{-n}\\right)$.',
      'Operator beda hingga sangat berguna saat diberi nilai $P(0), P(1), \\dots, P(n)$ pada titik bulat berurutan.'
    ]
  },
  {
    id: 'th-komb-dilworth-sperner',
    topic: 'Kombinatorika',
    title: 'Teorema Dilworth, Poset, & Sperner',
    subtitle: 'Partially Ordered Sets (Poset), Chain & Antichain, Teorema Dilworth, dan Teorema Sperner',
    summary: 'Analisis struktur himpunan terurut parsial (poset) untuk membagi objek kombinatorik menjadi rantai independen atau antichain maksimum.',
    content: `
### 1. Konsep Poset, Chain, & Antichain
Diberikan himpunan $P$ dengan relasi urutan parsial $\\le$:
- **Chain (Rantai):** Subhimpunan $C \\subseteq P$ di mana setiap dua elemen dapat dibandingkan ($x \\le y$ atau $y \\le x$).
- **Antichain:** Subhimpunan $A \\subseteq P$ di mana **TIDAK ADA** dua elemen berbeda yang dapat dibandingkan.

### 2. Teorema Dilworth
Dalam setiap poset berhingga $P$, ukuran **Antichain Maksimum** sama dengan jumlah minimum **Chain** yang saling lepas (disjoint) yang dibutuhkan untuk menutupi seluruh elemen $P$:
$$\\text{Ukuran Antichain Terbesar} = \\text{Jumlah Rantai Minimum Cover}$$

### 3. Teorema Sperner
Diberikan himpunan $S$ beranggotakan $n$ elemen. Ukuran maksimum dari keluarga subhimpunan dari $S$ di mana tidak ada subhimpunan yang memuat subhimpunan lainnya (antichain pada lattice subhimpunan) adalah:
$$|A| \\le \\binom{n}{\\lfloor n/2 \\rfloor}$$
`,
    keyTheorems: [
      {
        name: 'Teorema Sperner',
        statement: 'Banyaknya subhimpunan tak saling memuat maksimum dari himpunan $n$ elemen adalah $\\binom{n}{\\lfloor n/2 \\rfloor}$.',
        proofOutline: 'Menggunakan Ketaksamaan LYM (Lubell-Yamamoto-Meshalkin) dengan menghitung permutasi acak.',
        exampleProblem: 'Tentukan banyak subhimpunan maksimum dari $\\{1, 2, \\dots, 10\\}$ yang tidak saling memuat satu sama lain.'
      },
      {
        name: 'Teorema Dilworth',
        statement: 'Lebih maksimum antichain pada poset sama dengan pemutupan rantai minimum.',
        proofOutline: 'Induksi pada ukuran poset dan Teorema Match Hall pada Bipartite Graph.',
        exampleProblem: 'Buktikan bahwa dari $ab + 1$ bilangan real berbeda, terdapat barisan naik panjang $a+1$ atau turun panjang $b+1$ (Teorema Erdős-Szekeres).'
      }
    ],
    tips: [
      'Gunakan Teorema Erdős-Szekeres sebagai konsekuensi langsung dari Teorema Dilworth.',
      'Definisikan $x \\le y$ jika $x \\mid y$ untuk menerapkan Dilworth pada masalah keterbagian faktor.'
    ]
  },
  {
    id: 'th-geo-miquel-pivot',
    topic: 'Geometri',
    title: 'Teorema Miquel & Pivot Theorem',
    subtitle: 'Titik Miquel Segi-4 Kompleks, Lingkaran Miquel, dan Pivot Theorem pada Segitiga',
    summary: 'Pusat konformitas empat lingkaran yang berpotongan secara ajaib di satu titik (Titik Miquel). Kunci utama pembuktian segiempat siklik dan spiral similarity.',
    content: `
### 1. Miquel's Pivot Theorem
Diberikan segitiga $ABC$. Pilih titik $D, E, F$ berturut-turut pada garis $BC, CA, AB$.
Lingkaran luar $\\triangle AEF$, $\\triangle BFD$, dan $\\triangle CDE$ **selalu berpotongan di satu titik tunggal** $M$, yang disebut **Titik Miquel** dari $D, E, F$ terhadap $\\triangle ABC$.

### 2. Titik Miquel pada Segiempat Lengkap (Complete Quadrangle)
Empat garis acak yang berpotongan membentuk empat segitiga.
- **Teorema:** Lingkaran luar dari keempat segitiga tersebut **berpotongan di satu titik tunggal** $M$ (Titik Miquel dari Complete Quadrangle).
- **Pusat-Pusat Lingkaran:** Pusat dari keempat lingkaran tersebut dan titik $M$ terletak pada satu lingkaran baru (Lingkaran Miquel).

### 3. Sifat Keserupaan Spiral
Titik Miquel $M$ adalah pusat keserupaan spiral yang memetakan segmen-segmen terarah antar garis yang membentuk konfigurasi.
`,
    keyTheorems: [
      {
        name: 'Pivot Theorem',
        statement: 'Tiga lingkaran luar dari $AEF, BFD, CDE$ berpotongan di satu titik $M$.',
        proofOutline: 'Pelacak sudut (angle chasing) pada segiempat siklik $AFME$ dan $BDMF$. Tunjukkan $CDME$ otomatis siklik.',
        exampleProblem: 'Buktikan bahwa proyeksi ortogonal dari titik Miquel ke tiga sisi membentuk segitiga pedal.'
      }
    ],
    tips: [
      'Manfaatkan Miquel Point saat menjumpai 4 garis berpotongan sembarang pada gambar.',
      'Titik Miquel sangat sering bertindak sebagai pusat rotasi + dilatasi (spiral similarity).'
    ]
  },
  {
    id: 'th-nt-diophantine-forms',
    topic: 'Teori Bilangan',
    title: 'Persamaan Diophantine & Bentuk Kuadratik',
    subtitle: 'Persamaan Diophantine Non-Linear, Discriminant, Metode Bounding, dan Teorema Chevalley-Warning',
    summary: 'Studi penyelesaian solusi bulat dari persamaan derajat tinggi melalui teknik pemfaktoran, pembatasan interval (bounding), dan analisis bentuk kuadratik $a x^2 + b xy + c y^2$.',
    content: `
### 1. Teknik Pembatasan Interval (Bounding Method)
Banyak persamaan Diophantine $f(x, y) = g(x, y)$ yang dapat diselesaikan dengan menjepit suatu suku di antara dua kuadrat/kubik berurutan:
$$k^2 < (x + c)^2 < (k+1)^2 \\implies \\text{Kontradiksi (Tidak ada solusi bulat)}$$

### 2. Bentuk Kuadratik Biner $a x^2 + b xy + c y^2$
Diskriminan $D = b^2 - 4ac$.
- Jika $D < 0$: Bentuk definit (bernilai selalu positif atau selalu negatif).
- Jika $D > 0$ dan bukan kuadrat: Terkait erat dengan Persamaan Pell dan pecahan berlanjut.

### 3. Teorema Chevalley-Warning
Misalkan $P_1, P_2, \\dots, P_m \\in \\mathbb{F}_p[x_1, \\dots, x_n]$ adalah polinomial-polinomial dengan total derajat $\\sum \\text{deg}(P_i) < n$.
Banyaknya solusi $(x_1, \\dots, x_n) \\in \\mathbb{F}_p^n$ dari sistem persamaan $P_1 = P_2 = \\dots = P_m = 0$ **habis dibagi oleh $p$**.
`,
    keyTheorems: [
      {
        name: 'Teorema Chevalley-Warning',
        statement: 'Jumlah solusi sistem polinomial berderajat total $< n$ modulo $p$ habis dibagi $p$.',
        proofOutline: 'Menggunakan sifat $\\sum_{x \\in \\mathbb{F}_p} x^k \\equiv -1 \\pmod p$ jika $(p-1) \\mid k$, dan $0$ jika lainnya.',
        exampleProblem: 'Buktikan bahwa persamaan $x^2 + y^2 + z^2 \\equiv 0 \\pmod p$ selalu memiliki solusi tak-nol untuk sembarang prima $p$.'
      }
    ],
    tips: [
      'Uji modulo 3, 4, 8, atau $p$ untuk membatasi nilai variabel kuadratik/kubik.',
      'Gunakan pemfaktoran aljabar seperti $x^3 + y^3 = (x+y)(x^2 - xy + y^2)$ untuk memecah persamaan Diophantine.'
    ]
  }
];

