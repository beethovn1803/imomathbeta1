import React, { useState, useMemo } from 'react';
import { Search, Copy, Check, BookMarked, Code, Sparkles, Filter, HelpCircle, Layers, Info } from 'lucide-react';
import { MathRenderer } from './MathRenderer';

export interface MathSymbolItem {
  id: string;
  symbolTeX: string;
  name: string;
  category: 'Logika & Himpunan' | 'Teori Bilangan' | 'Aljabar & Ketaksamaan' | 'Geometri' | 'Kombinatorika & Pembuktian';
  texCode: string;
  description: string;
  exampleUsageTeX: string;
  explanationInIMO: string;
}

export const MATH_SYMBOLS_DICTIONARY: MathSymbolItem[] = [
  // Logika & Himpunan
  {
    id: 'forall',
    symbolTeX: '\\forall x \\in \\mathbb{R}',
    name: 'Kuantifier Universal (Untuk Semua / Setiap)',
    category: 'Logika & Himpunan',
    texCode: '\\forall',
    description: 'Menyatakan bahwa suatu pernyataan berlaku untuk semua elemen dalam semesta pembicaraan.',
    exampleUsageTeX: '\\forall x \\in \\mathbb{R}, x^2 \\ge 0',
    explanationInIMO: 'Sering digunakan dalam pernyataan soal persamaan fungsional atau ketaksamaan untuk menegaskan bahwa formula berlaku bagi seluruh bilangan real.'
  },
  {
    id: 'exists',
    symbolTeX: '\\exists x \\in \\mathbb{Z}',
    name: 'Kuantifier Eksistensial (Terdapat / Ada)',
    category: 'Logika & Himpunan',
    texCode: '\\exists',
    description: 'Menyatakan bahwa setidaknya ada satu elemen yang memenuhi kondisi tertentu.',
    exampleUsageTeX: '\\exists n \\in \\mathbb{N} \\text{ sedemikian hingga } 2^n - 1 \\text{ prima}',
    explanationInIMO: 'Biasa dipakai pada konstruksi contoh (counterexample) atau membuktikan keberadaan setidaknya satu solusi.'
  },
  {
    id: 'implies',
    symbolTeX: 'A \\implies B',
    name: 'Implikasi (Jika ... Maka ...)',
    category: 'Logika & Himpunan',
    texCode: '\\implies',
    description: 'Menyatakan implikasi logis dari kondisi $A$ menuju kesimpulan $B$.',
    exampleUsageTeX: 'a \\mid b \\implies a \\le b \\quad (\\forall a, b \\in \\mathbb{N})',
    explanationInIMO: 'Penyambung langkah deduksi kaku dalam penulisan solusi pembuktian resmi.'
  },
  {
    id: 'iff',
    symbolTeX: 'A \\iff B',
    name: 'Ekuivalensi / Ji-Ka-Ma (Jika dan Hanya Jika)',
    category: 'Logika & Himpunan',
    texCode: '\\iff',
    description: 'Implikasi dua arah: $A$ mengakibatkan $B$ dan $B$ mengakibatkan $A$.',
    exampleUsageTeX: 'a \\equiv b \\pmod{m} \\iff m \\mid (a - b)',
    explanationInIMO: 'Kunci pembuktian klaim ganda (karakterisasi penuh dari suatu kondisi).'
  },
  {
    id: 'element-of',
    symbolTeX: 'x \\in S, y \\notin S',
    name: 'Elemen Dari / Bukan Elemen Dari',
    category: 'Logika & Himpunan',
    texCode: '\\in, \\notin',
    description: 'Menyatakan keanggotaan suatu objek $x$ atau elemen dalam sebuah himpunan $S$.',
    exampleUsageTeX: 'p \\in \\mathbb{P} \\implies p \\ge 2',
    explanationInIMO: 'Dipakai menentukan domain fungsi atau keanggotaan himpunan bilangan.'
  },
  {
    id: 'subset',
    symbolTeX: 'A \\subseteq B',
    name: 'Himpunan Bagian (Subset)',
    category: 'Logika & Himpunan',
    texCode: '\\subseteq',
    description: 'Setiap elemen dalam himpunan $A$ juga merupakan elemen dalam himpunan $B$.',
    exampleUsageTeX: 'A \\cap B \\subseteq A \\subseteq A \\cup B',
    explanationInIMO: 'Biasa digunakan pada kombinatorika ekstremal dan teori himpunan.'
  },
  {
    id: 'sets-number-systems',
    symbolTeX: '\\mathbb{N}, \\mathbb{Z}, \\mathbb{Q}, \\mathbb{R}, \\mathbb{C}, \\mathbb{F}_p',
    name: 'Himpunan Bilangan Standar',
    category: 'Logika & Himpunan',
    texCode: '\\mathbb{N}, \\mathbb{Z}, \\mathbb{Q}, \\mathbb{R}, \\mathbb{C}',
    description: 'Notasi Blackboard Bold untuk himpunan bilangan: $\\mathbb{N}$ (Asli), $\\mathbb{Z}$ (Bulat), $\\mathbb{Q}$ (Rasional), $\\mathbb{R}$ (Real), $\\mathbb{C}$ (Kompleks), $\\mathbb{F}_p$ (Lapangan Modulo $p$).',
    exampleUsageTeX: 'f: \\mathbb{R}^+ \\to \\mathbb{R}^+',
    explanationInIMO: 'Spesifikasi domain dan kodomain wajib ditulis tepat agar pembuktian tidak salah sasaran.'
  },

  // Teori Bilangan
  {
    id: 'divides',
    symbolTeX: 'a \\mid b',
    name: 'Keterbagian (a Membagi b)',
    category: 'Teori Bilangan',
    texCode: 'a \\mid b',
    description: 'Berarti terdapat bilangan bulat $k$ sedemikian hingga $b = a \\cdot k$. Kebalikannya adalah $a \\nmid b$.',
    exampleUsageTeX: 'd \\mid a \\land d \\mid b \\implies d \\mid (xa + yb)',
    explanationInIMO: 'Fondasi utama Teori Bilangan IMO (Lembar Keterbagian, Kombinasi Linear).'
  },
  {
    id: 'mod-congruence',
    symbolTeX: 'a \\equiv b \\pmod{m}',
    name: 'Kongruensi Modulo',
    category: 'Teori Bilangan',
    texCode: 'a \\equiv b \\pmod{m}',
    description: 'Menyatakan bahwa $a$ dan $b$ memberikan sisa pembagian yang sama jika dibagi oleh $m$ (yaitu $m \\mid (a - b)$).',
    exampleUsageTeX: 'a^2 \\equiv 0 \\text{ atau } 1 \\pmod{4} \\quad (\\forall a \\in \\mathbb{Z})',
    explanationInIMO: 'Teknik dasar analisis residu kuadratik dan parity dalam Teori Bilangan.'
  },
  {
    id: 'gcd-lcm',
    symbolTeX: '\\gcd(a, b), \\operatorname{lcm}(a, b)',
    name: 'FPB (PBB) dan KPK',
    category: 'Teori Bilangan',
    texCode: '\\gcd(a, b), \\operatorname{lcm}(a, b)',
    description: 'Faktor Persekutuan Terbesar (Greatest Common Divisor) dan Kelipatan Persekutuan Terkecil (Least Common Multiple).',
    exampleUsageTeX: '\\gcd(a, b) \\cdot \\operatorname{lcm}(a, b) = a \\cdot b',
    explanationInIMO: 'Sering dipakai dengan identitas Bézout: $\\gcd(a,b) = xa + yb$.'
  },
  {
    id: 'p-adic-valuation',
    symbolTeX: 'v_p(n)',
    name: 'Valuasi p-adik',
    category: 'Teori Bilangan',
    texCode: 'v_p(n)',
    description: 'Eksponen pangkat tertinggi dari bilangan prima $p$ yang membagi $n$ (yaitu $p^{v_p(n)} \\mid n$ tetapi $p^{v_p(n)+1} \\nmid n$).',
    exampleUsageTeX: 'v_2(12) = 2, \\quad v_3(12) = 1, \\quad v_2(n!) = \\sum_{k=1}^\\infty \\lfloor \\frac{n}{2^k} \\rfloor',
    explanationInIMO: 'Sangat krusial untuk Teorema LTE (Lifting The Exponent Lemma) dan Rumus Legendre.'
  },
  {
    id: 'euler-phi',
    symbolTeX: '\\phi(n)',
    name: 'Fungsi Totient Euler',
    category: 'Teori Bilangan',
    texCode: '\\phi(n)',
    description: 'Banyaknya bilangan bulat positif $k$ dari $1$ hingga $n$ yang relatif prima terhadap $n$ (yaitu $\\gcd(k, n) = 1$).',
    exampleUsageTeX: '\\gcd(a, n) = 1 \\implies a^{\\phi(n)} \\equiv 1 \\pmod{n}',
    explanationInIMO: 'Digunakan dalam Teorema Euler dan Teorema Kecil Fermat.'
  },
  {
    id: 'floor-ceiling',
    symbolTeX: '\\lfloor x \\rfloor, \\lceil x \\rceil, \\{x\\}',
    name: 'Fungsi Floor (Lantai), Ceiling (Atap), & Fractional Part',
    category: 'Teori Bilangan',
    texCode: '\\lfloor x \\rfloor, \\lceil x \\rceil, \\{x\\}',
    description: '$\\lfloor x \\rfloor$ adalah bilangan bulat terbesar $\\le x$. $\\lceil x \\rceil$ adalah bilangan bulat terkecil $\\ge x$. $\\{x\\} = x - \\lfloor x \\rfloor$ adalah bagian pecahan.',
    exampleUsageTeX: 'x - 1 < \\lfloor x \\rfloor \\le x, \\quad \\{x\\} \\in [0, 1)',
    explanationInIMO: 'Sering muncul di soal persamaan tingkat tinggi dan estimasi analitik.'
  },

  // Aljabar & Ketaksamaan
  {
    id: 'sigma-summation',
    symbolTeX: '\\sum_{i=1}^n a_i',
    name: 'Notasi Sigma (Penjumlahan Deret)',
    category: 'Aljabar & Ketaksamaan',
    texCode: '\\sum_{i=1}^n a_i',
    description: 'Singkatan untuk penjumlahan suku-suku $a_1 + a_2 + \\dots + a_n$.',
    exampleUsageTeX: '\\sum_{i=1}^n i = \\frac{n(n+1)}{2}',
    explanationInIMO: 'Notasi standar ringkas untuk ketaksamaan dan identitas aljabar.'
  },
  {
    id: 'pi-product',
    symbolTeX: '\\prod_{i=1}^n a_i',
    name: 'Notasi Pi (Perkalian Deret)',
    category: 'Aljabar & Ketaksamaan',
    texCode: '\\prod_{i=1}^n a_i',
    description: 'Singkatan untuk perkalian suku-suku $a_1 \\cdot a_2 \\dots a_n$.',
    exampleUsageTeX: '\\prod_{i=1}^n \\left(1 + \\frac{1}{i}\\right) = n + 1',
    explanationInIMO: 'Dipakai pada perkalian teleskopik dan pertidaksamaan AM-GM.'
  },
  {
    id: 'cyclic-sum',
    symbolTeX: '\\sum_{\\text{cyc}} a^2 b',
    name: 'Jumlah Siklik (Cyclic Sum)',
    category: 'Aljabar & Ketaksamaan',
    texCode: '\\sum_{\\text{cyc}} a^2 b',
    description: 'Penjumlahan dengan menggeser variabel secara siklik (misal untuk variabel $a,b,c$: $a^2 b + b^2 c + c^2 a$).',
    exampleUsageTeX: '\\sum_{\\text{cyc}} \\frac{a}{b+c} \\ge \\frac{3}{2} \\quad (\\text{Ketaksamaan Nesbitt})',
    explanationInIMO: 'Menghemat waktu penulisan dalam bukti ketaksamaan simetris/siklik.'
  },
  {
    id: 'symmetric-sum',
    symbolTeX: '\\sum_{\\text{sym}} a^2 b',
    name: 'Jumlah Simetris (Symmetric Sum)',
    category: 'Aljabar & Ketaksamaan',
    texCode: '\\sum_{\\text{sym}} a^2 b',
    description: 'Penjumlahan mencakup seluruh permutasi variabel (6 suku untuk 3 variabel: $a^2 b + a^2 c + b^2 a + b^2 c + c^2 a + c^2 b$).',
    exampleUsageTeX: '\\sum_{\\text{sym}} a^3 \\ge \\sum_{\\text{sym}} a^2 b \\quad (\\text{Teorema Muirhead})',
    explanationInIMO: 'Dipakai pada Teorema Muirhead dan Bundling Ketaksamaan.'
  },
  {
    id: 'function-composition',
    symbolTeX: '(f \\circ g)(x) = f(g(x))',
    name: 'Komposisi Fungsi',
    category: 'Aljabar & Ketaksamaan',
    texCode: 'f \\circ g',
    description: 'Menerapkan fungsi $g$ terlebih dahulu, kemudian hasilnya dimasukkan ke dalam fungsi $f$.',
    exampleUsageTeX: 'f(f(x)) = f^2(x) \\neq (f(x))^2',
    explanationInIMO: 'Sering membingungkan pemula pada soal persamaan fungsional (Functional Equations).'
  },

  // Geometri
  {
    id: 'triangle-circumcircle',
    symbolTeX: '\\triangle ABC, \\odot(ABC)',
    name: 'Segitiga & Lingkaran Luar (Circumcircle)',
    category: 'Geometri',
    texCode: '\\triangle ABC, \\odot(ABC)',
    description: '$\\triangle ABC$ menyatakan segitiga $ABC$. $\\odot(ABC)$ atau $(ABC)$ menyatakan lingkaran luar (circumcircle) yang melalui titik $A, B, C$.',
    exampleUsageTeX: 'R = \\text{jari-jari } \\odot(ABC), \\quad r = \\text{jari-jari incircle}',
    explanationInIMO: 'Notasi standar visualisasi dan konfigurasi geometri sintetis.'
  },
  {
    id: 'perpendicular-parallel',
    symbolTeX: 'L_1 \\perp L_2, \\quad L_1 \\parallel L_2',
    name: 'Tegak Lurus & Sejajar',
    category: 'Geometri',
    texCode: '\\perp, \\parallel',
    description: '$L_1 \\perp L_2$ menyatakan dua garis saling tegak lurus (membentuk sudut $90^\\circ$). $L_1 \\parallel L_2$ menyatakan dua garis sejajar.',
    exampleUsageTeX: 'AH \\perp BC, \\quad OM \\perp BC \\implies AH \\parallel OM',
    explanationInIMO: 'Dasar pembuktian titik ortosentrum dan Garis Euler.'
  },
  {
    id: 'directed-angle',
    symbolTeX: '\\measuredangle(LA, LB)',
    name: 'Sudut Berarah (Directed Angle Modulo 180 deg)',
    category: 'Geometri',
    texCode: '\\measuredangle(LA, LB)',
    description: 'Sudut rotasi dari garis $LA$ ke garis $LB$ diukur berlawanan arah jarum jam modulo $180^\\circ$.',
    exampleUsageTeX: '\\measuredangle(AB, CD) = \\measuredangle(AB, EF) + \\measuredangle(EF, CD)',
    explanationInIMO: 'Menghindari jebakan salah posisi titik (configuration issues / case dependence) pada kaset siklik.'
  },
  {
    id: 'harmonic-ratio',
    symbolTeX: '(A, B; C, D) = -1',
    name: 'Rasio Harmonik (Harmonic Cross-Ratio)',
    category: 'Geometri',
    texCode: '(A, B; C, D) = -1',
    description: 'Perbandingan rasio segmen garis: $(AC / CB) : (AD / DB) = -1$.',
    exampleUsageTeX: '(B, C; D, T) = -1 \\implies \\text{kutub dan garis kutub (polar line)}',
    explanationInIMO: 'Konsep proyektif tingkat lanjut untuk membuktikan kolinearitas dan konkuren.'
  },
  {
    id: 'power-of-point',
    symbolTeX: '\\operatorname{Pow}_{\\omega}(P)',
    name: 'Kuasa Titik (Power of a Point)',
    category: 'Geometri',
    texCode: '\\operatorname{Pow}_{\\omega}(P)',
    description: 'Nilai $d^2 - r^2$ di mana $d$ adalah jarak $P$ ke pusat lingkaran $\\omega$ dan $r$ adalah jari-jarinya.',
    exampleUsageTeX: '\\operatorname{Pow}_{\\odot(ABC)}(P) = PA \\cdot PB = PC \\cdot PD',
    explanationInIMO: 'Landasan pencarian Garis Kuasa (Radical Axis) dua lingkaran.'
  },

  // Kombinatorika & Pembuktian
  {
    id: 'binomial-coeff',
    symbolTeX: '\\binom{n}{k}',
    name: 'Koefisien Binomial ("n pilih k")',
    category: 'Kombinatorika & Pembuktian',
    texCode: '\\binom{n}{k}',
    description: 'Banyaknya cara memilih $k$ objek dari $n$ objek tanpa memperhatikan urutan: $\\frac{n!}{k!(n-k)!}$.',
    exampleUsageTeX: '\\sum_{k=0}^n \\binom{n}{k} = 2^n, \\quad \\binom{n}{k} = \\binom{n-1}{k-1} + \\binom{n-1}{k}',
    explanationInIMO: 'Inti dari Segitiga Pascal, Teorema Binomial, dan Identitas Vandermonde.'
  },
  {
    id: 'factorial',
    symbolTeX: 'n!',
    name: 'Faktorial',
    category: 'Kombinatorika & Pembuktian',
    texCode: 'n!',
    description: 'Hasil kali seluruh bilangan bulat positif dari $1$ hingga $n$. Didefinisikan $0! = 1$.',
    exampleUsageTeX: 'n! = n \\times (n-1)!, \\quad n! \\sim \\sqrt{2\\pi n} \\left(\\frac{n}{e}\\right)^n',
    explanationInIMO: 'Dasar penghitungan permutasi dan analisis keterbagian angka besar.'
  },
  {
    id: 'proof-qed',
    symbolTeX: '\\blacksquare \\quad \\text{atau} \\quad \\text{Q.E.D.}',
    name: 'Simbol Akhir Pembuktian (Q.E.D. / Tombstone)',
    category: 'Kombinatorika & Pembuktian',
    texCode: '\\blacksquare',
    description: 'Quod Erat Demonstrandum (Yang harus dibuktikan). Menandakan bahwa pembuktian telah selesai secara sah.',
    exampleUsageTeX: '\\text{Maka terbukti bahwa } x = y. \\quad \\blacksquare',
    explanationInIMO: 'Standar penutupan lembar jawaban resmi juri IMO.'
  }
];

export const MathDictionary: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = ['Semua', 'Logika & Himpunan', 'Teori Bilangan', 'Aljabar & Ketaksamaan', 'Geometri', 'Kombinatorika & Pembuktian'];

  const filteredSymbols = useMemo(() => {
    return MATH_SYMBOLS_DICTIONARY.filter((item) => {
      const matchesCategory = selectedCategory === 'Semua' || item.category === selectedCategory;
      const query = searchQuery.toLowerCase().trim();
      if (!query) return matchesCategory;

      const matchesQuery =
        item.name.toLowerCase().includes(query) ||
        item.texCode.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.explanationInIMO.toLowerCase().includes(query) ||
        item.category.toLowerCase().includes(query);

      return matchesCategory && matchesQuery;
    });
  }, [searchQuery, selectedCategory]);

  const handleCopyTeX = (texCode: string, id: string) => {
    navigator.clipboard.writeText(texCode);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-4 max-w-3xl">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 text-xs font-bold uppercase tracking-wider">
            <BookMarked className="w-4 h-4 text-indigo-300" />
            <span>Kamus Notasi & Simbol IMO</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            Glosarium & Panduan TeX Matematika Olimpiade
          </h1>

          <p className="text-slate-300 text-xs sm:text-base leading-relaxed font-normal">
            Pahami arti intuitif, definisi formal, serta cara penulisan kode TeX untuk setiap simbol matematika yang biasa ditemui dalam soal & pembuktian IMO.
          </p>
        </div>

        {/* Decorative background TeX watermark */}
        <div className="absolute right-[-2%] bottom-[-10%] opacity-10 text-[120px] sm:text-[220px] font-serif font-black select-none pointer-events-none">
          $\forall \exists \sum$
        </div>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="p-4 sm:p-6 rounded-3xl bg-white border border-slate-200 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama simbol, kode TeX (contoh: \forall, \gcd, \sum), atau kata kunci..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-xs text-slate-400 hover:text-slate-600 font-bold"
              >
                Hapus
              </button>
            )}
          </div>
        </div>

        {/* Category Pills (Horizontal Touch Scroll on Mobile) */}
        <div className="flex overflow-x-auto no-scrollbar touch-pan-x items-center gap-2 pt-2 border-t border-slate-100 py-1">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider mr-1 shrink-0 text-[10px]">
            Kategori:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-xs font-bold'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results Counter */}
      <div className="flex items-center justify-between px-2 text-xs text-slate-500 font-medium">
        <span>Menampilkan <strong>{filteredSymbols.length}</strong> simbol matematika</span>
        <span className="text-[11px] text-indigo-600 font-semibold hidden sm:inline">
          Klik kode TeX untuk menyalinnya ke papan ketik
        </span>
      </div>

      {/* Symbol Cards Grid */}
      {filteredSymbols.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
          <HelpCircle className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">Simbol Tidak Ditemukan</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Tidak ada simbol yang cocok dengan kata kunci "{searchQuery}". Coba gunakan kata kunci lain seperti "mod", "sigma", "forall", atau "FPB".
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredSymbols.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Header Badge & Name */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100/80 inline-block">
                      {item.category}
                    </span>
                    <h3 className="text-base font-extrabold text-slate-900 mt-1.5 tracking-tight">
                      {item.name}
                    </h3>
                  </div>

                  {/* Copy TeX Code Button */}
                  <button
                    onClick={() => handleCopyTeX(item.texCode, item.id)}
                    className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-indigo-700 text-[11px] font-mono font-bold shrink-0 transition-colors"
                    title="Salin Kode TeX"
                  >
                    {copiedId === item.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-600">Tersalin!</span>
                      </>
                    ) : (
                      <>
                        <Code className="w-3.5 h-3.5" />
                        <span>{item.texCode}</span>
                        <Copy className="w-3 h-3 text-slate-400 ml-1" />
                      </>
                    )}
                  </button>
                </div>

                {/* Main Rendered TeX Box */}
                <div className="bg-slate-50/80 border border-slate-200/80 rounded-2xl p-4 flex items-center justify-center text-center overflow-x-auto min-h-[70px]">
                  <MathRenderer content={`$$${item.symbolTeX}$$`} />
                </div>

                {/* Formal Description */}
                <div className="text-xs text-slate-600 leading-relaxed">
                  <MathRenderer content={item.description} inline />
                </div>

                {/* Example Usage TeX */}
                <div className="bg-indigo-50/40 border border-indigo-100 rounded-2xl p-3 text-xs space-y-1">
                  <span className="text-[10px] font-bold text-indigo-900 uppercase tracking-wider block">
                    Contoh Penggunaan:
                  </span>
                  <div className="overflow-x-auto py-1">
                    <MathRenderer content={`$${item.exampleUsageTeX}$`} />
                  </div>
                </div>

                {/* IMO Context Explanation */}
                <div className="flex items-start space-x-2 text-[11px] text-slate-500 pt-1">
                  <Info className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                  <div className="text-slate-600">
                    <strong className="text-slate-700">Dalam Soal IMO: </strong>
                    <MathRenderer content={item.explanationInIMO} inline />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
