import React, { useState, useEffect } from 'react';
import { IMOProblem, ProofEvaluationResult } from '../types';
import { MathRenderer } from './MathRenderer';
import { Award, Clock, Play, Pause, RotateCcw, CheckCircle2, Sparkles, Send, AlertTriangle, ShieldCheck } from 'lucide-react';

interface ExamSimulationProps {
  problems: IMOProblem[];
  onFinishExam: (totalScore: number) => void;
}

export const ExamSimulation: React.FC<ExamSimulationProps> = ({ problems, onFinishExam }) => {
  const [examMode, setExamMode] = useState<'express' | 'full'>('express'); // 'express' = 1 prob 45m, 'full' = 3 prob 4.5h
  const [isExamActive, setIsExamActive] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Time remaining in seconds (45 mins = 2700s)
  const [timeRemaining, setTimeRemaining] = useState<number>(2700);

  // Selected exam problems
  const [examProblems, setExamProblems] = useState<IMOProblem[]>([]);
  const [currentProblemIndex, setCurrentProblemIndex] = useState<number>(0);

  // User answers per problem
  const [answers, setAnswers] = useState<Record<string, string>>({});

  // Final AI Evaluation results
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [examResults, setExamResults] = useState<{
    problemResults: { problemId: string; title: string; score: number; summary: string }[];
    totalScore: number;
    maxPossibleScore: number;
    medalAward: string;
  } | null>(null);

  // Timer effect
  useEffect(() => {
    let timer: any = null;
    if (isExamActive && !isPaused && timeRemaining > 0) {
      timer = setInterval(() => {
        setTimeRemaining((prev) => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isExamActive) {
      handleCompleteExam();
    }
    return () => clearInterval(timer);
  }, [isExamActive, isPaused, timeRemaining]);

  const startExam = (mode: 'express' | 'full') => {
    setExamMode(mode);
    const count = mode === 'express' ? 1 : 3;
    const selected = [...problems].sort(() => 0.5 - Math.random()).slice(0, count);

    setExamProblems(selected);
    setCurrentProblemIndex(0);
    setAnswers({});
    setExamResults(null);
    setTimeRemaining(mode === 'express' ? 45 * 60 : 270 * 60);
    setIsExamActive(true);
    setIsPaused(false);
  };

  const handleAnswerChange = (probId: string, val: string) => {
    setAnswers((prev) => ({ ...prev, [probId]: val }));
  };

  const handleCompleteExam = async () => {
    setIsExamActive(false);
    setIsSubmitting(true);

    const problemResultsList: { problemId: string; title: string; score: number; summary: string }[] = [];
    let accumulatedScore = 0;

    for (const prob of examProblems) {
      const userProof = answers[prob.id] || '';
      if (!userProof.trim()) {
        problemResultsList.push({
          problemId: prob.id,
          title: prob.title,
          score: 0,
          summary: 'Lembar jawaban tidak diisi (0 Poin).',
        });
        continue;
      }

      try {
        const res = await fetch('/api/gemini/evaluate-proof', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            problemTitle: prob.title,
            problemStatement: prob.statement,
            userProof: userProof,
            expectedTopic: prob.topic,
          }),
        });

        if (res.ok) {
          const evalData: ProofEvaluationResult = await res.json();
          const score = evalData.score || 0;
          accumulatedScore += score;
          problemResultsList.push({
            problemId: prob.id,
            title: prob.title,
            score,
            summary: evalData.summary || 'Pembuktian dievaluasi.',
          });
        } else {
          problemResultsList.push({
            problemId: prob.id,
            title: prob.title,
            score: 0,
            summary: 'Gagal mengevaluasi bukti.',
          });
        }
      } catch (e) {
        problemResultsList.push({
          problemId: prob.id,
          title: prob.title,
          score: 0,
          summary: 'Terjadi kendala jaringan saat evaluasi.',
        });
      }
    }

    const maxScore = examProblems.length * 7;
    let medal = 'Peserta Apresiasi IMO';

    if (maxScore === 21) {
      if (accumulatedScore >= 18) medal = '🥇 Medali Emas IMO';
      else if (accumulatedScore >= 14) medal = '🥈 Medali Perak IMO';
      else if (accumulatedScore >= 10) medal = '🥉 Medali Perunggu IMO';
      else if (problemResultsList.some((r) => r.score === 7)) medal = '📜 Honorable Mention (Sebutan Kehormatan)';
    } else {
      if (accumulatedScore === 7) medal = '🥇 Sempurna (7/7 Poin)';
      else if (accumulatedScore >= 5) medal = '🥈 Sangat Baik (5-6 Poin)';
      else if (accumulatedScore >= 3) medal = '🥉 Cukup Baik (3-4 Poin)';
    }

    setExamResults({
      problemResults: problemResultsList,
      totalScore: accumulatedScore,
      maxPossibleScore: maxScore,
      medalAward: medal,
    });

    onFinishExam(accumulatedScore);
    setIsSubmitting(false);
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hrs > 0) {
      return `${hrs}j ${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
    }
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  const currentProb = examProblems[currentProblemIndex];

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold mb-2">
            <Award className="w-3.5 h-3.5" />
            <span>Simulasi Resmi Ujian IMO</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Simulasi Ujian IMO Waktu Nyata</h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Uji ketahanan mental dan kualitas pembuktian Anda di bawah batasan waktu standar Olimpiade Internasional.
          </p>
        </div>
      </div>

      {/* Start Exam Selection Card (If not active & no results) */}
      {!isExamActive && !examResults && !isSubmitting && (
        <div className="p-8 sm:p-10 rounded-3xl bg-white border border-slate-200 space-y-8 shadow-sm">
          <div className="max-w-2xl space-y-2">
            <h2 className="text-2xl font-bold text-slate-900">Pilih Mode Simulasi Ujian</h2>
            <p className="text-slate-500 text-xs sm:text-sm">
              Aturan standar IMO: Setiap soal dinilai 0-7 Poin. Dilarang melihat kunci atau kalkulator saat waktu berjalan.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Express Mode Card */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-indigo-300 space-y-4 transition-all shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                  Mode Ekspres
                </span>
                <span className="text-xs text-slate-500 font-mono flex items-center space-x-1 font-bold">
                  <Clock className="w-3.5 h-3.5 text-indigo-600" />
                  <span>45 Menit</span>
                </span>
              </div>

              <div>
                <h3 className="font-bold text-lg text-slate-900">1 Soal Pembuktian</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Ideal untuk latihan cepat harian dalam mematangkan 1 soal olimpiade penuh.
                </p>
              </div>

              <button
                onClick={() => startExam('express')}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center space-x-2"
              >
                <Play className="w-4 h-4" />
                <span>Mulai Simulasi 45 Mins</span>
              </button>
            </div>

            {/* Full IMO Trial Card */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-purple-300 space-y-4 transition-all shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-100">
                  Mode Penuh IMO
                </span>
                <span className="text-xs text-slate-500 font-mono flex items-center space-x-1 font-bold">
                  <Clock className="w-3.5 h-3.5 text-purple-600" />
                  <span>4.5 Jam (270 Mins)</span>
                </span>
              </div>

              <div>
                <h3 className="font-bold text-lg text-slate-900">3 Soal IMO (Total 21 Poin)</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Simulasi otentik Hari Ujian IMO (Day 1 / Day 2) dengan prediksi raihan Medali.
                </p>
              </div>

              <button
                onClick={() => startExam('full')}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md shadow-purple-600/20 transition-all flex items-center justify-center space-x-2"
              >
                <Award className="w-4 h-4" />
                <span>Mulai Trial Penuh 4.5 Jam</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active Exam Workspace */}
      {isExamActive && currentProb && (
        <div className="space-y-6">
          {/* Exam Status Bar */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center space-x-3">
              <span className="px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 font-mono text-xs font-bold">
                Soal {currentProblemIndex + 1} / {examProblems.length}
              </span>
              <span className="text-xs font-bold text-slate-800 truncate max-w-[180px] sm:max-w-none">
                {currentProb.title}
              </span>
            </div>

            {/* Timer & Controls Display */}
            <div className="flex items-center justify-between sm:justify-end space-x-2 sm:space-x-3">
              <div className="flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-xl bg-slate-50 border border-slate-200">
                <Clock className="w-4 h-4 text-indigo-600 animate-pulse" />
                <span className="font-mono text-sm sm:text-base font-extrabold text-indigo-900">
                  {formatTime(timeRemaining)}
                </span>
              </div>

              <button
                onClick={() => setIsPaused(!isPaused)}
                className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold"
                title={isPaused ? 'Lanjutkan' : 'Jeda Waktu'}
              >
                {isPaused ? <Play className="w-4 h-4 text-emerald-600" /> : <Pause className="w-4 h-4 text-amber-600" />}
              </button>

              <button
                onClick={handleCompleteExam}
                className="px-3.5 sm:px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 flex items-center space-x-1.5 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kumpulkan</span>
              </button>
            </div>
          </div>

          {/* Problem Navigation Tabs (For full mode) */}
          {examProblems.length > 1 && (
            <div className="flex overflow-x-auto no-scrollbar touch-pan-x space-x-2 py-1">
              {examProblems.map((p, idx) => (
                <button
                  key={p.id}
                  onClick={() => setCurrentProblemIndex(idx)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all ${
                    currentProblemIndex === idx
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  Soal {idx + 1}: {p.topic}
                </button>
              ))}
            </div>
          )}

          {/* Problem Statement Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                {currentProb.topic}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {currentProb.source}
              </span>
            </div>

            <h3 className="text-xl font-bold text-slate-900">
              {currentProb.title}
            </h3>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs sm:text-sm text-slate-800 leading-relaxed">
              <MathRenderer content={currentProb.statement} />
            </div>
          </div>

          {/* Answer Editor Area */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 space-y-3 shadow-sm">
            <label className="block text-xs font-bold text-slate-700">
              Lembar Jawaban Pembuktian Siswa (Soal {currentProblemIndex + 1}):
            </label>

            <textarea
              value={answers[currentProb.id] || ''}
              onChange={(e) => handleAnswerChange(currentProb.id, e.target.value)}
              placeholder="Tuliskan bukti lengkap secara kaku di sini. Gunakan notasi LaTeX $...$..."
              className="w-full h-72 p-4 bg-slate-50 border border-slate-200 rounded-2xl font-mono text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-500 leading-relaxed resize-none"
            />
          </div>
        </div>
      )}

      {/* Submitting Loading Overlay */}
      {isSubmitting && (
        <div className="p-12 text-center bg-white border border-slate-200 rounded-3xl space-y-4 shadow-sm">
          <Sparkles className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
          <h3 className="text-xl font-bold text-slate-900">Juri AI Sedang Menilai Pembuktian Ujian Anda...</h3>
          <p className="text-xs text-slate-500">
            Menguji kelengkapan bukti, keabsahan langkah logika, dan mengalkulasi skor IMO (0-7 Poin per soal).
          </p>
        </div>
      )}

      {/* Exam Results Dashboard */}
      {examResults && !isSubmitting && (
        <div className="p-8 sm:p-10 rounded-3xl bg-white border border-indigo-200 space-y-8 shadow-md shadow-indigo-100/50 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 border-b border-slate-100 pb-6">
            <div>
              <span className="px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold">
                Laporan Hasil Ujian IMO
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 mt-2">
                {examResults.medalAward}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Total Perolehan Skor: <strong className="text-indigo-700">{examResults.totalScore} dari {examResults.maxPossibleScore} Poin</strong>
              </p>
            </div>

            <button
              onClick={() => {
                setExamResults(null);
                setIsExamActive(false);
              }}
              className="px-5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition-colors shadow-2xs"
            >
              Uji Kembali
            </button>
          </div>

          {/* Breakdown per problem */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Rincian Nilai per Soal:</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {examResults.problemResults.map((res, idx) => (
                <div key={idx} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-500">Soal {idx + 1}</span>
                    <span className="px-2.5 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 font-mono font-bold text-xs">
                      {res.score} / 7 Poin
                    </span>
                  </div>
                  <p className="text-xs font-bold text-slate-900">{res.title}</p>
                  <p className="text-[11px] text-slate-600 leading-relaxed pt-2 border-t border-slate-200/80">
                    {res.summary}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
