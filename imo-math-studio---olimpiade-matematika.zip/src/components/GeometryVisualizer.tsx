import React, { useState } from 'react';
import { Sparkles, Eye, Info, RotateCcw, Sliders, Layers } from 'lucide-react';

export type GeometryDiagramType = 
  | 'ceva-menelaus' 
  | 'cyclic-quad' 
  | 'miquel-theorem'
  | 'simson-line'
  | 'power-of-point' 
  | 'incircle-excircle' 
  | 'euler-line'
  | 'pascal-theorem';

interface GeometryVisualizerProps {
  type: GeometryDiagramType;
  title?: string;
  caption?: string;
}

export const GeometryVisualizer: React.FC<GeometryVisualizerProps> = ({
  type,
  title,
  caption,
}) => {
  // Mode toggle for Ceva vs Menelaus
  const [cevaMode, setCevaMode] = useState<'ceva' | 'menelaus'>('ceva');
  
  // Barycentric weights for Ceva Point P inside ABC
  const [wA, setWA] = useState<number>(2.0);
  const [wB, setWB] = useState<number>(3.0);
  const [wC, setWC] = useState<number>(3.0);

  // Menelaus parameters: position of F on AB (lambda) and D on BC (mu)
  const [lambdaF, setLambdaF] = useState<number>(0.333); // AF/AB = 0.333 -> AF/FB = 0.5
  const [muD, setMuD] = useState<number>(0.600);     // BD/BC = 0.600 -> BD/DC = 1.5

  // Angle chasing interactive vertex position (angle in degrees)
  const [quadAngle, setQuadAngle] = useState<number>(315);
  const [showAngleColors, setShowAngleColors] = useState<boolean>(true);

  // Miquel's Theorem interactive parameter (position of D on BC, E on CA, F on AB)
  const [miquelParam, setMiquelParam] = useState<number>(0.5);

  // Simson Line interactive position of point P on circumcircle (angle in degrees)
  const [simsonAngle, setSimsonAngle] = useState<number>(45);

  // Pascal's Hexagram interactive vertex shift
  const [pascalShift, setPascalShift] = useState<number>(0);

  // Power of point P distance factor
  const [pointPDist, setPointPDist] = useState<number>(180);
  const [powerSubMode, setPowerSubMode] = useState<'power' | 'radical'>('power');

  // Incircle / Excircle view mode
  const [incircleMode, setIncircleMode] = useState<'incircle' | 'excircle'>('incircle');

  // Euler line view detail mode
  const [showNinePoints, setShowNinePoints] = useState<boolean>(true);

  // ==========================================
  // 1. RENDER CEVA & MENELAUS DIAGRAMS
  // ==========================================
  const renderCevaMenelaus = () => {
    if (cevaMode === 'ceva') {
      // Triangle ABC
      const A = { x: 200, y: 30 };
      const B = { x: 50, y: 250 };
      const C = { x: 350, y: 250 };

      // Compute exact P and ceviana endpoints using barycentric coordinates
      const wSum = wA + wB + wC;
      const P = {
        x: (wA * A.x + wB * B.x + wC * C.x) / wSum,
        y: (wA * A.y + wB * B.y + wC * C.y) / wSum,
      };

      // D on BC
      const D = {
        x: (wB * B.x + wC * C.x) / (wB + wC),
        y: (wB * B.y + wC * C.y) / (wB + wC),
      };

      // E on AC
      const E = {
        x: (wA * A.x + wC * C.x) / (wA + wC),
        y: (wA * A.y + wC * C.y) / (wA + wC),
      };

      // F on AB
      const F = {
        x: (wA * A.x + wB * B.x) / (wA + wB),
        y: (wA * A.y + wB * B.y) / (wA + wB),
      };

      // Exact Ratios
      const ratioAF_FB = wB / wA;
      const ratioBD_DC = wC / wB;
      const ratioCE_EA = wA / wC;
      const product = ratioAF_FB * ratioBD_DC * ratioCE_EA;

      return (
        <svg viewBox="0 0 400 320" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
          <defs>
            <linearGradient id="triGradCeva" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6366f1" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.05" />
            </linearGradient>
          </defs>

          {/* Triangle Fill */}
          <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="url(#triGradCeva)" stroke="#818cf8" strokeWidth="2.5" />

          {/* Cevians: AD, BE, CF - ALL EXACTLY INTERSECT AT P */}
          <line x1={A.x} y1={A.y} x2={D.x} y2={D.y} stroke="#f43f5e" strokeWidth="2" strokeDasharray="5 3" />
          <line x1={B.x} y1={B.y} x2={E.x} y2={E.y} stroke="#10b981" strokeWidth="2" strokeDasharray="5 3" />
          <line x1={C.x} y1={C.y} x2={F.x} y2={F.y} stroke="#3b82f6" strokeWidth="2" strokeDasharray="5 3" />

          {/* Ceva Point P */}
          <circle cx={P.x} cy={P.y} r="6" fill="#f59e0b" className="animate-pulse" />
          <text x={P.x + 8} y={P.y - 8} fill="#fbbf24" className="text-xs font-bold font-mono">P (Titik Ceva)</text>

          {/* Vertices A, B, C */}
          <circle cx={A.x} cy={A.y} r="5" fill="#818cf8" />
          <text x={A.x - 6} y={A.y - 10} fill="#ffffff" className="text-sm font-extrabold">A</text>

          <circle cx={B.x} cy={B.y} r="5" fill="#818cf8" />
          <text x={B.x - 18} y={B.y + 16} fill="#ffffff" className="text-sm font-extrabold">B</text>

          <circle cx={C.x} cy={C.y} r="5" fill="#818cf8" />
          <text x={C.x + 8} y={C.y + 16} fill="#ffffff" className="text-sm font-extrabold">C</text>

          {/* Points D, E, F */}
          <circle cx={D.x} cy={D.y} r="4" fill="#f43f5e" />
          <text x={D.x - 4} y={D.y + 16} fill="#f43f5e" className="text-xs font-bold">D</text>

          <circle cx={E.x} cy={E.y} r="4" fill="#10b981" />
          <text x={E.x + 8} y={E.y - 2} fill="#10b981" className="text-xs font-bold">E</text>

          <circle cx={F.x} cy={F.y} r="4" fill="#3b82f6" />
          <text x={F.x - 18} y={F.y - 2} fill="#3b82f6" className="text-xs font-bold">F</text>

          {/* Equation Box Overlay */}
          <rect x="15" y="260" width="370" height="50" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x="200" y="280" textAnchor="middle" fill="#38bdf8" className="text-xs font-mono font-bold">
            ({ratioAF_FB.toFixed(2)}) × ({ratioBD_DC.toFixed(2)}) × ({ratioCE_EA.toFixed(2)}) = {product.toFixed(2)}
          </text>
          <text x="200" y="298" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
            Garis AD, BE, CF selalu konkuren di titik P untuk semua bobot (wA={wA}, wB={wB}, wC={wC}).
          </text>
        </svg>
      );
    } else {
      // Menelaus Transversal
      // Triangle ABC
      const A = { x: 180, y: 40 };
      const B = { x: 60, y: 220 };
      const C = { x: 300, y: 220 };

      // Point F on AB using lambdaF parameter: F = (1-lambda)*A + lambda*B
      const F = {
        x: (1 - lambdaF) * A.x + lambdaF * B.x,
        y: (1 - lambdaF) * A.y + lambdaF * B.y,
      };

      // Point D on BC using muD parameter: D = (1-mu)*B + mu*C
      const D = {
        x: (1 - muD) * B.x + muD * C.x,
        y: (1 - muD) * B.y + muD * C.y,
      };

      // Line FD slope m_FD
      const mFD = (D.y - F.y) / (D.x - F.x);

      // Line AC slope m_AC
      const mAC = (C.y - A.y) / (C.x - A.x); // (220-40)/(300-180) = 1.5

      // Point E is the intersection of line FD and line AC
      // y - A.y = mAC*(x - A.x)  and  y - F.y = mFD*(x - F.x)
      // mAC*x - mAC*A.x + A.y = mFD*x - mFD*F.x + F.y
      const xE = (A.y - F.y + mFD * F.x - mAC * A.x) / (mFD - mAC);
      const yE = A.y + mAC * (xE - A.x);
      const E = { x: xE, y: yE };

      // Transversal extended line bounds for smooth SVG rendering
      const xStart = 20;
      const yStart = F.y + mFD * (xStart - F.x);
      const xEnd = Math.min(390, Math.max(xE + 20, 370));
      const yEnd = F.y + mFD * (xEnd - F.x);

      // Exact Ratios
      const rAF_FB = lambdaF / (1 - lambdaF);
      const rBD_DC = muD / (1 - muD);
      const distCE = Math.hypot(E.x - C.x, E.y - C.y);
      const distEA = Math.hypot(E.x - A.x, E.y - A.y);
      const rCE_EA = distCE / distEA;
      const product = rAF_FB * rBD_DC * rCE_EA;

      return (
        <svg viewBox="0 0 420 330" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
          <defs>
            <linearGradient id="triGradMenelaus" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0.05" />
            </linearGradient>
          </defs>

          {/* Triangle Fill */}
          <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="url(#triGradMenelaus)" stroke="#818cf8" strokeWidth="2.5" />

          {/* Extended Side AC through C to E */}
          <line x1={A.x} y1={A.y} x2={E.x} y2={E.y} stroke="#64748b" strokeWidth="1.5" strokeDasharray="4 3" />

          {/* Transversal Line F-D-E (drawn as a single continuous straight line) */}
          <line x1={xStart} y1={yStart} x2={xEnd} y2={yEnd} stroke="#f43f5e" strokeWidth="2.5" />

          {/* Vertices A, B, C */}
          <circle cx={A.x} cy={A.y} r="5" fill="#818cf8" />
          <text x={A.x - 6} y={A.y - 10} fill="#ffffff" className="text-sm font-extrabold">A</text>

          <circle cx={B.x} cy={B.y} r="5" fill="#818cf8" />
          <text x={B.x - 18} y={B.y + 16} fill="#ffffff" className="text-sm font-extrabold">B</text>

          <circle cx={C.x} cy={C.y} r="5" fill="#818cf8" />
          <text x={C.x - 15} y={C.y - 8} fill="#ffffff" className="text-sm font-extrabold">C</text>

          {/* Transversal Points F, D, E */}
          <circle cx={F.x} cy={F.y} r="5" fill="#f43f5e" />
          <text x={F.x - 22} y={F.y - 8} fill="#f43f5e" className="text-xs font-bold">F (AB)</text>

          <circle cx={D.x} cy={D.y} r="5" fill="#f43f5e" />
          <text x={D.x - 4} y={D.y + 18} fill="#f43f5e" className="text-xs font-bold">D (BC)</text>

          <circle cx={E.x} cy={E.y} r="5" fill="#f59e0b" className="animate-pulse" />
          <text x={E.x - 25} y={E.y + 18} fill="#fbbf24" className="text-xs font-bold">E (sisi AC diperpanjang)</text>

          {/* Equation Box Overlay */}
          <rect x="25" y="270" width="370" height="48" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x="210" y="290" textAnchor="middle" fill="#f43f5e" className="text-xs font-mono font-bold">
            ({rAF_FB.toFixed(2)}) × ({rBD_DC.toFixed(2)}) × ({rCE_EA.toFixed(2)}) = {product.toFixed(2)}
          </text>
          <text x="210" y="308" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
            Titik F, D, dan E selalu segaris (kolinear) memotong perpanjangan AC.
          </text>
        </svg>
      );
    }
  };

  // ==========================================
  // 2. RENDER CYCLIC QUADRILATERAL & ANGLE CHASING
  // ==========================================
  const renderCyclicQuad = () => {
    const cx = 200;
    const cy = 135;
    const R = 95;

    const aA = (210 * Math.PI) / 180;
    const aB = (130 * Math.PI) / 180;
    const aC = (30 * Math.PI) / 180;
    const aD = (quadAngle * Math.PI) / 180;

    const A = { x: cx + R * Math.cos(aA), y: cy + R * Math.sin(aA) };
    const B = { x: cx + R * Math.cos(aB), y: cy + R * Math.sin(aB) };
    const C = { x: cx + R * Math.cos(aC), y: cy + R * Math.sin(aC) };
    const D = { x: cx + R * Math.cos(aD), y: cy + R * Math.sin(aD) };

    // Subtended angle for arc AD = (210° - quadAngle) / 2
    const arcDegree = (360 + quadAngle - 210) % 360;
    const inscribedAngle = (arcDegree / 2).toFixed(1);

    // Opposite angles sum
    const angleA_approx = (180 - (quadAngle - 130) / 2).toFixed(0);
    const angleC_approx = ((quadAngle - 130) / 2).toFixed(0);

    return (
      <svg viewBox="0 0 400 310" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
        {/* Circumcircle */}
        <circle cx={cx} cy={cy} r={R} fill="rgba(56, 189, 248, 0.04)" stroke="#38bdf8" strokeWidth="2" strokeDasharray="6 3" />
        <circle cx={cx} cy={cy} r="3" fill="#38bdf8" />
        <text x={cx + 8} y={cy + 4} fill="#38bdf8" className="text-[10px] font-mono">Pusat O</text>

        {/* Subtended Arc AD Highlight */}
        {showAngleColors && (
          <path
            d={`M ${A.x} ${A.y} A ${R} ${R} 0 0 1 ${D.x} ${D.y}`}
            fill="none"
            stroke="#c084fc"
            strokeWidth="4"
          />
        )}

        {/* Quadrilateral Sides */}
        <polygon
          points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y} ${D.x},${D.y}`}
          fill="rgba(99, 102, 241, 0.08)"
          stroke="#f87171"
          strokeWidth="2.5"
        />

        {/* Diagonals AC and BD */}
        <line x1={A.x} y1={A.y} x2={C.x} y2={C.y} stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="3 3" />
        <line x1={B.x} y1={B.y} x2={D.x} y2={D.y} stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="3 3" />

        {/* Angle ABD and Angle ACD Markers */}
        {showAngleColors && (
          <>
            <circle cx={B.x} cy={B.y} r="14" fill="none" stroke="#c084fc" strokeWidth="2" strokeDasharray="10 5" />
            <circle cx={C.x} cy={C.y} r="14" fill="none" stroke="#c084fc" strokeWidth="2" strokeDasharray="10 5" />
          </>
        )}

        {/* Vertices */}
        <circle cx={A.x} cy={A.y} r="5" fill="#ffffff" />
        <text x={A.x - 16} y={A.y - 8} fill="#ffffff" className="text-xs font-bold">A</text>

        <circle cx={B.x} cy={B.y} r="5" fill="#ffffff" />
        <text x={B.x - 16} y={B.y + 16} fill="#ffffff" className="text-xs font-bold">B</text>

        <circle cx={C.x} cy={C.y} r="5" fill="#ffffff" />
        <text x={C.x + 10} y={C.y + 10} fill="#ffffff" className="text-xs font-bold">C</text>

        <circle cx={D.x} cy={D.y} r="6" fill="#f43f5e" className="animate-pulse" />
        <text x={D.x + 10} y={D.y - 8} fill="#f43f5e" className="text-xs font-bold">D ({quadAngle}°)</text>

        {/* Info Box */}
        <rect x="20" y="250" width="360" height="48" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
        <text x="200" y="268" textAnchor="middle" fill="#c084fc" className="text-xs font-mono font-bold">
          ∠ABD = ∠ACD = {inscribedAngle}° (Menghadap Busur Merah AD)
        </text>
        <text x="200" y="286" textAnchor="middle" fill="#38bdf8" className="text-[10px]">
          Sifat Segiempat Siklik: ∠A + ∠C = 180° ({angleA_approx}° + {angleC_approx}°) & Teorema Ptolemy AC·BD = AB·CD + AD·BC
        </text>
      </svg>
    );
  };

  // ==========================================
  // 3. RENDER POWER OF A POINT & RADICAL AXIS
  // ==========================================
  const renderPowerOfPoint = () => {
    if (powerSubMode === 'power') {
      const cx = 150;
      const cy = 130;
      const R = 60;

      // External point P
      const P = { x: cx + pointPDist, y: cy };

      // Tangent point T
      const angleT = Math.acos(R / pointPDist);
      const T = {
        x: cx + R * Math.cos(angleT),
        y: cy - R * Math.sin(angleT),
      };

      // Secants
      const A = { x: cx - R * 0.8, y: cy - R * 0.6 };
      const B = { x: cx + R * 0.9, y: cy - R * 0.43 };

      const C = { x: cx - R * 0.7, y: cy + R * 0.71 };
      const D = { x: cx + R * 0.85, y: cy + R * 0.52 };

      const powVal = Math.round(pointPDist * pointPDist - R * R);
      const tangentLen = Math.round(Math.sqrt(powVal));

      return (
        <svg viewBox="0 0 420 280" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
          {/* Circle */}
          <circle cx={cx} cy={cy} r={R} fill="rgba(16, 185, 129, 0.08)" stroke="#10b981" strokeWidth="2" />
          <circle cx={cx} cy={cy} r="3" fill="#10b981" />
          <text x={cx - 10} y={cy + 15} fill="#10b981" className="text-[10px] font-mono">Pusat O</text>

          {/* Line OP */}
          <line x1={cx} y1={cy} x2={P.x} y2={P.y} stroke="#64748b" strokeWidth="1" strokeDasharray="3 3" />

          {/* Radius OT */}
          <line x1={cx} y1={cy} x2={T.x} y2={T.y} stroke="#10b981" strokeWidth="1.5" strokeDasharray="2 2" />

          {/* Tangent line PT */}
          <line x1={P.x} y1={P.y} x2={T.x} y2={T.y} stroke="#f59e0b" strokeWidth="2.5" />
          <circle cx={T.x} cy={T.y} r="4" fill="#f59e0b" />
          <text x={T.x - 6} y={T.y - 10} fill="#f59e0b" className="text-xs font-bold">T (Titik Singgung)</text>

          {/* Secants PAB and PCD */}
          <line x1={P.x} y1={P.y} x2={A.x - 20} y2={cy - R * 0.7} stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="4 2" />
          <line x1={P.x} y1={P.y} x2={C.x - 20} y2={cy + R * 0.8} stroke="#a855f7" strokeWidth="1.5" strokeDasharray="4 2" />

          {/* Points A, B, C, D */}
          <circle cx={A.x} cy={A.y} r="4" fill="#38bdf8" />
          <text x={A.x - 14} y={A.y - 6} fill="#38bdf8" className="text-xs font-bold">A</text>

          <circle cx={B.x} cy={B.y} r="4" fill="#38bdf8" />
          <text x={B.x + 6} y={B.y - 6} fill="#38bdf8" className="text-xs font-bold">B</text>

          <circle cx={C.x} cy={C.y} r="4" fill="#a855f7" />
          <text x={C.x - 14} y={C.y + 14} fill="#a855f7" className="text-xs font-bold">C</text>

          <circle cx={D.x} cy={D.y} r="4" fill="#a855f7" />
          <text x={D.x + 6} y={D.y + 14} fill="#a855f7" className="text-xs font-bold">D</text>

          {/* Point P */}
          <circle cx={P.x} cy={P.y} r="6" fill="#f43f5e" className="animate-pulse" />
          <text x={P.x + 8} y={P.y + 4} fill="#f43f5e" className="text-xs font-extrabold">P (Jarak OP={pointPDist})</text>

          {/* Formula Box */}
          <rect x="20" y="220" width="380" height="48" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x="210" y="240" textAnchor="middle" fill="#34d399" className="text-xs font-mono font-bold">
            PA × PB = PC × PD = PT² = OP² - R² = {powVal} (PT = {tangentLen}px)
          </text>
          <text x="210" y="258" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
            Kuasa Titik (Power of a Point) selalu konstan untuk semua garis secant yang ditarik dari P.
          </text>
        </svg>
      );
    } else {
      // Radical Axis Diagram
      const O1 = { x: 130, y: 130 };
      const R1 = 65;
      const O2 = { x: 250, y: 130 };
      const R2 = 55;

      // Common points of intersection A and B
      // O1=(130,130), O2=(250,130), distance=120
      // Intersection chord x = 180
      const chordX = 180;
      const dy = Math.sqrt(R1 * R1 - (chordX - O1.x) * (chordX - O1.x)); // sqrt(65^2 - 50^2) = sqrt(4225-2500) = sqrt(1725) ≈ 41.5
      const A = { x: chordX, y: O1.y - dy };
      const B = { x: chordX, y: O1.y + dy };

      return (
        <svg viewBox="0 0 420 280" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
          {/* Circle 1 */}
          <circle cx={O1.x} cy={O1.y} r={R1} fill="rgba(56, 189, 248, 0.08)" stroke="#38bdf8" strokeWidth="2" />
          <circle cx={O1.x} cy={O1.y} r="3" fill="#38bdf8" />
          <text x={O1.x - 20} y={O1.y + 16} fill="#38bdf8" className="text-[10px] font-mono">Pusat O1</text>

          {/* Circle 2 */}
          <circle cx={O2.x} cy={O2.y} r={R2} fill="rgba(168, 85, 247, 0.08)" stroke="#a855f7" strokeWidth="2" />
          <circle cx={O2.x} cy={O2.y} r="3" fill="#a855f7" />
          <text x={O2.x + 8} y={O2.y + 16} fill="#a855f7" className="text-[10px] font-mono">Pusat O2</text>

          {/* Line of centers O1O2 */}
          <line x1={O1.x} y1={O1.y} x2={O2.x} y2={O2.y} stroke="#64748b" strokeWidth="1.5" strokeDasharray="3 3" />

          {/* Radical Axis (Line AB extended vertically) */}
          <line x1={chordX} y1="30" x2={chordX} y2="220" stroke="#f43f5e" strokeWidth="3" />

          {/* Common chord points A and B */}
          <circle cx={A.x} cy={A.y} r="4" fill="#f43f5e" />
          <text x={A.x + 8} y={A.y - 4} fill="#f43f5e" className="text-xs font-bold">A</text>

          <circle cx={B.x} cy={B.y} r="4" fill="#f43f5e" />
          <text x={B.x + 8} y={B.y + 12} fill="#f43f5e" className="text-xs font-bold">B</text>

          {/* Point P on Radical Axis */}
          <circle cx={chordX} cy="50" r="5" fill="#f59e0b" className="animate-pulse" />
          <text x={chordX + 10} y="54" fill="#fbbf24" className="text-xs font-bold font-mono">P (Sumbu Radikal)</text>

          {/* Info Box */}
          <rect x="20" y="230" width="380" height="40" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x="210" y="248" textAnchor="middle" fill="#f43f5e" className="text-xs font-mono font-bold">
            Sumbu Radikal: Pow_ω1(P) = Pow_ω2(P) (Selalu Tegak Lurus Garis O1O2)
          </text>
          <text x="210" y="262" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
            Setiap titik P pada garis merah memiliki panjang garis singgung yang sama ke kedua lingkaran.
          </text>
        </svg>
      );
    }
  };

  // ==========================================
  // 4. RENDER INCIRCLE & EXCIRCLE DIAGRAM
  // ==========================================
  const renderIncircleExcircle = () => {
    if (incircleMode === 'incircle') {
      // Triangle ABC
      const A = { x: 200, y: 30 };
      const B = { x: 60, y: 240 };
      const C = { x: 340, y: 240 };

      // Incenter I(200, 165.1), radius r = 74.9
      const I = { x: 200, y: 165.1 };
      const r = 74.9;

      // Contact points D, E, F
      const D = { x: 200, y: 240 };
      const E = { x: 262.3, y: 123.5 };
      const F = { x: 137.7, y: 123.5 };

      return (
        <svg viewBox="0 0 400 310" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
          <defs>
            <linearGradient id="incircleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.05" />
            </linearGradient>
          </defs>

          {/* Triangle ABC */}
          <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="url(#incircleGrad)" stroke="#818cf8" strokeWidth="2.5" />

          {/* Incircle */}
          <circle cx={I.x} cy={I.y} r={r} fill="rgba(16, 185, 129, 0.12)" stroke="#10b981" strokeWidth="2.5" />
          <circle cx={I.x} cy={I.y} r="4" fill="#10b981" />
          <text x={I.x + 8} y={I.y + 4} fill="#10b981" className="text-xs font-bold">I (Incenter)</text>

          {/* Radii ID, IE, IF */}
          <line x1={I.x} y1={I.y} x2={D.x} y2={D.y} stroke="#10b981" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1={I.x} y1={I.y} x2={E.x} y2={E.y} stroke="#10b981" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1={I.x} y1={I.y} x2={F.x} y2={F.y} stroke="#10b981" strokeWidth="1.5" strokeDasharray="3 3" />

          {/* Contact Points D, E, F */}
          <circle cx={D.x} cy={D.y} r="4" fill="#f43f5e" />
          <text x={D.x - 4} y={D.y + 18} fill="#f43f5e" className="text-xs font-bold">D</text>

          <circle cx={E.x} cy={E.y} r="4" fill="#f43f5e" />
          <text x={E.x + 8} y={E.y - 2} fill="#f43f5e" className="text-xs font-bold">E</text>

          <circle cx={F.x} cy={F.y} r="4" fill="#f43f5e" />
          <text x={F.x - 18} y={F.y - 2} fill="#f43f5e" className="text-xs font-bold">F</text>

          {/* Vertices */}
          <text x={A.x - 6} y={A.y - 8} fill="#ffffff" className="text-sm font-extrabold">A</text>
          <text x={B.x - 18} y={B.y + 16} fill="#ffffff" className="text-sm font-extrabold">B</text>
          <text x={C.x + 8} y={C.y + 16} fill="#ffffff" className="text-sm font-extrabold">C</text>

          {/* Tangency length labels */}
          <text x="160" y="70" fill="#facc15" className="text-[10px] font-mono font-bold">AF = s - a</text>
          <text x="210" y="70" fill="#facc15" className="text-[10px] font-mono font-bold">AE = s - a</text>

          <text x="85" y="190" fill="#38bdf8" className="text-[10px] font-mono font-bold">BF = s - b</text>
          <text x="120" y="235" fill="#38bdf8" className="text-[10px] font-mono font-bold">BD = s - b</text>

          <text x="285" y="190" fill="#c084fc" className="text-[10px] font-mono font-bold">CE = s - c</text>
          <text x="250" y="235" fill="#c084fc" className="text-[10px] font-mono font-bold">CD = s - c</text>

          {/* Formula Box */}
          <rect x="20" y="262" width="360" height="40" rx="8" fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x="200" y="280" textAnchor="middle" fill="#34d399" className="text-xs font-mono font-bold">
            AF = AE = s - a, BD = BF = s - b, CD = CE = s - c
          </text>
          <text x="200" y="294" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
            Inradius r = Luas / s, Jarak Euler: OI² = R² - 2Rr (R ≥ 2r)
          </text>
        </svg>
      );
    } else {
      // Excircle Diagram (A-Excircle)
      const A = { x: 200, y: 40 };
      const B = { x: 120, y: 160 };
      const C = { x: 280, y: 160 };

      // Incircle contact point D on BC
      const D = { x: 180, y: 160 }; // BD = s-b = 60, CD = s-c = 100

      // Excircle contact point D' on BC (symmetric to D wrt midpoint of BC)
      // Midpoint of BC is 200
      const Dprime = { x: 220, y: 160 }; // BD' = s-c = 100, CD' = s-b = 60

      // A-Excircle center Ia
      const Ia = { x: 200, y: 250 };
      const ra = 90;

      return (
        <svg viewBox="0 0 400 320" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
          {/* Triangle ABC */}
          <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="rgba(99, 102, 241, 0.1)" stroke="#818cf8" strokeWidth="2" />

          {/* Extended Sides AB and AC */}
          <line x1={B.x} y1={B.y} x2="70" y2="235" stroke="#64748b" strokeWidth="1.5" strokeDasharray="4 3" />
          <line x1={C.x} y1={C.y} x2="330" y2="235" stroke="#64748b" strokeWidth="1.5" strokeDasharray="4 3" />

          {/* Extended BC line */}
          <line x1="40" y1="160" x2="360" y2="160" stroke="#818cf8" strokeWidth="1.5" />

          {/* A-Excircle */}
          <circle cx={Ia.x} cy={Ia.y} r={ra} fill="rgba(244, 63, 94, 0.1)" stroke="#f43f5e" strokeWidth="2.5" />
          <circle cx={Ia.x} cy={Ia.y} r="4" fill="#f43f5e" />
          <text x={Ia.x + 8} y={Ia.y + 4} fill="#f43f5e" className="text-xs font-bold">Ia (Pusat A-Excircle)</text>

          {/* Points D (Incircle) and D' (Excircle) */}
          <circle cx={D.x} cy={D.y} r="4" fill="#10b981" />
          <text x={D.x - 8} y={D.y - 8} fill="#10b981" className="text-xs font-bold">D</text>

          <circle cx={Dprime.x} cy={Dprime.y} r="4" fill="#f43f5e" />
          <text x={Dprime.x + 4} y={Dprime.y - 8} fill="#f43f5e" className="text-xs font-bold">D'</text>

          {/* Midpoint M of BC */}
          <circle cx="200" cy="160" r="3" fill="#fbbf24" />
          <text x="195" y="150" fill="#fbbf24" className="text-[10px] font-bold">M (Tengah BC)</text>

          {/* Vertices */}
          <text x={A.x - 6} y={A.y - 6} fill="#ffffff" className="text-sm font-extrabold">A</text>
          <text x={B.x - 16} y={B.y - 6} fill="#ffffff" className="text-sm font-extrabold">B</text>
          <text x={C.x + 8} y={C.y - 6} fill="#ffffff" className="text-sm font-extrabold">C</text>

          {/* Formula Box */}
          <rect x="20" y="270" width="360" height="42" rx="8" fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x="200" y="288" textAnchor="middle" fill="#f43f5e" className="text-xs font-mono font-bold">
            Simetri Tangen: BD = CD' = s - b dan CD = BD' = s - c
          </text>
          <text x="200" y="304" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
            Titik D (Incircle) & D' (Excircle) simetris terhadap titik tengah M dari BC.
          </text>
        </svg>
      );
    }
  };

  // ==========================================
  // 5. RENDER EULER LINE & NINE-POINT CIRCLE
  // ==========================================
  const renderEulerLine = () => {
    // Triangle ABC
    const A = { x: 180, y: 40 };
    const B = { x: 60, y: 220 };
    const C = { x: 320, y: 220 };

    // Exact Euler Points
    const O = { x: 190, y: 176.7 }; // Circumcenter
    const G = { x: 186.7, y: 160.0 }; // Centroid
    const N = { x: 185.0, y: 151.7 }; // Nine-point center (midpoint of OH)
    const H = { x: 180.0, y: 126.7 }; // Orthocenter

    // Circumradius R = 137.0
    const R_circum = 137.0;
    // Nine point radius R_nine = R / 2 = 68.5
    const R_nine = 68.5;

    // 9 Special Points on Nine-Point Circle
    // 1. Midpoints of sides:
    const Ma = { x: 190, y: 220 };
    const Mb = { x: 250, y: 130 };
    const Mc = { x: 120, y: 130 };

    // 2. Altitude feet:
    const Ha = { x: 180, y: 220 };

    // 3. Euler points (midpoints of AH, BH, CH):
    const Pa = { x: 180, y: 83.3 };
    const Pb = { x: 120, y: 173.3 };
    const Pc = { x: 250, y: 173.3 };

    return (
      <svg viewBox="0 0 400 310" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
        {/* Circumcircle */}
        <circle cx={O.x} cy={O.y} r={R_circum} fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="5 4" opacity="0.6" />

        {/* Nine-point circle */}
        <circle cx={N.x} cy={N.y} r={R_nine} fill="rgba(168, 85, 247, 0.12)" stroke="#a855f7" strokeWidth="2.5" />

        {/* Triangle ABC */}
        <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="none" stroke="#818cf8" strokeWidth="2" />

        {/* Altitudes AH, BH */}
        <line x1={A.x} y1={A.y} x2={Ha.x} y2={Ha.y} stroke="#64748b" strokeWidth="1" strokeDasharray="3 3" />

        {/* Euler Line (through O, G, N, H) extended */}
        <line x1="205" y1="250" x2="175" y2="100" stroke="#f43f5e" strokeWidth="3" />

        {/* Nine Points Highlights */}
        {showNinePoints && (
          <>
            {/* Midpoints */}
            <circle cx={Ma.x} cy={Ma.y} r="3.5" fill="#a855f7" />
            <circle cx={Mb.x} cy={Mb.y} r="3.5" fill="#a855f7" />
            <circle cx={Mc.x} cy={Mc.y} r="3.5" fill="#a855f7" />

            {/* Altitude feet */}
            <circle cx={Ha.x} cy={Ha.y} r="3.5" fill="#f43f5e" />

            {/* Euler Points */}
            <circle cx={Pa.x} cy={Pa.y} r="3.5" fill="#38bdf8" />
            <circle cx={Pb.x} cy={Pb.y} r="3.5" fill="#38bdf8" />
            <circle cx={Pc.x} cy={Pc.y} r="3.5" fill="#38bdf8" />
          </>
        )}

        {/* Points O, G, N, H */}
        <circle cx={O.x} cy={O.y} r="5" fill="#38bdf8" />
        <text x={O.x + 8} y={O.y - 2} fill="#38bdf8" className="text-xs font-bold">O (Sirkumsenter)</text>

        <circle cx={G.x} cy={G.y} r="5" fill="#10b981" />
        <text x={G.x - 85} y={G.y - 2} fill="#10b981" className="text-xs font-bold">G (Centroid)</text>

        <circle cx={N.x} cy={N.y} r="5" fill="#a855f7" />
        <text x={N.x + 8} y={N.y + 4} fill="#a855f7" className="text-xs font-bold">N (Pusat 9 Titik)</text>

        <circle cx={H.x} cy={H.y} r="5" fill="#f43f5e" />
        <text x={H.x - 85} y={H.y + 12} fill="#f43f5e" className="text-xs font-bold">H (Ortosenter)</text>

        {/* Vertices */}
        <text x={A.x - 6} y={A.y - 10} fill="#ffffff" className="text-xs font-bold">A</text>
        <text x={B.x - 16} y={B.y + 16} fill="#ffffff" className="text-xs font-bold">B</text>
        <text x={C.x + 8} y={C.y + 16} fill="#ffffff" className="text-xs font-bold">C</text>

        {/* Formula Box */}
        <rect x="20" y="255" width="360" height="46" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
        <text x="200" y="273" textAnchor="middle" fill="#f43f5e" className="text-xs font-mono font-bold">
          Garis Euler: OG : GH = 1 : 2 (HG = 2 GO) & ON = NH
        </text>
        <text x="200" y="290" textAnchor="middle" fill="#a855f7" className="text-[10px]">
          Lingkaran Sembilan Titik (Ungu, R = ½ R_luar) melalui 3 titik tengah, 3 kaki tinggi, & 3 titik Euler.
        </text>
      </svg>
    );
  };

  // ==========================================
  // 6. RENDER MIQUEL'S THEOREM (PIVOT THEOREM)
  // ==========================================
  const renderMiquelTheorem = () => {
    // Triangle ABC
    const A = { x: 200, y: 35 };
    const B = { x: 50, y: 240 };
    const C = { x: 350, y: 240 };

    // Points D on BC, E on CA, F on AB controlled by miquelParam (t in [0.2, 0.8])
    const tD = miquelParam;
    const tE = 0.35 + miquelParam * 0.3;
    const tF = 0.65 - miquelParam * 0.2;

    const D = { x: (1 - tD) * B.x + tD * C.x, y: 240 };
    const E = { x: (1 - tE) * C.x + tE * A.x, y: (1 - tE) * C.y + tE * A.y };
    const F = { x: (1 - tF) * A.x + tF * B.x, y: (1 - tF) * A.y + tF * B.y };

    const getCircle = (P1: {x: number; y: number}, P2: {x: number; y: number}, P3: {x: number; y: number}) => {
      const d = 2 * (P1.x * (P2.y - P3.y) + P2.x * (P3.y - P1.y) + P3.x * (P1.y - P2.y));
      const ux = ((P1.x*P1.x + P1.y*P1.y)*(P2.y - P3.y) + (P2.x*P2.x + P2.y*P2.y)*(P3.y - P1.y) + (P3.x*P3.x + P3.y*P3.y)*(P1.y - P2.y)) / d;
      const uy = ((P1.x*P1.x + P1.y*P1.y)*(P3.x - P2.x) + (P2.x*P2.x + P2.y*P2.y)*(P1.x - P3.x) + (P3.x*P3.x + P3.y*P3.y)*(P2.x - P1.x)) / d;
      const r = Math.hypot(P1.x - ux, P1.y - uy);
      return { cx: ux, cy: uy, r };
    };

    const cAEF = getCircle(A, E, F);
    const cBFD = getCircle(B, F, D);
    const cCDE = getCircle(C, D, E);

    const dx = cBFD.cx - cAEF.cx;
    const dy = cBFD.cy - cAEF.cy;
    const distCC = Math.hypot(dx, dy);
    const aDist = (cAEF.r * cAEF.r - cBFD.r * cBFD.r + distCC * distCC) / (2 * distCC);
    const hDist = Math.sqrt(Math.max(0, cAEF.r * cAEF.r - aDist * aDist));
    const x2 = cAEF.cx + (aDist * dx) / distCC;
    const y2 = cAEF.cy + (aDist * dy) / distCC;
    
    const int1 = { x: x2 + (hDist * dy) / distCC, y: y2 - (hDist * dx) / distCC };
    const int2 = { x: x2 - (hDist * dy) / distCC, y: y2 + (hDist * dx) / distCC };
    const M = Math.hypot(int1.x - F.x, int1.y - F.y) > 5 ? int1 : int2;

    return (
      <svg viewBox="0 0 400 320" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
        <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="rgba(99, 102, 241, 0.05)" stroke="#818cf8" strokeWidth="2.5" />
        <circle cx={cAEF.cx} cy={cAEF.cy} r={cAEF.r} fill="rgba(56, 189, 248, 0.06)" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="4 3" />
        <circle cx={cBFD.cx} cy={cBFD.cy} r={cBFD.r} fill="rgba(16, 185, 129, 0.06)" stroke="#10b981" strokeWidth="1.5" strokeDasharray="4 3" />
        <circle cx={cCDE.cx} cy={cCDE.cy} r={cCDE.r} fill="rgba(244, 63, 94, 0.06)" stroke="#f43f5e" strokeWidth="1.5" strokeDasharray="4 3" />

        <circle cx={A.x} cy={A.y} r="5" fill="#818cf8" />
        <text x={A.x - 6} y={A.y - 10} fill="#ffffff" className="text-xs font-bold">A</text>
        <circle cx={B.x} cy={B.y} r="5" fill="#818cf8" />
        <text x={B.x - 16} y={B.y + 16} fill="#ffffff" className="text-xs font-bold">B</text>
        <circle cx={C.x} cy={C.y} r="5" fill="#818cf8" />
        <text x={C.x + 8} y={C.y + 16} fill="#ffffff" className="text-xs font-bold">C</text>

        <circle cx={D.x} cy={D.y} r="4" fill="#10b981" />
        <text x={D.x - 4} y={D.y + 18} fill="#10b981" className="text-xs font-bold">D</text>
        <circle cx={E.x} cy={E.y} r="4" fill="#f43f5e" />
        <text x={E.x + 8} y={E.y - 2} fill="#f43f5e" className="text-xs font-bold">E</text>
        <circle cx={F.x} cy={F.y} r="4" fill="#38bdf8" />
        <text x={F.x - 18} y={F.y - 2} fill="#38bdf8" className="text-xs font-bold">F</text>

        <circle cx={M.x} cy={M.y} r="6" fill="#f59e0b" className="animate-pulse" />
        <text x={M.x + 8} y={M.y + 4} fill="#fbbf24" className="text-xs font-bold font-mono">M (Titik Miquel)</text>

        <line x1={M.x} y1={M.y} x2={D.x} y2={D.y} stroke="#f59e0b" strokeWidth="1" strokeDasharray="2 2" />
        <line x1={M.x} y1={M.y} x2={E.x} y2={E.y} stroke="#f59e0b" strokeWidth="1" strokeDasharray="2 2" />
        <line x1={M.x} y1={M.y} x2={F.x} y2={F.y} stroke="#f59e0b" strokeWidth="1" strokeDasharray="2 2" />

        <rect x="20" y="260" width="360" height="48" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
        <text x="200" y="278" textAnchor="middle" fill="#fbbf24" className="text-xs font-mono font-bold">
          Teorema Pivot Miquel: Lingkaran AEF, BFD, CDE Berpotongan di M
        </text>
        <text x="200" y="296" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
          Titik M selalu tunggal dan konstan sebagai pusat keserupaan spiral (spiral similarity).
        </text>
      </svg>
    );
  };

  // ==========================================
  // 7. RENDER SIMSON LINE THEOREM
  // ==========================================
  const renderSimsonLine = () => {
    const cx = 200;
    const cy = 135;
    const R = 95;

    const aA = (210 * Math.PI) / 180;
    const aB = (330 * Math.PI) / 180;
    const aC = (90 * Math.PI) / 180;

    const A = { x: cx + R * Math.cos(aA), y: cy + R * Math.sin(aA) };
    const B = { x: cx + R * Math.cos(aB), y: cy + R * Math.sin(aB) };
    const C = { x: cx + R * Math.cos(aC), y: cy + R * Math.sin(aC) };

    const aP = (simsonAngle * Math.PI) / 180;
    const P = { x: cx + R * Math.cos(aP), y: cy + R * Math.sin(aP) };

    const getFoot = (Pt: {x: number; y: number}, L1: {x: number; y: number}, L2: {x: number; y: number}) => {
      const dx = L2.x - L1.x;
      const dy = L2.y - L1.y;
      const t = ((Pt.x - L1.x) * dx + (Pt.y - L1.y) * dy) / (dx * dx + dy * dy);
      return { x: L1.x + t * dx, y: L1.y + t * dy };
    };

    const X = getFoot(P, B, C);
    const Y = getFoot(P, C, A);
    const Z = getFoot(P, A, B);

    return (
      <svg viewBox="0 0 400 320" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
        <circle cx={cx} cy={cy} r={R} fill="rgba(56, 189, 248, 0.04)" stroke="#38bdf8" strokeWidth="2" strokeDasharray="5 3" />
        <polygon points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`} fill="rgba(99, 102, 241, 0.08)" stroke="#818cf8" strokeWidth="2.5" />

        <line x1={A.x - 40} y1={A.y + 20} x2={B.x + 40} y2={B.y - 20} stroke="#475569" strokeWidth="1" strokeDasharray="3 3" />

        <line x1={P.x} y1={P.y} x2={X.x} y2={X.y} stroke="#f43f5e" strokeWidth="1.5" strokeDasharray="3 2" />
        <line x1={P.x} y1={P.y} x2={Y.x} y2={Y.y} stroke="#10b981" strokeWidth="1.5" strokeDasharray="3 2" />
        <line x1={P.x} y1={P.y} x2={Z.x} y2={Z.y} stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="3 2" />

        <line x1={Z.x - 60} y1={Z.y - ((Y.y - Z.y) / (Y.x - Z.x)) * 60} x2={X.x + 60} y2={X.y + ((Y.y - Z.y) / (Y.x - Z.x)) * 60} stroke="#f59e0b" strokeWidth="3" />

        <circle cx={X.x} cy={X.y} r="4" fill="#f43f5e" />
        <text x={X.x + 6} y={X.y + 12} fill="#f43f5e" className="text-xs font-bold">X (kaki BC)</text>
        <circle cx={Y.x} cy={Y.y} r="4" fill="#10b981" />
        <text x={Y.x - 22} y={Y.y - 6} fill="#10b981" className="text-xs font-bold">Y (kaki CA)</text>
        <circle cx={Z.x} cy={Z.y} r="4" fill="#38bdf8" />
        <text x={Z.x + 6} y={Z.y - 6} fill="#38bdf8" className="text-xs font-bold">Z (kaki AB)</text>

        <circle cx={A.x} cy={A.y} r="4" fill="#818cf8" />
        <text x={A.x - 14} y={A.y - 4} fill="#ffffff" className="text-xs font-bold">A</text>
        <circle cx={B.x} cy={B.y} r="4" fill="#818cf8" />
        <text x={B.x + 8} y={B.y + 12} fill="#ffffff" className="text-xs font-bold">B</text>
        <circle cx={C.x} cy={C.y} r="4" fill="#818cf8" />
        <text x={C.x - 14} y={C.y + 16} fill="#ffffff" className="text-xs font-bold">C</text>

        <circle cx={P.x} cy={P.y} r="6" fill="#c084fc" className="animate-pulse" />
        <text x={P.x + 8} y={P.y - 4} fill="#c084fc" className="text-xs font-bold">P ({simsonAngle}°)</text>

        <rect x="20" y="260" width="360" height="48" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
        <text x="200" y="278" textAnchor="middle" fill="#fbbf24" className="text-xs font-mono font-bold">
          Garis Simson: Proyeksi Tegak Lurus X, Y, Z Selalu Kolinear
        </text>
        <text x="200" y="296" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
          Proyeksi ortogonal dari P pada lingkar luar ke tiga sisi selalu membentuk garis lurus.
        </text>
      </svg>
    );
  };

  // ==========================================
  // 8. RENDER PASCAL'S THEOREM (HEXAGRAMMUM MYSTICUM)
  // ==========================================
  const renderPascalTheorem = () => {
    const cx = 200;
    const cy = 130;
    const R = 90;

    const angles = [20, 75, 140, 200, 260, 315].map(deg => (deg + pascalShift) * Math.PI / 180);
    const Pts = angles.map(a => ({ x: cx + R * Math.cos(a), y: cy + R * Math.sin(a) }));

    const [P1, P2, P3, P4, P5, P6] = Pts;

    const getIntersect = (A: {x: number; y: number}, B: {x: number; y: number}, C: {x: number; y: number}, D: {x: number; y: number}) => {
      const a1 = B.y - A.y;
      const b1 = A.x - B.x;
      const c1 = a1 * A.x + b1 * A.y;

      const a2 = D.y - C.y;
      const b2 = C.x - D.x;
      const c2 = a2 * C.x + b2 * C.y;

      const det = a1 * b2 - a2 * b1;
      if (Math.abs(det) < 1e-5) return { x: 200, y: 130 };
      return {
        x: (b2 * c1 - b1 * c2) / det,
        y: (a1 * c2 - a2 * c1) / det
      };
    };

    const X = getIntersect(P1, P2, P4, P5);
    const Y = getIntersect(P2, P3, P5, P6);
    const Z = getIntersect(P3, P4, P6, P1);

    return (
      <svg viewBox="0 0 400 320" className="w-full h-auto bg-slate-900 rounded-2xl shadow-inner border border-slate-800">
        <circle cx={cx} cy={cy} r={R} fill="rgba(168, 85, 247, 0.04)" stroke="#a855f7" strokeWidth="2" strokeDasharray="5 3" />

        <line x1={P1.x} y1={P1.y} x2={P2.x} y2={P2.y} stroke="#38bdf8" strokeWidth="1.5" />
        <line x1={P2.x} y1={P2.y} x2={P3.x} y2={P3.y} stroke="#10b981" strokeWidth="1.5" />
        <line x1={P3.x} y1={P3.y} x2={P4.x} y2={P4.y} stroke="#f43f5e" strokeWidth="1.5" />
        <line x1={P4.x} y1={P4.y} x2={P5.x} y2={P5.y} stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="3 2" />
        <line x1={P5.x} y1={P5.y} x2={P6.x} y2={P6.y} stroke="#10b981" strokeWidth="1.5" strokeDasharray="3 2" />
        <line x1={P6.x} y1={P6.y} x2={P1.x} y2={P1.y} stroke="#f43f5e" strokeWidth="1.5" strokeDasharray="3 2" />

        <line x1={X.x} y1={X.y} x2={Z.x} y2={Z.y} stroke="#fbbf24" strokeWidth="3" />

        <circle cx={X.x} cy={X.y} r="5" fill="#fbbf24" />
        <text x={X.x + 6} y={X.y - 4} fill="#fbbf24" className="text-xs font-bold font-mono">X (12∩45)</text>

        <circle cx={Y.x} cy={Y.y} r="5" fill="#fbbf24" />
        <text x={Y.x + 6} y={Y.y + 12} fill="#fbbf24" className="text-xs font-bold font-mono">Y (23∩56)</text>

        <circle cx={Z.x} cy={Z.y} r="5" fill="#fbbf24" />
        <text x={Z.x - 24} y={Z.y + 12} fill="#fbbf24" className="text-xs font-bold font-mono">Z (34∩61)</text>

        {Pts.map((p, idx) => (
          <g key={idx}>
            <circle cx={p.x} cy={p.y} r="4" fill="#ffffff" />
            <text x={p.x + (p.x > cx ? 6 : -12)} y={p.y + (p.y > cy ? 12 : -6)} fill="#ffffff" className="text-xs font-extrabold">{idx + 1}</text>
          </g>
        ))}

        <rect x="20" y="260" width="360" height="48" rx="10" fill="#0f172a" stroke="#334155" strokeWidth="1" />
        <text x="200" y="278" textAnchor="middle" fill="#fbbf24" className="text-xs font-mono font-bold">
          Garis Pascal: Titik Potong Sisi-Sisi Berhadapan X, Y, Z Kolinear
        </text>
        <text x="200" y="296" textAnchor="middle" fill="#94a3b8" className="text-[10px]">
          Teorema Hexagrammum Mysticum Pascal untuk 6 titik pada irisan kerucut (konik).
        </text>
      </svg>
    );
  };

  return (
    <div className="my-6 p-5 sm:p-6 rounded-3xl bg-slate-950 border border-slate-800 text-slate-100 space-y-4 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-extrabold text-white">
              {title || 'Diagram Geometri Interaktif IMO'}
            </h4>
            <p className="text-[11px] text-slate-400">
              {caption || 'Visualisasi presisi konfigurasi ruang, titik-titik istimewa, dan kesamaan rasio/sudut.'}
            </p>
          </div>
        </div>

        {/* Mode Toggle Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {type === 'ceva-menelaus' && (
            <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-bold">
              <button
                onClick={() => setCevaMode('ceva')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  cevaMode === 'ceva'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Teorema Ceva
              </button>
              <button
                onClick={() => setCevaMode('menelaus')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  cevaMode === 'menelaus'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Teorema Menelaus
              </button>
            </div>
          )}

          {type === 'cyclic-quad' && (
            <button
              onClick={() => setShowAngleColors(!showAngleColors)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-purple-300 font-bold flex items-center space-x-1 border border-slate-700"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{showAngleColors ? 'Sembunyikan Sorotan' : 'Sorot Busur & Sudut'}</span>
            </button>
          )}

          {type === 'power-of-point' && (
            <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-bold">
              <button
                onClick={() => setPowerSubMode('power')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  powerSubMode === 'power'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Kuasa Titik
              </button>
              <button
                onClick={() => setPowerSubMode('radical')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  powerSubMode === 'radical'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Sumbu Radikal
              </button>
            </div>
          )}

          {type === 'incircle-excircle' && (
            <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-bold">
              <button
                onClick={() => setIncircleMode('incircle')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  incircleMode === 'incircle'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Incircle
              </button>
              <button
                onClick={() => setIncircleMode('excircle')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  incircleMode === 'excircle'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Excircle (A-Excircle)
              </button>
            </div>
          )}

          {type === 'euler-line' && (
            <button
              onClick={() => setShowNinePoints(!showNinePoints)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-purple-300 font-bold flex items-center space-x-1 border border-slate-700"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{showNinePoints ? 'Sembunyikan 9 Titik' : 'Tampilkan 9 Titik'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main SVG Interactive Canvas Area */}
      <div className="relative">
        {type === 'ceva-menelaus' && renderCevaMenelaus()}
        {type === 'cyclic-quad' && renderCyclicQuad()}
        {type === 'power-of-point' && renderPowerOfPoint()}
        {type === 'incircle-excircle' && renderIncircleExcircle()}
        {type === 'euler-line' && renderEulerLine()}
        {type === 'miquel-theorem' && renderMiquelTheorem()}
        {type === 'simson-line' && renderSimsonLine()}
        {type === 'pascal-theorem' && renderPascalTheorem()}
      </div>

      {/* Interactive Controls & Sliders depending on Diagram Type */}
      {type === 'ceva-menelaus' && cevaMode === 'ceva' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Sliders className="w-4 h-4 text-indigo-400" />
            <span>Atur Bobot Barisentrik Titik P (wA, wB, wC):</span>
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex items-center space-x-2">
              <span className="text-slate-400 font-mono font-bold w-6">wA:</span>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.5"
                value={wA}
                onChange={(e) => setWA(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
              <span className="font-mono text-indigo-400 font-bold w-8">{wA.toFixed(1)}</span>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-slate-400 font-mono font-bold w-6">wB:</span>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.5"
                value={wB}
                onChange={(e) => setWB(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <span className="font-mono text-emerald-400 font-bold w-8">{wB.toFixed(1)}</span>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-slate-400 font-mono font-bold w-6">wC:</span>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.5"
                value={wC}
                onChange={(e) => setWC(Number(e.target.value))}
                className="w-full accent-blue-500 cursor-pointer"
              />
              <span className="font-mono text-blue-400 font-bold w-8">{wC.toFixed(1)}</span>
            </div>
          </div>
        </div>
      )}

      {type === 'ceva-menelaus' && cevaMode === 'menelaus' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Sliders className="w-4 h-4 text-rose-400" />
            <span>Atur Posisi Garis Transversal Menelaus (F pada AB & D pada BC):</span>
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center space-x-2">
              <span className="text-slate-400 font-mono font-bold w-12">F (AB):</span>
              <input
                type="range"
                min="0.2"
                max="0.8"
                step="0.05"
                value={lambdaF}
                onChange={(e) => setLambdaF(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
              <span className="font-mono text-rose-400 font-bold w-12">{(lambdaF/(1-lambdaF)).toFixed(2)}</span>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-slate-400 font-mono font-bold w-12">D (BC):</span>
              <input
                type="range"
                min="0.2"
                max="0.8"
                step="0.05"
                value={muD}
                onChange={(e) => setMuD(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
              <span className="font-mono text-rose-400 font-bold w-12">{(muD/(1-muD)).toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}

      {type === 'cyclic-quad' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Info className="w-4 h-4 text-amber-400" />
            <span>Geser Posisi Sudut Titik D sepanjang Lingkaran:</span>
          </span>
          <div className="flex items-center space-x-3 w-full sm:w-1/2">
            <input
              type="range"
              min="275"
              max="355"
              value={quadAngle}
              onChange={(e) => setQuadAngle(Number(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <span className="font-mono text-indigo-400 font-bold">{quadAngle}°</span>
          </div>
        </div>
      )}

      {type === 'power-of-point' && powerSubMode === 'power' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Info className="w-4 h-4 text-emerald-400" />
            <span>Atur Jarak Titik P ke Pusat Lingkaran (OP):</span>
          </span>
          <div className="flex items-center space-x-3 w-full sm:w-1/2">
            <input
              type="range"
              min="110"
              max="220"
              value={pointPDist}
              onChange={(e) => setPointPDist(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <span className="font-mono text-emerald-400 font-bold">{pointPDist}px</span>
          </div>
        </div>
      )}

      {type === 'miquel-theorem' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>Atur Posisi Titik D pada Sisi BC:</span>
          </span>
          <div className="flex items-center space-x-3 w-full sm:w-1/2">
            <input
              type="range"
              min="0.2"
              max="0.8"
              step="0.05"
              value={miquelParam}
              onChange={(e) => setMiquelParam(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <span className="font-mono text-amber-400 font-bold">{miquelParam.toFixed(2)}</span>
          </div>
        </div>
      )}

      {type === 'simson-line' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Info className="w-4 h-4 text-purple-400" />
            <span>Putar Titik P pada Lingkaran Luar (Sudut P):</span>
          </span>
          <div className="flex items-center space-x-3 w-full sm:w-1/2">
            <input
              type="range"
              min="10"
              max="350"
              value={simsonAngle}
              onChange={(e) => setSimsonAngle(Number(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
            <span className="font-mono text-purple-400 font-bold">{simsonAngle}°</span>
          </div>
        </div>
      )}

      {type === 'pascal-theorem' && (
        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <span className="text-slate-300 font-bold flex items-center space-x-1.5">
            <Sliders className="w-4 h-4 text-yellow-400" />
            <span>Rotasi Konfigurasi 6 Titik Hexagram:</span>
          </span>
          <div className="flex items-center space-x-3 w-full sm:w-1/2">
            <input
              type="range"
              min="0"
              max="180"
              value={pascalShift}
              onChange={(e) => setPascalShift(Number(e.target.value))}
              className="w-full accent-yellow-500 cursor-pointer"
            />
            <span className="font-mono text-yellow-400 font-bold">{pascalShift}°</span>
          </div>
        </div>
      )}
    </div>
  );
};
