import React, { useState } from 'react';
import { IMOProblem, IMOTopic, DifficultyLevel, UserProgress } from '../types';
import { MathRenderer } from './MathRenderer';
import { 
  Search, Filter, Bookmark, Eye, Lightbulb, CheckCircle2, 
  PenTool, Sparkles, RefreshCw, ChevronDown, ChevronUp, Plus, Target
} from 'lucide-react';

interface ProblemBankProps {
  problems: IMOProblem[];
  selectedTopicFilter?: string;
  userProgress: UserProgress;
  onToggleBookmark: (problemId: string) => void;
  onSelectProblemForProof: (problem: IMOProblem) => void;
  onAddNewProblem: (newProblem: IMOProblem) => void;
}

export const ProblemBank: React.FC<ProblemBankProps> = ({
  problems,
  selectedTopicFilter = 'Semua',
  userProgress,
  onToggleBookmark,
  onSelectProblemForProof,
  onAddNewProblem,
}) => {
  const [topicFilter, setTopicFilter] = useState<string>(selectedTopicFilter);
  const [difficultyFilter, setDifficultyFilter] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // State for expanded hints/solutions
  const [expandedHints, setExpandedHints] = useState<Record<string, number>>({});
  const [showSolution, setShowSolution] = useState<Record<string, boolean>>({});

  // Generating new AI problem state
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const topics: ('Semua' | IMOTopic)[] = ['Semua', 'Aljabar', 'Kombinatorika', 'Geometri', 'Teori Bilangan'];
  const difficulties: ('Semua' | DifficultyLevel)[] = ['Semua', 'Kota/Provinsi', 'OSN Nasional', 'IMO', 'IMO Shortlist'];

  const filteredProblems = problems.filter((p) => {
    const matchesTopic = topicFilter === 'Semua' || p.topic === topicFilter;
    const matchesDiff = difficultyFilter === 'Semua' || p.difficulty === difficultyFilter;
    const matchesSearch = 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.statement.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.source.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTopic && matchesDiff && matchesSearch;
  });

  const toggleHintStep = (id: string, totalHints: number) => {
    setExpandedHints((prev) => {
      const current = prev[id] || 0;
      if (current >= totalHints) {
        return { ...prev, [id]: 0 }; // collapse
      } else {
        return { ...prev, [id]: current + 1 }; // show next hint
      }
    });
  };

  const toggleSolutionVisibility = (id: string) => {
    setShowSolution((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleGenerateAIProblem = async () => {
    setIsGenerating(true);
    try {
      const targetTopic = topicFilter === 'Semua' ? 'Aljabar' : topicFilter;
      const targetDiff = difficultyFilter === 'Semua' ? 'OSN Nasional' : difficultyFilter;

      const res = await fetch('/api/gemini/generate-problem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: targetTopic, difficulty: targetDiff }),
      });

      if (!res.ok) throw new Error('Gagal membuat soal dari AI');
      const data = await res.json();

      if (data && data.title && data.statement) {
        const newProb: IMOProblem = {
          id: `ai-${Date.now()}`,
          title: data.title,
          topic: data.topic || targetTopic,
          difficulty: data.difficulty || targetDiff,
          year: data.year || '2026 AI',
          source: 'Gemini AI Studio IMO Engine',
          statement: data.statement,
          hints: data.hints || ['Gunakan metode substitusi atau pembuktian kontradiksi.'],
          solution: data.solution || 'Solusi pembuktian terinci.',
          keyConcepts: ['AI Generated', 'Olimpiade Matematika'],
        };
        onAddNewProblem(newProb);
      }
    } catch (err) {
      console.error('Error generating AI problem:', err);
      alert('Gagal menghasilkan soal baru dari AI. Pastikan server Gemini aktif.');
    } finally {
      setIsGenerating(false);
    }
  };

  const getDifficultyBadgeColor = (diff: DifficultyLevel) => {
    switch (diff) {
      case 'Kota/Provinsi':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'OSN Nasional':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'IMO':
      case 'IMO Shortlist':
        return 'bg-purple-50 text-purple-800 border-purple-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold mb-2">
            <Target className="w-3.5 h-3.5" />
            <span>Koleksi Soal Olimpiade Autentik</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Bank Soal IMO & OSN</h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Kumpulan soal autentik Olimpiade Sains Nasional (OSN) & IMO beserta petunjuk bertahap.
          </p>
        </div>

        {/* Generate AI Problem Button */}
        <button
          onClick={handleGenerateAIProblem}
          disabled={isGenerating}
          className="w-full sm:w-auto px-5 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
        >
          {isGenerating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Membuat Soal Baru via AI...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate Soal Orisinal via AI</span>
            </>
          )}
        </button>
      </div>

      {/* Search & Filters Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 space-y-4 shadow-xs">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari berdasarkan judul, kata kunci, atau sumber..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {/* Difficulty Dropdown */}
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={difficultyFilter}
              onChange={(e) => setDifficultyFilter(e.target.value)}
              className="w-full sm:w-auto bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-700 font-semibold focus:outline-none focus:border-indigo-500"
            >
              <option value="Semua">Semua Tingkat Kesulitan</option>
              {difficulties.filter((d) => d !== 'Semua').map((diff) => (
                <option key={diff} value={diff}>
                  {diff}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Topic Filter Pills */}
        <div className="flex overflow-x-auto no-scrollbar touch-pan-x sm:flex-wrap items-center gap-2 pt-3 border-t border-slate-100 py-1">
          <span className="text-xs text-slate-400 self-center mr-1 font-bold uppercase tracking-wider text-[10px] shrink-0">Topik:</span>
          {topics.map((top) => (
            <button
              key={top}
              onClick={() => setTopicFilter(top)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                topicFilter === top
                  ? 'bg-indigo-600 text-white shadow-xs font-bold'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {top}
            </button>
          ))}
        </div>
      </div>

      {/* Problems List */}
      <div className="space-y-6">
        {filteredProblems.length === 0 ? (
          <div className="p-12 text-center bg-white border border-slate-200 rounded-3xl space-y-3 shadow-xs">
            <p className="text-slate-600 text-sm font-bold">Tidak ada soal yang cocok dengan filter Anda.</p>
            <button
              onClick={() => {
                setTopicFilter('Semua');
                setDifficultyFilter('Semua');
                setSearchQuery('');
              }}
              className="text-indigo-600 text-xs font-bold hover:underline"
            >
              Reset Filter
            </button>
          </div>
        ) : (
          filteredProblems.map((problem) => {
            const isBookmarked = userProgress.bookmarkedProblemIds.includes(problem.id);
            const isSolved = userProgress.solvedProblemIds.includes(problem.id);
            const activeHintStep = expandedHints[problem.id] || 0;
            const isSolVisible = showSolution[problem.id] || false;

            return (
              <div
                key={problem.id}
                className={`rounded-3xl bg-white border ${
                  isSolved ? 'border-emerald-300 bg-emerald-50/20' : 'border-slate-200'
                } p-6 sm:p-8 space-y-5 transition-all shadow-sm hover:border-indigo-300`}
              >
                {/* Header */}
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                        {problem.topic}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getDifficultyBadgeColor(problem.difficulty)}`}>
                        {problem.difficulty}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        {problem.source} ({problem.year})
                      </span>
                      {isSolved && (
                        <span className="flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Terbukti</span>
                        </span>
                      )}
                    </div>

                    <h3 className="text-xl font-bold text-slate-900">
                      {problem.title}
                    </h3>
                  </div>

                  {/* Bookmark Toggle */}
                  <button
                    onClick={() => onToggleBookmark(problem.id)}
                    className={`p-2 rounded-xl border text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                      isBookmarked
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-slate-50 text-slate-500 hover:text-slate-900 border-slate-200'
                    }`}
                    title={isBookmarked ? 'Hapus Simpan' : 'Simpan Soal'}
                  >
                    <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-500 text-amber-500' : ''}`} />
                  </button>
                </div>

                {/* Problem Statement */}
                <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs sm:text-sm leading-relaxed text-slate-800">
                  <MathRenderer content={problem.statement} />
                </div>

                {/* Key Concepts Tags */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-slate-400 font-bold text-[11px] uppercase mr-1">Konsep Kunci:</span>
                  {problem.keyConcepts.map((concept, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-0.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-medium"
                    >
                      {concept}
                    </span>
                  ))}
                </div>

                {/* Progressive Hints Drawer */}
                {activeHintStep > 0 && (
                  <div className="space-y-2 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs">
                    <div className="font-bold text-amber-900 flex items-center space-x-1.5">
                      <Lightbulb className="w-4 h-4 text-amber-600" />
                      <span>Petunjuk Langkah {activeHintStep} dari {problem.hints.length}:</span>
                    </div>
                    {problem.hints.slice(0, activeHintStep).map((hint, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-white border border-amber-100 text-slate-800 font-medium">
                        <MathRenderer content={hint} />
                      </div>
                    ))}
                  </div>
                )}

                {/* Full Solution Drawer */}
                {isSolVisible && (
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
                    <div className="font-bold text-indigo-900 flex items-center justify-between border-b border-slate-200 pb-2">
                      <span>Solusi Resmi & Pembuktian Lengkap:</span>
                      <span className="text-[10px] text-slate-500 font-mono">IMO Official Standard</span>
                    </div>
                    <MathRenderer content={problem.solution} />
                  </div>
                )}

                {/* Card Action Buttons */}
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    {/* Hint Toggle Button */}
                    <button
                      onClick={() => toggleHintStep(problem.id, problem.hints.length)}
                      className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold flex items-center space-x-1.5 transition-colors"
                    >
                      <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                      <span>
                        {activeHintStep === 0
                          ? 'Buka Petunjuk'
                          : activeHintStep < problem.hints.length
                          ? `Petunjuk (${activeHintStep}/${problem.hints.length})`
                          : 'Tutup Petunjuk'}
                      </span>
                    </button>

                    {/* Solution Toggle Button */}
                    <button
                      onClick={() => toggleSolutionVisibility(problem.id)}
                      className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold flex items-center space-x-1.5 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5 text-indigo-600" />
                      <span>{isSolVisible ? 'Sembunyikan Solusi' : 'Solusi Lengkap'}</span>
                    </button>
                  </div>

                  {/* Submit Proof / Workspace Button */}
                  <button
                    onClick={() => onSelectProblemForProof(problem)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-indigo-600/20"
                  >
                    <PenTool className="w-3.5 h-3.5" />
                    <span>Tulis Pembuktian di Papan</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
