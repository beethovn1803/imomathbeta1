import React, { useState } from 'react';
import { 
  BookOpen, Target, PenTool, Bot, Award, Flame, Bookmark, Sparkles, 
  LayoutDashboard, BookMarked, Menu, X, ChevronRight, Grid
} from 'lucide-react';
import { UserProgress } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userProgress: UserProgress;
  onOpenBookmarks: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  userProgress,
  onOpenBookmarks,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'overview', label: 'Beranda', sublabel: 'Dashboard & Soal Harian', icon: LayoutDashboard },
    { id: 'theory', label: 'Materi & Teorema', sublabel: '28+ Modul Kurikulum', icon: BookOpen },
    { id: 'dictionary', label: 'Kamus Simbol', sublabel: 'Notasi & Rumus TeX', icon: BookMarked },
    { id: 'problems', label: 'Bank Soal IMO', sublabel: 'Ratusan Soal + Filter', icon: Target },
    { id: 'workspace', label: 'Papan Pembuktian', sublabel: 'Editor TeX + Evaluator AI', icon: PenTool },
    { id: 'tutor', label: 'Tutor AI Gemini', sublabel: 'Diskusi & Bimbingan 24/7', icon: Bot },
    { id: 'exam', label: 'Simulasi IMO', sublabel: 'Ujian Waktu Nyata', icon: Award },
  ];

  // Mobile Bottom Bar items (Top 4 most used + Menu toggle)
  const mobileBottomTabs = [
    { id: 'overview', label: 'Beranda', icon: LayoutDashboard },
    { id: 'theory', label: 'Materi', icon: BookOpen },
    { id: 'problems', label: 'Soal', icon: Target },
    { id: 'workspace', label: 'Papan', icon: PenTool },
  ];

  const handleSelectTab = (id: string) => {
    setActiveTab(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Header */}
      <header className="sticky top-0 z-40 pt-2 sm:pt-4 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-xs sm:shadow-sm rounded-2xl px-3 sm:px-6">
          <div className="flex items-center justify-between h-14 sm:h-16">
            {/* Brand Logo */}
            <div 
              onClick={() => handleSelectTab('overview')}
              className="flex items-center space-x-2 sm:space-x-2.5 cursor-pointer group shrink-0"
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-serif font-bold text-base sm:text-xl shadow-xs group-hover:scale-105 transition-transform duration-200">
                Σ
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="font-sans font-extrabold text-slate-800 tracking-tight text-base sm:text-xl">
                    IMO<span className="text-indigo-600">Studio</span>
                  </span>
                  <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold tracking-wider bg-indigo-50 text-indigo-600 border border-indigo-100 rounded-full uppercase">
                    Indonesia
                  </span>
                </div>
                <p className="text-[9px] sm:text-[11px] text-slate-400 font-medium -mt-1 truncate max-w-[90px] sm:max-w-none">
                  Akademi IMO
                </p>
              </div>
            </div>

            {/* Desktop Nav Items */}
            <nav className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* User Progress Stats & Actions */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              {/* Streak Badge */}
              <div className="flex items-center space-x-1 sm:space-x-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl bg-amber-50 border border-amber-200/80 text-[11px] sm:text-xs font-bold text-amber-900 shadow-2xs">
                <Flame className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500 fill-amber-500 shrink-0" />
                <span>{userProgress.streakDays}d<span className="hidden sm:inline"> Streak</span></span>
              </div>

              {/* Bookmarks */}
              <button
                onClick={onOpenBookmarks}
                className="relative p-1.5 sm:p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 transition-colors shadow-2xs"
                title="Soal Tersimpan"
              >
                <Bookmark className="w-4 h-4 text-indigo-600" />
                {userProgress.bookmarkedProblemIds.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {userProgress.bookmarkedProblemIds.length}
                  </span>
                )}
              </button>

              {/* Solved Stats (Desktop) */}
              <div className="hidden lg:flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>{userProgress.solvedProblemIds.length} Selesai</span>
              </div>

              {/* Mobile Menu Button (Hamburger) */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-1.5 sm:p-2 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5 text-indigo-600" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-down Drawer / Full Menu Sheet */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden bg-slate-900/60 backdrop-blur-xs flex flex-col justify-start pt-16 px-3">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-4 sm:p-5 max-h-[85vh] overflow-y-auto space-y-4 animate-in slide-in-from-top duration-200">
            {/* Header in Mobile Sheet */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <Grid className="w-5 h-5 text-indigo-600" />
                <h3 className="font-extrabold text-slate-900 text-base">Navigasi Modul HP</h3>
              </div>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1.5 rounded-full bg-slate-100 text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* User Stats Banner in Mobile Sheet */}
            <div className="grid grid-cols-2 gap-2 bg-indigo-50/60 border border-indigo-100 p-3 rounded-2xl">
              <div className="flex items-center space-x-2">
                <Flame className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
                <div>
                  <p className="text-[10px] text-indigo-900/70 font-semibold">Streak Belajar</p>
                  <p className="text-xs font-bold text-slate-900">{userProgress.streakDays} Hari Beruntun</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <p className="text-[10px] text-indigo-900/70 font-semibold">Terbukti Selesai</p>
                  <p className="text-xs font-bold text-slate-900">{userProgress.solvedProblemIds.length} Soal IMO</p>
                </div>
              </div>
            </div>

            {/* List of All 7 Nav Items */}
            <div className="space-y-1.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl text-left transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-xs font-bold'
                        : 'bg-slate-50/80 hover:bg-slate-100 text-slate-800 border border-slate-200/60 font-semibold'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-xl ${isActive ? 'bg-white/20 text-white' : 'bg-white text-indigo-600 shadow-2xs'}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold">{item.label}</p>
                        <p className={`text-[10px] ${isActive ? 'text-indigo-100' : 'text-slate-400'}`}>{item.sublabel}</p>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Ergonomic Mobile Bottom Tab Bar (Fixed at HP bottom for 1-thumb touch navigation) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-xl px-2 py-1.5 pb-safe">
        <div className="grid grid-cols-5 gap-1 items-center max-w-md mx-auto">
          {mobileBottomTabs.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all ${
                  isActive
                    ? 'text-indigo-600 font-extrabold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <div className={`p-1 rounded-lg ${isActive ? 'bg-indigo-50 text-indigo-600' : ''}`}>
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <span className="text-[10px] leading-tight mt-0.5 tracking-tight font-medium">
                  {item.label}
                </span>
              </button>
            );
          })}

          {/* 5th Tab: Menu / Lainnya button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all ${
              isMobileMenuOpen || !mobileBottomTabs.some(t => t.id === activeTab)
                ? 'text-indigo-600 font-extrabold'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <div className={`p-1 rounded-lg ${isMobileMenuOpen ? 'bg-indigo-50 text-indigo-600' : ''}`}>
              <Grid className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <span className="text-[10px] leading-tight mt-0.5 tracking-tight font-medium">
              Lainnya
            </span>
          </button>
        </div>
      </nav>
    </>
  );
};

