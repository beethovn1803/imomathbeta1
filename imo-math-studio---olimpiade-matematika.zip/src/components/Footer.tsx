import React from 'react';
import { Sparkles, Heart, Award, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-100/80 border-t border-slate-200 text-slate-500 text-xs py-12 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-extrabold text-xs shadow-md shadow-indigo-600/20">
                IMO
              </div>
              <span className="font-extrabold text-slate-900 text-base tracking-tight">IMO Studio</span>
            </div>
            <p className="text-slate-500 text-xs leading-relaxed">
              Platform pembelajaran Olimpiade Matematika Internasional (IMO) & OSN Indonesia dengan verifikasi logika cerdas berpresisi tinggi.
            </p>
          </div>

          {/* Col 2: IMO Pillars */}
          <div className="space-y-2">
            <p className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">4 Pilar IMO</p>
            <ul className="space-y-1 text-slate-500 font-medium">
              <li>• Aljabar & Ketaksamaan</li>
              <li>• Kombinatorika & Invarian</li>
              <li>• Geometri Bidang & Siklik</li>
              <li>• Teori Bilangan & Modulo</li>
            </ul>
          </div>

          {/* Col 3: Inspirational Quote */}
          <div className="space-y-2 md:col-span-2 p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <p className="font-bold text-indigo-600 text-[11px] uppercase tracking-wider">Kutipan Inspiratif IMO:</p>
            <blockquote className="italic text-slate-700 text-xs leading-relaxed">
              "Matematika olimpiade bukan hanya tentang menghitung angka, tetapi tentang seni menemukan keteraturan di tengah kerumitan dan membangun argumentasi kaku yang tak terbantahkan."
            </blockquote>
            <p className="text-slate-400 text-[11px] font-bold text-right">— Terinspirasi oleh Peraih Medali Fields IMO</p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <p>© 2026 IMO Math Studio Indonesia. Terintegrasi dengan Google Gemini AI Engine.</p>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="font-medium">Presisi Pembuktian LaTeX & Rubrik IMO 0-7 Poin</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

