import React, { useState } from 'react';
import { IMOProblem, ProofEvaluationResult, UserProgress } from '../types';
import { MathRenderer } from './MathRenderer';
import { 
  PenTool, Sparkles, RefreshCw, CheckCircle2, AlertTriangle, 
  HelpCircle, Eye, Code, Award, Send, Save, ArrowLeft
} from 'lucide-react';

interface ProofWorkspaceProps {
  activeProblem: IMOProblem | null;
  problems: IMOProblem[];
  userProgress: UserProgress;
  onSelectProblem: (problem: IMOProblem) => void;
  onSaveSubmission: (problemId: string, proof: string, score: number) => void;
}

export const ProofWorkspace: React.FC<ProofWorkspaceProps> = ({
  activeProblem,
  problems,
  userProgress,
  onSelectProblem,
  onSaveSubmission,
}) => {
  const [selectedProb, setSelectedProb] = useState<IMOProblem | null>(activeProblem || problems[0] || null);
  const [userProofText, setUserProofText] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'editor' | 'preview' | 'both'>('both');

  // AI Evaluation state
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<ProofEvaluationResult | null>(null);

  // Math symbols palette items
  const mathPalette = [
    { label: '∀', code: '\\forall ' },
    { label: '∃', code: '\\exists ' },
    { label: '∈', code: '\\in ' },
    { label: '∉', code: '\\notin ' },
    { label: '≡', code: '\\equiv ' },
    { label: 'pmod', code: '\\pmod{n} ' },
    { label: '≤', code: '\\le ' },
    { label: '≥', code: '\\ge ' },
    { label: '≠', code: '\\neq ' },
    { label: '⇒', code: '\\implies ' },
    { label: '⇔', code: '\\iff ' },
    { label: '∑', code: '\\sum_{i=1}^n ' },
    { label: '∏', code: '\\prod_{i=1}^n ' },
    { label: 'frac', code: '\\frac{a}{b} ' },
    { label: 'sqrt', code: '\\sqrt{x} ' },
    { label: 'ℝ', code: '\\mathbb{R} ' },
    { label: 'ℤ', code: '\\mathbb{Z} ' },
    { label: 'ℕ', code: '\\mathbb{N} ' },
    { label: '∠', code: '\\angle ' },
    { label: 'Δ', code: '\\Delta ' },
    { label: '■', code: '\\blacksquare' },
  ];

  const insertSymbol = (code: string) => {
    setUserProofText((prev) => prev + code);
  };

  const handleEvaluateProof = async () => {
    if (!selectedProb) return;
    if (!userProofText.trim()) {
      alert('Tuliskan draf pembuktian Anda terlebih dahulu!');
      return;
    }

    setIsEvaluating(true);
    setEvaluationResult(null);

    try {
      const res = await fetch('/api/gemini/evaluate-proof', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problemTitle: selectedProb.title,
          problemStatement: selectedProb.statement,
          userProof: userProofText,
          expectedTopic: selectedProb.topic,
        }),
      });

      if (!res.ok) throw new Error('Gagal mengevaluasi pembuktian.');
      const data: ProofEvaluationResult = await res.json();

      setEvaluationResult(data);
      if (data.score !== undefined) {
        onSaveSubmission(selectedProb.id, userProofText, data.score);
      }
    } catch (err) {
      console.error('Error evaluating proof:', err);
      alert('Terjadi kesalahan saat mengevaluasi pembuktian dengan AI.');
    } finally {
      setIsEvaluating(false);
    }
  };

  const getScoreColorClass = (score: number) => {
    if (score === 7) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
    if (score >= 5) return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
    if (score >= 3) return 'bg-blue-500/20 text-blue-400 border-blue-500/40';
    return 'bg-red-500/20 text-red-400 border-red-500/40';
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold mb-2">
            <PenTool className="w-3.5 h-3.5" />
            <span>Lembar Cakar & Evaluator Logika</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Papan Pembuktian LaTeX</h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Tuliskan alur logika pembuktian Anda secara eksplisit dan dapatkan penilaian dari Juri AI berskor IMO (0-7 Poin).
          </p>
        </div>

        {/* Problem Selector Dropdown */}
        <div className="w-full md:w-80">
          <label className="block text-xs font-bold text-slate-500 mb-1">Pilih Soal yang Dibuktikan:</label>
          <select
            value={selectedProb?.id || ''}
            onChange={(e) => {
              const prob = problems.find((p) => p.id === e.target.value);
              if (prob) {
                setSelectedProb(prob);
                onSelectProblem(prob);
                setEvaluationResult(null);
              }
            }}
            className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-indigo-500 shadow-2xs"
          >
            {problems.map((p) => (
              <option key={p.id} value={p.id}>
                [{p.topic}] {p.title} ({p.difficulty})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Selected Problem Banner */}
      {selectedProb && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 space-y-3 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                {selectedProb.topic}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200">
                {selectedProb.difficulty}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {selectedProb.source}
              </span>
            </div>
            <span className="text-xs text-indigo-600 font-bold font-mono">
              Rubrik IMO: Maks. 7 Poin
            </span>
          </div>

          <h3 className="text-xl font-bold text-slate-900">
            {selectedProb.title}
          </h3>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs sm:text-sm text-slate-800 leading-relaxed">
            <MathRenderer content={selectedProb.statement} />
          </div>
        </div>
      )}

      {/* Quick Math Symbols Palette */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-xs">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider text-[11px]">Palet Simbol Matematika Cepat:</span>
          <span className="text-[10px] text-slate-400 sm:hidden">Geser ke kanan →</span>
        </div>
        <div className="flex overflow-x-auto no-scrollbar touch-pan-x sm:flex-wrap gap-1.5 py-1">
          {mathPalette.map((sym, idx) => (
            <button
              key={idx}
              onClick={() => insertSymbol(sym.code)}
              className="px-3 py-1.5 rounded-lg bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-indigo-700 font-mono text-xs font-bold transition-colors hover:border-indigo-300 shrink-0"
              title={`Sisipkan ${sym.code}`}
            >
              {sym.label}
            </button>
          ))}
        </div>
      </div>

      {/* Mobile View Mode Toggles */}
      <div className="flex lg:hidden bg-slate-100 p-1 rounded-2xl border border-slate-200 space-x-1 text-xs font-bold">
        <button
          onClick={() => setActiveTab('editor')}
          className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
            activeTab === 'editor' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600'
          }`}
        >
          <Code className="w-3.5 h-3.5" />
          <span>Editor</span>
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
            activeTab === 'preview' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Pratinjau</span>
        </button>
        <button
          onClick={() => setActiveTab('both')}
          className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
            activeTab === 'both' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600'
          }`}
        >
          <PenTool className="w-3.5 h-3.5" />
          <span>Keduanya</span>
        </button>
      </div>

      {/* Editor & Preview Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Editor Box */}
        {(activeTab === 'editor' || activeTab === 'both') && (
          <div className="space-y-3 p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Code className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-slate-800">Editor Pembuktian (LaTeX Enabled)</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                $inline$ / $$block$$
              </span>
            </div>

            <textarea
              value={userProofText}
              onChange={(e) => setUserProofText(e.target.value)}
              placeholder={`Tuliskan alur logika pembuktian Anda di sini...\nContoh:\nMisalkan $P(a,b)$ menyatakan pernyataan asli.\nSubstitusikan $a = 0$, diperoleh $f(0) + 2f(b) = f(f(b))$.\nMisalkan $f(0) = c$...\n$$\\sum_{i=1}^n a_i \\ge n \\sqrt[n]{\\prod_{i=1}^n a_i}$$`}
              className="w-full h-64 sm:h-80 p-4 bg-slate-50 border border-slate-200 rounded-2xl font-mono text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-500 leading-relaxed resize-none"
            />

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
              <button
                onClick={() => setUserProofText('')}
                className="text-xs text-slate-400 hover:text-slate-700 font-semibold text-left"
              >
                Bersihkan Teks
              </button>

              {/* Evaluate Button */}
              <button
                onClick={handleEvaluateProof}
                disabled={isEvaluating}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
              >
                {isEvaluating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Juri AI Memeriksa...</span>
                  </>
                ) : (
                  <>
                    <Award className="w-4 h-4" />
                    <span>Evaluasi Pembuktian (Skor 0-7)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Live Preview Box */}
        {(activeTab === 'preview' || activeTab === 'both') && (
          <div className="space-y-3 p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Eye className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-slate-800">Pratinjau Hasil Render TeX</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">Live Render</span>
            </div>

            <div className="w-full h-64 sm:h-80 p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-2xl overflow-y-auto text-xs leading-relaxed">
              {userProofText.trim() ? (
                <MathRenderer content={userProofText} />
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 italic text-center p-4">
                  Pratinjau pembuktian akan muncul di sini saat Anda mengetik...
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Evaluation Results Card */}
      {evaluationResult && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-indigo-200 space-y-6 shadow-md shadow-indigo-100/50 animate-fade-in">
          {/* Header & Score Badge */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
            <div>
              <div className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                <h3 className="text-xl font-bold text-slate-900">Laporan Evaluasi Juri AI IMO</h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Penilaian kaku berdasar standar komite pembuktian matematika internasional.
              </p>
            </div>

            <div className="px-6 py-3 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-center shadow-2xs">
              <span className="block text-[10px] uppercase font-bold tracking-wider text-indigo-600">Skor Pembuktian</span>
              <span className="text-3xl font-extrabold">{evaluationResult.score} / 7</span>
            </div>
          </div>

          {/* Summary */}
          <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 text-xs text-indigo-950 leading-relaxed space-y-1">
            <span className="font-bold text-indigo-700 block">Ringkasan Evaluasi Juri:</span>
            <MathRenderer content={evaluationResult.summary} />
          </div>

          {/* Strengths & Gaps Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Strengths */}
            <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2">
              <h4 className="font-bold text-emerald-800 flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Kekuatan Logika & Lemma Terbukti:</span>
              </h4>
              <div className="space-y-1.5 text-slate-700">
                {evaluationResult.strengths?.map((str, idx) => (
                  <div key={idx} className="flex items-start space-x-1.5">
                    <span className="text-emerald-600 font-bold">•</span>
                    <MathRenderer content={str} />
                  </div>
                )) || <p>Ide awal yang baik.</p>}
              </div>
            </div>

            {/* Gaps */}
            <div className="p-4 rounded-2xl bg-rose-50/80 border border-rose-200 space-y-2">
              <h4 className="font-bold text-rose-800 flex items-center space-x-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>Celah Logika / Langkah Terlewat:</span>
              </h4>
              <div className="space-y-1.5 text-slate-700">
                {evaluationResult.gaps?.map((gap, idx) => (
                  <div key={idx} className="flex items-start space-x-1.5">
                    <span className="text-rose-600 font-bold">•</span>
                    <MathRenderer content={gap} />
                  </div>
                )) || <p>Tidak ditemukan celah logika utama.</p>}
              </div>
            </div>
          </div>

          {/* Suggestions */}
          {evaluationResult.suggestions && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs space-y-1">
              <h4 className="font-bold text-amber-900 flex items-center space-x-1.5 mb-1">
                <HelpCircle className="w-4 h-4 text-amber-600" />
                <span>Saran Perbaikan Juri:</span>
              </h4>
              <MathRenderer content={evaluationResult.suggestions} />
            </div>
          )}

          {/* Detailed TeX Feedback */}
          {evaluationResult.detailedFeedback && (
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
              <h4 className="font-bold text-slate-900">Ulasan Rinci & Catatan Notasi:</h4>
              <MathRenderer content={evaluationResult.detailedFeedback} />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
