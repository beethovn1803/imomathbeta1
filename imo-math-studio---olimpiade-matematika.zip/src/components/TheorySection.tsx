import React, { useState } from 'react';
import { THEORY_MODULES } from '../data/imoData';
import { IMOTopic, TheoryModule, SubChapter } from '../types';
import { MathRenderer } from './MathRenderer';
import { GeometryVisualizer, GeometryDiagramType } from './GeometryVisualizer';
import { 
  BookOpen, 
  ChevronRight, 
  Lightbulb, 
  Sparkles, 
  X, 
  ArrowRight, 
  Search, 
  GraduationCap, 
  ChevronDown, 
  ChevronUp, 
  Award, 
  Target, 
  Layers,
  Compass,
  Library,
  BookMarked,
  CheckCircle2,
  Flame,
  HelpCircle,
  Edit3
} from 'lucide-react';

interface TheorySectionProps {
  initialTopic?: string;
  onNavigateToProblems: (topic: string) => void;
}

export const TheorySection: React.FC<TheorySectionProps> = ({
  initialTopic,
  onNavigateToProblems,
}) => {
  const [selectedTopicFilter, setSelectedTopicFilter] = useState<string>(initialTopic || 'Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModule, setActiveModule] = useState<TheoryModule | null>(null);
  
  // Tab index: -1 or 0 for Overview, 1..N for sub-chapters
  const [activeSubChapterTab, setActiveSubChapterTab] = useState<number>(0);
  const [overviewDiagramType, setOverviewDiagramType] = useState<GeometryDiagramType>('ceva-menelaus');
  
  // Expanded states for solution toggles: key = `${subChapterId}-${exampleIdx}`
  const [expandedSolutions, setExpandedSolutions] = useState<Record<string, boolean>>({});
  
  // Expanded states for challenge hints and solutions
  const [expandedHints, setExpandedHints] = useState<Record<string, boolean>>({});
  const [expandedChallengeSolutions, setExpandedChallengeSolutions] = useState<Record<string, boolean>>({});
  const [challengeDrafts, setChallengeDrafts] = useState<Record<string, string>>({});

  const topics: ('Semua' | IMOTopic)[] = ['Semua', 'Aljabar', 'Kombinatorika', 'Geometri', 'Teori Bilangan'];

  const filteredModules = THEORY_MODULES.filter((module) => {
    const matchesTopic = selectedTopicFilter === 'Semua' || module.topic === selectedTopicFilter;
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesTopic;

    const matchesTitle = module.title.toLowerCase().includes(query);
    const matchesSubtitle = module.subtitle.toLowerCase().includes(query);
    const matchesSummary = module.summary.toLowerCase().includes(query);
    const matchesTheorems = module.keyTheorems.some((t) => t.name.toLowerCase().includes(query));
    const matchesSubChapters = module.subChapters?.some(s => 
      s.title.toLowerCase().includes(query) || s.description.toLowerCase().includes(query)
    );

    return matchesTopic && (matchesTitle || matchesSubtitle || matchesSummary || matchesTheorems || matchesSubChapters);
  });

  const toggleSolution = (key: string) => {
    setExpandedSolutions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleHint = (key: string) => {
    setExpandedHints(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleChallengeSolution = (key: string) => {
    setExpandedChallengeSolutions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleDraftChange = (key: string, value: string) => {
    setChallengeDrafts(prev => ({ ...prev, [key]: value }));
  };

  const openModuleModal = (module: TheoryModule) => {
    setActiveModule(module);
    setActiveSubChapterTab(0); // Default to sub-chapter 1 if available, or overview
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold mb-2">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Modul Kuliah & Pembahasan Berjenjang</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Materi Mendalam & Sub-Bab IMO</h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Pelajari konsep teoretis per sub-bab, contoh soal pembahasan tingkat Intermediate, Medium, Hard, lalu latih kemandirian dengan Bank Soal IMO.
          </p>
        </div>

        {/* Topic Filter Pills */}
        <div className="flex flex-wrap gap-2">
          {topics.map((top) => (
            <button
              key={top}
              onClick={() => setSelectedTopicFilter(top)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                selectedTopicFilter === top
                  ? 'bg-indigo-600 text-white font-bold shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200 shadow-2xs'
              }`}
            >
              {top}
            </button>
          ))}
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Cari materi, sub-bab, atau teorema (misal: Cauchy-Schwarz, Sub-Bab AM-GM, Pigeonhole)..."
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-medium shadow-2xs"
        />
      </div>

      {/* Modules Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredModules.length === 0 ? (
          <div className="md:col-span-2 p-12 text-center bg-white border border-slate-200 rounded-3xl space-y-2">
            <p className="text-slate-600 font-bold text-sm">Tidak ada materi yang sesuai dengan pencarian.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedTopicFilter('Semua');
              }}
              className="text-xs text-indigo-600 font-bold hover:underline"
            >
              Reset Filter & Pencarian
            </button>
          </div>
        ) : (
          filteredModules.map((module) => (
            <div
              key={module.id}
              onClick={() => openModuleModal(module)}
              className="group rounded-3xl bg-white border border-slate-200 hover:border-indigo-400 p-6 flex flex-col justify-between transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                    {module.topic}
                  </span>
                  <span className="text-[11px] text-slate-500 font-semibold flex items-center space-x-1">
                    <Layers className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{module.subChapters?.length || 0} Sub-Bab Mendalam</span>
                  </span>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {module.title}
                  </h3>
                  <p className="text-xs font-bold text-indigo-600/90 mt-1">
                    {module.subtitle}
                  </p>
                </div>

                <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">
                  {module.summary}
                </p>

                {/* Sub-Chapter Preview List */}
                {module.subChapters && module.subChapters.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                      <BookOpen className="w-3 h-3 text-indigo-500" />
                      <span>Daftar Sub-Bab & Contoh Soal Graded:</span>
                    </p>
                    <div className="space-y-1.5">
                      {module.subChapters.map((sub, idx) => (
                        <div
                          key={sub.id}
                          className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs flex items-center justify-between group-hover:bg-indigo-50/50 transition-colors"
                        >
                          <div className="truncate pr-2">
                            <span className="font-bold text-indigo-950">Sub-Bab {idx + 1}: </span>
                            <span className="text-slate-700 font-medium">{sub.title}</span>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                            3 Soal
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    openModuleModal(module);
                  }}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs flex items-center space-x-1.5 transition-colors"
                >
                  <span>Buka Modul & Sub-Bab</span>
                  <BookOpen className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onNavigateToProblems(module.topic);
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 flex items-center space-x-1 font-semibold"
                >
                  <span>Latihan Soal IMO</span>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-600" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Deep Learning Sub-Chapter Modal */}
      {activeModule && (
        <div 
          onClick={() => setActiveModule(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-5xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-8 shadow-2xl space-y-6 my-6 max-h-[92vh] overflow-y-auto text-slate-900"
          >
            {/* Close Button */}
            <button
              onClick={() => setActiveModule(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="pr-12 sm:pr-10">
              <div className="flex items-center space-x-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                  {activeModule.topic}
                </span>
                <span className="text-xs font-semibold text-slate-400">
                  Modul Kuliah IMO
                </span>
              </div>
              <h2 className="text-xl sm:text-3xl font-extrabold text-slate-900 mt-2 tracking-tight">
                {activeModule.title}
              </h2>
              <p className="text-xs sm:text-sm text-indigo-600 font-bold mt-1">
                {activeModule.subtitle}
              </p>
            </div>

            {/* Sub-Chapter Navigation Tabs */}
            <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar touch-pan-x space-x-2 pb-1">
              <button
                onClick={() => setActiveSubChapterTab(0)}
                className={`px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all whitespace-nowrap shrink-0 flex items-center space-x-2 border-b-2 ${
                  activeSubChapterTab === 0
                    ? 'border-indigo-600 text-indigo-600 bg-indigo-50/60'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>Ikhtisar & Teorema Kunci</span>
              </button>

              {activeModule.subChapters?.map((sub, idx) => (
                <button
                  key={sub.id}
                  onClick={() => setActiveSubChapterTab(idx + 1)}
                  className={`px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all whitespace-nowrap shrink-0 flex items-center space-x-2 border-b-2 ${
                    activeSubChapterTab === idx + 1
                      ? 'border-indigo-600 text-indigo-600 bg-indigo-50/60'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Sub-Bab {idx + 1}: {sub.title}</span>
                </button>
              ))}
            </div>

            {/* TAB CONTENT 0: Overview & Key Theorems */}
            {activeSubChapterTab === 0 && (
              <div className="space-y-6">
                {/* Detailed Module Overview Content */}
                <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
                  <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center space-x-2">
                    <GraduationCap className="w-5 h-5 text-indigo-600" />
                    <span>Pengantar Teori & Landasan Konseptual</span>
                  </h3>
                  <MathRenderer content={activeModule.content} />
                </div>

                {/* Geometry Diagram for Geometri Modules */}
                {activeModule.topic === 'Geometri' && (
                  <div className="space-y-3">
                    <div className="p-4 bg-indigo-50/70 border border-indigo-200/80 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                      <span className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                        <Compass className="w-4 h-4 text-indigo-600" />
                        Pilih Visualisasi Teorema Geometri:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { type: 'ceva-menelaus', label: 'Ceva & Menelaus' },
                          { type: 'cyclic-quad', label: 'Segiempat Siklik' },
                          { type: 'power-of-point', label: 'Kuasa Titik' },
                          { type: 'incircle-excircle', label: 'Incircle & Excircle' },
                          { type: 'euler-line', label: 'Garis Euler & 9-Titik' },
                          { type: 'miquel-theorem', label: 'Teorema Miquel' },
                          { type: 'simson-line', label: 'Garis Simson' },
                          { type: 'pascal-theorem', label: 'Teorema Pascal' },
                        ].map((item) => (
                          <button
                            key={item.type}
                            onClick={() => setOverviewDiagramType(item.type as GeometryDiagramType)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                              overviewDiagramType === item.type
                                ? 'bg-indigo-600 text-white shadow-xs'
                                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    <GeometryVisualizer
                      type={overviewDiagramType}
                      title="Diagram Interaktif Konfigurasi Geometri Utuh"
                      caption="Eksplorasi garis, lingkaran, dan perpotongan titik secara langsung melalui kontrol interaktif."
                    />
                  </div>
                )}

                {/* Key Theorems Breakdown */}
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                    <Sparkles className="w-5 h-5 text-indigo-600" />
                    <span>Teorema & Lemma Utama Modul</span>
                  </h3>

                  <div className="grid grid-cols-1 gap-4">
                    {activeModule.keyTheorems.map((thm, idx) => (
                      <div
                        key={idx}
                        className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-indigo-900 text-base">
                            {idx + 1}. {thm.name}
                          </h4>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-600 font-bold">
                            Pernyataan Teorema
                          </span>
                        </div>

                        <div className="p-3 bg-white rounded-xl border border-slate-200 text-sm">
                          <MathRenderer content={thm.statement} />
                        </div>

                        <div className="text-xs space-y-1">
                          <p className="font-bold text-slate-500">Garis Besar Pembuktian (Proof Outline):</p>
                          <div className="text-slate-700 leading-relaxed">
                            <MathRenderer content={thm.proofOutline} />
                          </div>
                        </div>

                        {thm.exampleProblem && (
                          <div className="p-3 rounded-xl bg-indigo-50/80 border border-indigo-100 text-xs text-indigo-900">
                            <span className="font-bold text-indigo-700 block mb-1">Contoh Penerapan Soal:</span>
                            <MathRenderer content={thm.exampleProblem} />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Application Strategy & Heuristics Guide */}
                {activeModule.applicationGuide && (
                  <div className="p-6 rounded-2xl bg-indigo-50/70 border border-indigo-200/80 space-y-3">
                    <h3 className="text-base font-extrabold text-indigo-950 flex items-center space-x-2">
                      <Compass className="w-5 h-5 text-indigo-600" />
                      <span>Cara Penerapan & Strategi Taktis Pemecahan Soal (Step-by-Step)</span>
                    </h3>
                    <div className="text-sm text-indigo-900 leading-relaxed">
                      <MathRenderer content={activeModule.applicationGuide} />
                    </div>
                  </div>
                )}

                {/* Recommended Books & Ebooks Section */}
                {activeModule.recommendedBooks && activeModule.recommendedBooks.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                      <Library className="w-5 h-5 text-indigo-600" />
                      <span>Rekomendasi Ebook & Buku Referensi Utama Olimpiade</span>
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {activeModule.recommendedBooks.map((book, bIdx) => (
                        <div
                          key={bIdx}
                          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all space-y-2 flex flex-col justify-between"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                                {book.level}
                              </span>
                              <BookMarked className="w-4 h-4 text-slate-400" />
                            </div>
                            <h4 className="font-extrabold text-slate-900 text-sm">
                              {book.title}
                            </h4>
                            <p className="text-xs font-semibold text-slate-500">
                              Penulis: {book.author}
                            </p>
                          </div>

                          <p className="text-xs text-slate-600 leading-relaxed pt-2 border-t border-slate-100">
                            {book.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tips Section */}
                <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 space-y-2">
                  <h4 className="text-sm font-bold text-amber-900 flex items-center space-x-2">
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    <span>Tips Penyelesaian Soal dari Pakar IMO:</span>
                  </h4>
                  <div className="space-y-1.5 text-xs text-slate-700">
                    {activeModule.tips.map((tip, idx) => (
                      <div key={idx} className="flex items-start space-x-1.5">
                        <span className="text-amber-600 font-bold">•</span>
                        <MathRenderer content={tip} inline />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT 1..N: Sub-Chapter Deep Lecture & Graded Examples */}
            {activeSubChapterTab > 0 && activeModule.subChapters && (
              (() => {
                const subChapter: SubChapter = activeModule.subChapters[activeSubChapterTab - 1];
                if (!subChapter) return null;

                return (
                  <div className="space-y-8">
                    {/* Sub-Chapter Title & Description Header */}
                    <div className="p-6 rounded-3xl bg-indigo-900 text-white space-y-2 shadow-md">
                      <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-800 text-indigo-200 text-xs font-bold">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>Sub-Bab {activeSubChapterTab} dari {activeModule.subChapters.length}</span>
                      </div>
                      <h3 className="text-2xl font-extrabold text-white">
                        {subChapter.title}
                      </h3>
                      <p className="text-indigo-200 text-xs sm:text-sm leading-relaxed">
                        {subChapter.description}
                      </p>
                    </div>

                    {/* Detailed Textbook Lecture Content */}
                    <div className="p-6 sm:p-8 rounded-3xl bg-slate-50 border border-slate-200/90 space-y-4">
                      <div className="flex items-center space-x-2 border-b border-slate-200 pb-3">
                        <GraduationCap className="w-5 h-5 text-indigo-600" />
                        <h4 className="text-base font-extrabold text-slate-900">
                          Materi Kuliah & Pemahaman Teoretis Mendalam
                        </h4>
                      </div>
                      <div className="text-slate-800">
                        <MathRenderer content={subChapter.detailedContent} />
                      </div>
                    </div>

                    {/* Geometry Visualizer Diagram if defined or if topic is Geometri */}
                    {(subChapter.diagramType || activeModule.topic === 'Geometri') && (
                      <GeometryVisualizer 
                        type={subChapter.diagramType || (
                          activeSubChapterTab === 1 ? 'ceva-menelaus' :
                          activeSubChapterTab === 2 ? 'cyclic-quad' :
                          activeSubChapterTab === 3 ? 'power-of-point' :
                          activeSubChapterTab === 4 ? 'incircle-excircle' :
                          activeSubChapterTab === 5 ? 'euler-line' :
                          activeSubChapterTab === 6 ? 'miquel-theorem' :
                          activeSubChapterTab === 7 ? 'simson-line' : 'pascal-theorem'
                        )}
                        title={`Visualisasi Geometri Interaktif: ${subChapter.title}`}
                        caption="Gunakan kontrol interaktif untuk mengubah parameter, menggeser titik, dan mengamati pembuktian rasio/sudut secara visual."
                      />
                    )}

                    {/* Graded Worked Examples Section */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                        <div>
                          <h4 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2">
                            <Target className="w-5 h-5 text-emerald-600" />
                            <span>Contoh Soal & Pembahasan Terpandu Berjenjang</span>
                          </h4>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Disusun bertahap dari tingkat Intermediate (OSN-K), Medium (OSN-P), hingga Hard (IMO Shortlist)
                          </p>
                        </div>
                      </div>

                      <div className="space-y-6">
                        {subChapter.workedExamples.map((ex, exIdx) => {
                          const solutionKey = `${subChapter.id}-${exIdx}`;
                          const isExpanded = expandedSolutions[solutionKey] || false;

                          let levelBadgeColor = 'bg-amber-50 text-amber-700 border-amber-200';
                          if (ex.level === 'Medium') {
                            levelBadgeColor = 'bg-indigo-50 text-indigo-700 border-indigo-200';
                          } else if (ex.level === 'Hard') {
                            levelBadgeColor = 'bg-rose-50 text-rose-700 border-rose-200';
                          }

                          return (
                            <div 
                              key={exIdx}
                              className="rounded-3xl bg-white border border-slate-200 p-6 space-y-4 shadow-xs hover:border-slate-300 transition-all"
                            >
                              {/* Example Level & Header */}
                              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                                <div className="flex items-center space-x-2">
                                  <span className={`px-3 py-1 rounded-full text-xs font-bold border ${levelBadgeColor}`}>
                                    {ex.levelLabel}
                                  </span>
                                  <h5 className="font-bold text-slate-900 text-sm sm:text-base">
                                    {ex.title}
                                  </h5>
                                </div>
                                <span className="text-xs font-mono text-slate-400">
                                  Contoh Soal #{exIdx + 1}
                                </span>
                              </div>

                              {/* Problem Text */}
                              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-sm leading-relaxed text-slate-900">
                                <span className="text-xs font-extrabold text-slate-500 block mb-1 uppercase tracking-wider">
                                  Pernyataan Soal:
                                </span>
                                <MathRenderer content={ex.problemText} />
                              </div>

                              {/* Solution Toggle Button */}
                              <div>
                                <button
                                  onClick={() => toggleSolution(solutionKey)}
                                  className="w-full py-2.5 px-4 rounded-2xl bg-indigo-50 hover:bg-indigo-100/80 text-indigo-700 font-bold text-xs flex items-center justify-between border border-indigo-100 transition-colors"
                                >
                                  <span className="flex items-center space-x-2">
                                    <Award className="w-4 h-4 text-indigo-600" />
                                    <span>{isExpanded ? 'Sembunyikan Pembahasan Detail' : 'Tampilkan Pembahasan & Solusi Langkah demi Langkah'}</span>
                                  </span>
                                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                </button>
                              </div>

                              {/* Expanded Solution View */}
                              {isExpanded && (
                                <div className="space-y-4 pt-2">
                                  <div className="p-5 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 text-slate-900 space-y-3">
                                    <span className="text-xs font-extrabold text-emerald-800 uppercase tracking-wider block">
                                      Pembahasan Lengkap & Bukti Formal:
                                    </span>
                                    <div className="text-sm">
                                      <MathRenderer content={ex.solutionText} />
                                    </div>
                                  </div>

                                  {/* Key Takeaway */}
                                  <div className="p-4 rounded-2xl bg-indigo-900 text-white space-y-1">
                                    <span className="text-xs font-bold text-indigo-200 uppercase tracking-wider flex items-center space-x-1">
                                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                                      <span>Konsep Kunci (Key Takeaway):</span>
                                    </span>
                                    <p className="text-xs font-medium leading-relaxed text-indigo-100">
                                      {ex.keyTakeaway}
                                    </p>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Challenge Problems Section */}
                    {subChapter.challengeProblems && subChapter.challengeProblems.length > 0 && (
                      <div className="space-y-6 pt-4 border-t border-slate-200">
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <div>
                            <h4 className="text-lg font-extrabold text-amber-950 flex items-center space-x-2">
                              <Flame className="w-5 h-5 text-amber-600 animate-bounce" />
                              <span>Soal Tantangan Sub-Bab (Challenge Problems)</span>
                            </h4>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Uji kemandirianmu! Tulis draf lembar jawaban, buka hint jika kesulitan, lalu cocokkan dengan solusi formal.
                            </p>
                          </div>
                        </div>

                        <div className="space-y-6">
                          {subChapter.challengeProblems.map((ch, chIdx) => {
                            const chKey = `${subChapter.id}-ch-${ch.id || chIdx}`;
                            const isHintOpen = expandedHints[chKey] || false;
                            const isSolOpen = expandedChallengeSolutions[chKey] || false;
                            const userDraft = challengeDrafts[chKey] || '';

                            return (
                              <div
                                key={chIdx}
                                className="rounded-3xl bg-amber-50/40 border border-amber-200/90 p-6 space-y-4 shadow-sm hover:border-amber-300 transition-all"
                              >
                                {/* Challenge Header */}
                                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/60 pb-3">
                                  <div className="flex items-center space-x-2">
                                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500 text-slate-950 shadow-2xs">
                                      {ch.difficultyLabel || 'Soal Tantangan'}
                                    </span>
                                    <h5 className="font-extrabold text-amber-950 text-sm sm:text-base">
                                      {ch.title}
                                    </h5>
                                  </div>
                                  <span className="text-xs font-mono text-amber-800 font-bold">
                                    Tantangan #{chIdx + 1}
                                  </span>
                                </div>

                                {/* Problem Statement */}
                                <div className="p-4 rounded-2xl bg-white border border-amber-200 text-sm leading-relaxed text-slate-900 shadow-2xs">
                                  <span className="text-xs font-extrabold text-amber-800 block mb-1 uppercase tracking-wider flex items-center space-x-1">
                                    <Target className="w-3.5 h-3.5 text-amber-600" />
                                    <span>Pernyataan Soal Tantangan:</span>
                                  </span>
                                  <MathRenderer content={ch.problemText} />
                                </div>

                                {/* Interactive Scratchpad / Answer Draft */}
                                <div className="space-y-2">
                                  <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                                    <span className="flex items-center space-x-1.5">
                                      <Edit3 className="w-3.5 h-3.5 text-indigo-600" />
                                      <span>Lembar Coretan & Gagasan Buktimu:</span>
                                    </span>
                                    <span className="text-[10px] text-slate-400 font-normal">Tersimpan otomatis</span>
                                  </label>
                                  <textarea
                                    value={userDraft}
                                    onChange={(e) => handleDraftChange(chKey, e.target.value)}
                                    placeholder="Tuliskan gagasan, persamaan, atau langkah pembuktian awalmu di sini..."
                                    rows={3}
                                    className="w-full p-3 bg-white border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-mono shadow-2xs resize-y"
                                  />
                                </div>

                                {/* Actions: Hint Toggle & Solution Toggle */}
                                <div className="flex flex-wrap gap-3 pt-1">
                                  {ch.hint && (
                                    <button
                                      onClick={() => toggleHint(chKey)}
                                      className="py-2 px-4 rounded-xl bg-amber-100 hover:bg-amber-200/80 text-amber-900 font-bold text-xs flex items-center space-x-1.5 transition-colors border border-amber-200"
                                    >
                                      <HelpCircle className="w-3.5 h-3.5 text-amber-700" />
                                      <span>{isHintOpen ? 'Sembunyikan Hint' : 'Buka Hint / Petunjuk'}</span>
                                    </button>
                                  )}

                                  <button
                                    onClick={() => toggleChallengeSolution(chKey)}
                                    className="py-2 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-xs"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-200" />
                                    <span>{isSolOpen ? 'Sembunyikan Solusi Formal' : 'Cocokkan dengan Solusi Formal'}</span>
                                  </button>
                                </div>

                                {/* Hint View */}
                                {isHintOpen && ch.hint && (
                                  <div className="p-4 rounded-2xl bg-amber-100/70 border border-amber-200 text-xs text-amber-950 space-y-1">
                                    <span className="font-extrabold text-amber-900 flex items-center space-x-1">
                                      <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                                      <span>Hint & Petunjuk Awal:</span>
                                    </span>
                                    <div className="leading-relaxed font-medium">
                                      <MathRenderer content={ch.hint} />
                                    </div>
                                  </div>
                                )}

                                {/* Challenge Solution View */}
                                {isSolOpen && (
                                  <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-slate-900 space-y-3">
                                    <span className="text-xs font-extrabold text-emerald-800 uppercase tracking-wider block flex items-center space-x-1">
                                      <Award className="w-4 h-4 text-emerald-600" />
                                      <span>Pembahasan & Solusi Formal Tantangan:</span>
                                    </span>
                                    <div className="text-sm">
                                      <MathRenderer content={ch.solutionText} />
                                    </div>
                                    {ch.keyTakeaway && (
                                      <div className="p-3 rounded-xl bg-emerald-900 text-white text-xs font-medium mt-2">
                                        <span className="font-bold text-emerald-300 block mb-0.5">Key Takeaway:</span>
                                        {ch.keyTakeaway}
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* IMO Practice Problem Banner Callout */}
                    <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 text-white space-y-4 shadow-xl border border-indigo-800">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-800/80 text-indigo-200 text-xs font-bold">
                            <Target className="w-3.5 h-3.5 text-amber-300" />
                            <span>Saatnya Latihan Mandiri</span>
                          </div>
                          <h4 className="text-xl font-extrabold text-white">
                            Siap Menguji Pemahaman Sub-Bab Ini?
                          </h4>
                          <p className="text-xs sm:text-sm text-indigo-200 max-w-xl">
                            Kamu telah mempelajari teori dan contoh soal terpandu. Sekarang giliranmu menyelesaikan Bank Soal IMO & OSN Mandiri untuk topik <strong className="text-white">{activeModule.topic}</strong> dengan bantuan Hint & Evaluator AI Juri IMO!
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            const topicToNav = activeModule.topic;
                            setActiveModule(null);
                            onNavigateToProblems(topicToNav);
                          }}
                          className="px-6 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-lg transition-all flex items-center justify-center space-x-2 shrink-0"
                        >
                          <span>Kerjakan Soal IMO Mandiri</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })()
            )}

            {/* Modal Actions Footer */}
            <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
              <div className="flex space-x-2">
                {activeModule.subChapters && (
                  <span className="text-xs font-semibold text-slate-500 hidden sm:inline">
                    Sub-Bab Aktif: {activeSubChapterTab === 0 ? 'Ikhtisar' : `Sub-Bab ${activeSubChapterTab} dari ${activeModule.subChapters.length}`}
                  </span>
                )}
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => setActiveModule(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
                >
                  Tutup Modul
                </button>

                <button
                  onClick={() => {
                    const topicToNav = activeModule.topic;
                    setActiveModule(null);
                    onNavigateToProblems(topicToNav);
                  }}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all flex items-center space-x-1.5"
                >
                  <span>Ke Bank Soal IMO</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
