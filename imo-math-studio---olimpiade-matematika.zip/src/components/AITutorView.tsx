import React, { useState, useRef, useEffect } from 'react';
import { IMOProblem } from '../types';
import { MathRenderer } from './MathRenderer';
import { Bot, Send, Sparkles, User, RefreshCw, Lightbulb, Compass, HelpCircle, Code } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

interface AITutorViewProps {
  activeProblem?: IMOProblem | null;
}

export const AITutorView: React.FC<AITutorViewProps> = ({ activeProblem }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Selamat datang di **Ruang Pembinaan Matematika Olimpiade IMO/OSN (FMIPA ITB)**.

Saya adalah Pembina Tim Olimpiade Matematika Indonesia (Dosen ITB). Di sini kita akan mendiskusikan penalaran kaku (*rigorous mathematical proof*), struktur teori, dan teknik pengerjaan soal tingkat nasional/internasional.

Fokus Diskusi Akademis:
- 📐 **Konstruksi Pembuktian Kaku**: Mengecek kesahihan alur logika, pengandaian *WLOG*, dan penggunaan lemma.
- 💡 **Teorema & Teknik Utama**: Pertidaksamaan (*Cauchy-Schwarz*, *Titu*, *AM-GM*, *Hölder*), *LTE Lemma*, *Titik Miquel*, *Inversi Lingkaran*, *Pigeonhole Principle*.
- 🔍 **Penjelasan Ala Dosen ITB**: Penjelasan matematis mendalam tanpa frasa template robotik.

Silakan tulis pertanyaan atau soal yang ingin kita bedah bersama!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [selectedTopic, setSelectedTopic] = useState<string>('Umum');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputPrompt;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setInputPrompt('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/math-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          topic: selectedTopic,
          problemContext: activeProblem ? {
            title: activeProblem.title,
            statement: activeProblem.statement,
          } : undefined,
          mode: 'diskusi',
        }),
      });

      if (!res.ok) throw new Error('Gagal menghubungi AI Tutor');
      const data = await res.json();

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: data.text || 'Maaf, tidak ada tanggapan.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error('Error sending message to AI Tutor:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          sender: 'ai',
          text: 'Maaf, terjadi kendala koneksi dengan server Tutor AI. Pastikan server Gemini aktif.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const presetQuestions = [
    { label: '📐 Bukti Pertidaksamaan Titu / Cauchy', text: 'Buktikan $\\frac{a^2}{b+c} + \\frac{b^2}{c+a} + \\frac{c^2}{a+b} \\ge \\frac{a+b+c}{2}$ untuk $a,b,c > 0$ secara kaku.' },
    { label: '💡 Beri Clue Tanpa Spoil', text: 'Bisa berikan saya 1 petunjuk awal tanpa membocorkan seluruh solusi?' },
    { label: '📐 Jelaskan Konsep Teorema', text: 'Jelaskan intuisi dasar dan cara menerapkan Teorema Ceva & Menelaus.' },
    { label: '🔍 Periksa Asumsi Logika', text: 'Apakah asumsi bahwa $a$ bernilai maksimum tanpa mengurangi keumuman (WLOG) valid di sini?' },
  ];

  const quickSymbols = ['\\forall', '\\exists', '\\le', '\\ge', '\\equiv', '\\pmod{n}', '\\sum', '\\frac{a}{b}'];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold mb-2">
            <Bot className="w-3.5 h-3.5" />
            <span>Asisten AI Olimpiade Matematika</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Tutor AI Gemini IMO</h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Diskusi Sokrates, eksplorasi teorema, dan bimbingan logika matematika tingkat olimpiade.
          </p>
        </div>

        {/* Topic Selector */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-500 font-bold">Topik Diskusi:</span>
          <select
            value={selectedTopic}
            onChange={(e) => setSelectedTopic(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-3.5 py-2 text-xs text-slate-800 font-semibold focus:outline-none focus:border-indigo-500 shadow-2xs"
          >
            <option value="Umum">Umum (Semua Cabang)</option>
            <option value="Aljabar">Aljabar</option>
            <option value="Kombinatorika">Kombinatorika</option>
            <option value="Geometri">Geometri</option>
            <option value="Teori Bilangan">Teori Bilangan</option>
          </select>
        </div>
      </div>

      {/* Context Banner if active problem loaded */}
      {activeProblem && (
        <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-100 text-xs flex items-center justify-between shadow-2xs">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <span className="text-indigo-950 font-bold">
              Fokus Diskusi Soal: <strong className="text-indigo-700">{activeProblem.title}</strong> ({activeProblem.topic})
            </span>
          </div>
          <span className="text-[10px] text-indigo-600 font-bold uppercase font-mono bg-white px-2 py-0.5 rounded-full border border-indigo-100">
            Context Active
          </span>
        </div>
      )}

      {/* Preset Action Buttons */}
      <div className="flex overflow-x-auto no-scrollbar touch-pan-x sm:flex-wrap gap-2 py-1">
        {presetQuestions.map((q, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(q.text)}
            disabled={isLoading}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors shadow-2xs"
          >
            {q.label}
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="p-4 sm:p-8 rounded-3xl bg-white border border-slate-200 space-y-4 min-h-[350px] sm:min-h-[420px] max-h-[50vh] sm:max-h-[550px] overflow-y-auto shadow-xs">
        {messages.map((msg) => {
          const isAI = msg.sender === 'ai';
          return (
            <div
              key={msg.id}
              className={`flex space-x-2.5 sm:space-x-3 ${isAI ? 'justify-start' : 'justify-end'}`}
            >
              {isAI && (
                <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center flex-shrink-0 text-indigo-600 font-bold">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[90%] sm:max-w-[75%] rounded-2xl p-3.5 sm:p-4 text-xs leading-relaxed space-y-1 break-words ${
                  isAI
                    ? 'bg-slate-50 border border-slate-200/90 text-slate-800'
                    : 'bg-indigo-600 text-white font-medium shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] opacity-75 mb-1 font-mono">
                  <span>{isAI ? 'Tutor AI IMO' : 'Anda'}</span>
                  <span>{msg.timestamp}</span>
                </div>

                <MathRenderer content={msg.text} className={isAI ? 'text-slate-800' : 'text-white'} />
              </div>

              {!isAI && (
                <div className="w-8 h-8 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center flex-shrink-0 text-amber-700 font-bold">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center space-x-3 text-indigo-600 text-xs">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center">
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
            </div>
            <span className="font-bold">Tutor AI sedang menyusun rumus & analisis...</span>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Input Box & Symbols */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 space-y-3 shadow-xs">
        {/* Quick Symbol Insert Bar */}
        <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar touch-pan-x pb-1 text-xs">
          <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider mr-1 shrink-0">Simbol:</span>
          {quickSymbols.map((sym, idx) => (
            <button
              key={idx}
              onClick={() => setInputPrompt((prev) => prev + ` $${sym}$ `)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-indigo-700 font-mono text-[11px] font-bold shrink-0"
            >
              ${sym}$
            </button>
          ))}
        </div>

        {/* Text Input Area */}
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder="Tanyakan konsep, minta hint, atau ajukan pertanyaan matematika..."
            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-medium"
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !inputPrompt.trim()}
            className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 flex items-center space-x-1.5 transition-all disabled:opacity-50"
          >
            <span>Kirim</span>
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
