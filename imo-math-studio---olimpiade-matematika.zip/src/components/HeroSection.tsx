import React, { useState, useMemo } from 'react';
import { 
  ArrowRight, Sparkles, Target, PenTool, Bot, Compass, ShieldCheck, Sigma, 
  Calendar, Flame, Shuffle, Bookmark, CheckCircle2, Lightbulb, Clock, BookMarked
} from 'lucide-react';
import { MathRenderer } from './MathRenderer';
import { IMOProblem, UserProgress } from '../types';
import { INITIAL_PROBLEMS } from '../data/imoData';

interface HeroSectionProps {
  onNavigate: (tab: string) => void;
  onSelectTopic: (topic: string) => void;
  problems?: IMOProblem[];
  onSelectProblemForProof?: (problem: IMOProblem) => void;
  onToggleBookmark?: (problemId: string) => void;
  userProgress?: UserProgress;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ 
  onNavigate, 
  onSelectTopic, 
  problems = INITIAL_PROBLEMS,
  onSelectProblemForProof,
  onToggleBookmark,
  userProgress
}) => {
  const [shuffleOffset, setShuffleOffset] = useState<number>(0);
  const [showHint, setShowHint] = useState<boolean>(false);

  // Deterministically select a daily problem based on current date + offset
  const dailyProblem = useMemo(() => {
    if (!problems || problems.length === 0) return INITIAL_PROBLEMS[0];
    const today = new Date();
    const dateStr = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
    let hash = 0;
    for (let i = 0; i < dateStr.length; i++) {
      hash = (hash << 5) - hash + dateStr.charCodeAt(i);
      hash |= 0;
    }
    const baseIndex = Math.abs(hash) % problems.length;
    const finalIndex = (baseIndex + shuffleOffset) % problems.length;
    return problems[finalIndex];
  }, [problems, shuffleOffset]);

  const isBookmarked = userProgress?.bookmarkedProblemIds.includes(dailyProblem.id);
  const isSolved = userProgress?.solvedProblemIds.includes(dailyProblem.id);

  // Formatted Indonesian date
  const formattedToday = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const pillars = [
    {
      id: 'Aljabar',
      name: 'Aljabar (Algebra)',
      icon: '∑',
      color: 'bg-amber-50/80 border-amber-200 text-amber-900',
      badge: 'bg-amber-100 text-amber-800 border-amber-200',
      description: 'Persamaan fungsional, polinomial, dan ketaksamaan Cauchy-Schwarz, AM-GM, Hölder.',
      formulaSample: 'a^2 + b^2 + c^2 \\ge ab + bc + ca',
    },
    {
      id: 'Kombinatorika',
      name: 'Kombinatorika (Combinatorics)',
      icon: '∁',
      color: 'bg-blue-50/80 border-blue-200 text-blue-900',
      badge: 'bg-blue-100 text-blue-800 border-blue-200',
      description: 'Teori Graf, Pigeonhole Principle, Invarian, Rekurensi, dan Double Counting.',
      formulaSample: '|A \\cup B| = |A| + |B| - |A \\cap B|',
    },
    {
      id: 'Geometri',
      name: 'Geometri (Geometry)',
      icon: '∆',
      color: 'bg-emerald-50/80 border-emerald-200 text-emerald-900',
      badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      description: 'Geometri bidang, segiempat siklik, Teorema Ceva & Menelaus, Inversi, dan Titik Miquel.',
      formulaSample: '\\frac{AF}{FB} \\cdot \\frac{BD}{DC} \\cdot \\frac{CE}{EA} = 1',
    },
    {
      id: 'Teori Bilangan',
      name: 'Teori Bilangan (Number Theory)',
      icon: '≡',
      color: 'bg-purple-50/80 border-purple-200 text-purple-900',
      badge: 'bg-purple-100 text-purple-800 border-purple-200',
      description: 'Aritmetika modulo, Teorema Fermat/Euler, Persamaan Diophantine, dan LTE Lemma.',
      formulaSample: 'a^{\\phi(n)} \\equiv 1 \\pmod{n}',
    },
  ];

  return (
    <div className="space-y-10 pb-12">
      {/* Hero Bento Grid Block */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Hero Bento Card (8 Cols) */}
        <div className="lg:col-span-8 bg-indigo-600 rounded-3xl p-6 sm:p-10 relative overflow-hidden text-white shadow-lg flex flex-col justify-between">
          <div className="relative z-10 space-y-5 sm:space-y-6">
            <span className="bg-indigo-400/30 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider inline-block">
              Platform Olimpiade Matematika IMO
            </span>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-sans font-extrabold tracking-tight leading-tight">
              Kuasai Olimpiade Matematika Internasional
            </h1>

            <p className="text-indigo-100 max-w-xl text-xs sm:text-lg leading-relaxed font-normal">
              Kuasai 4 Pilar IMO, latih soal olimpiade autentik, tulis pembuktian kaku dengan KaTeX, dan dapatkan skor instan dari Evaluator Juri AI.
            </p>

            <div className="flex flex-col sm:flex-row flex-wrap gap-2.5 sm:gap-3 pt-2">
              <button
                onClick={() => onNavigate('problems')}
                className="w-full sm:w-auto justify-center bg-white text-indigo-600 px-5 py-3.5 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-md flex items-center space-x-2 text-xs sm:text-sm"
              >
                <Target className="w-4 h-4" />
                <span>Bank Soal IMO</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('workspace')}
                className="w-full sm:w-auto justify-center bg-indigo-500/80 text-white px-5 py-3.5 rounded-xl font-bold border border-indigo-400 hover:bg-indigo-500 transition-colors flex items-center space-x-2 text-xs sm:text-sm"
              >
                <PenTool className="w-4 h-4" />
                <span>Papan Pembuktian</span>
              </button>

              <button
                onClick={() => onNavigate('dictionary')}
                className="w-full sm:w-auto justify-center bg-indigo-900/60 text-white px-5 py-3.5 rounded-xl font-bold border border-indigo-400/50 hover:bg-indigo-900/80 transition-colors flex items-center space-x-2 text-xs sm:text-sm"
              >
                <BookMarked className="w-4 h-4 text-indigo-300" />
                <span>Kamus Simbol</span>
              </button>

              <button
                onClick={() => onNavigate('tutor')}
                className="w-full sm:w-auto justify-center bg-indigo-900/60 text-white px-5 py-3.5 rounded-xl font-bold border border-indigo-400/50 hover:bg-indigo-900/80 transition-colors flex items-center space-x-2 text-xs sm:text-sm"
              >
                <Bot className="w-4 h-4 text-indigo-300" />
                <span>Tutor AI</span>
              </button>
            </div>
          </div>

          <div className="absolute top-[-5%] right-[-5%] opacity-10 text-[110px] sm:text-[220px] font-black italic select-none pointer-events-none font-serif">
            IMO
          </div>
        </div>

        {/* Feature Highlights Bento Card (4 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200 p-6 flex flex-col justify-between shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-800">Fitur Unggulan IMO</h3>
            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-100">
              Pro Engine
            </span>
          </div>

          <div className="space-y-3 flex-1">
            <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
              <div className="p-2 rounded-xl bg-indigo-100 text-indigo-600 font-bold">
                <Sigma className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-xs text-slate-800">Presisi TeX KaTeX</p>
                <p className="text-[11px] text-slate-500">Render formula LaTeX seketika</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
              <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-xs text-slate-800">Rubrik Juri IMO 0-7</p>
                <p className="text-[11px] text-slate-500">Evaluasi bukti logika terinci</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
              <div className="p-2 rounded-xl bg-amber-100 text-amber-700 font-bold">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-xs text-slate-800">Clue Bertahap Sokrates</p>
                <p className="text-[11px] text-slate-500">Bimbingan tanpa spoil jawaban</p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-indigo-50/80 border border-indigo-100 rounded-2xl flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-900">Mulai Latihan Hari Ini</span>
            <button
              onClick={() => onNavigate('exam')}
              className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-xs hover:bg-indigo-700"
            >
              Simulasi Ujian
            </button>
          </div>
        </div>
      </div>

      {/* Daily Problem Widget (Soal Harian 24 Jam) */}
      <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-indigo-800/80">
        {/* Background glow & watermark */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          {/* Header Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-indigo-800/60 pb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold text-amber-400 tracking-wider uppercase">Tantangan Soal Harian</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-slate-950 flex items-center space-x-1">
                    <Clock className="w-3 h-3 inline" />
                    <span>24 JAM</span>
                  </span>
                </div>
                <p className="text-xs text-indigo-200 font-medium mt-0.5">{formattedToday}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {userProgress && (
                <div className="px-3 py-1 rounded-xl bg-indigo-800/50 border border-indigo-700/60 text-xs text-indigo-200 flex items-center space-x-1.5 font-bold">
                  <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span>Streak: {userProgress.streakDays} Hari</span>
                </div>
              )}

              <button
                onClick={() => {
                  setShuffleOffset((prev) => prev + 1);
                  setShowHint(false);
                }}
                className="px-3 py-1.5 rounded-xl bg-indigo-800/80 hover:bg-indigo-700/80 border border-indigo-600/50 text-indigo-200 text-xs font-bold flex items-center space-x-1.5 transition-colors"
                title="Tukar Soal Harian"
              >
                <Shuffle className="w-3.5 h-3.5" />
                <span>Tukar Soal</span>
              </button>
            </div>
          </div>

          {/* Daily Problem Content */}
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center space-x-2">
                <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  {dailyProblem.topic}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {dailyProblem.difficulty}
                </span>
                <span className="text-xs text-indigo-300 font-mono">
                  {dailyProblem.source}
                </span>
              </div>

              {isSolved && (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Selesai Dikerjakan</span>
                </span>
              )}
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {dailyProblem.title}
              </h3>
            </div>

            <div className="p-4 sm:p-5 rounded-2xl bg-indigo-950/60 border border-indigo-800/80 text-indigo-100 text-xs sm:text-sm leading-relaxed overflow-x-auto shadow-inner">
              <MathRenderer content={dailyProblem.statement} />
            </div>

            {/* Hint Box if toggled */}
            {showHint && dailyProblem.hints && dailyProblem.hints.length > 0 && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
                <p className="font-bold flex items-center space-x-1.5 text-amber-300">
                  <Lightbulb className="w-4 h-4 text-amber-400" />
                  <span>Petunjuk Sokrates:</span>
                </p>
                <ul className="list-disc list-inside space-y-1 text-amber-200/90 leading-relaxed">
                  {dailyProblem.hints.map((hint, idx) => (
                    <li key={idx}>
                      <MathRenderer content={hint} inline />
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Action Bar */}
          <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-indigo-800/60">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  if (onSelectProblemForProof) {
                    onSelectProblemForProof(dailyProblem);
                  } else {
                    onNavigate('workspace');
                  }
                }}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-5 py-2.5 rounded-xl font-extrabold text-xs shadow-md flex items-center space-x-2 transition-colors"
              >
                <PenTool className="w-4 h-4" />
                <span>Kerjakan Sekarang di Papan Pembuktian</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setShowHint(!showHint)}
                className="px-3.5 py-2.5 rounded-xl bg-indigo-800/60 hover:bg-indigo-800 border border-indigo-700/60 text-indigo-200 text-xs font-bold flex items-center space-x-1.5 transition-colors"
              >
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <span>{showHint ? 'Sembunyikan Clue' : 'Lihat Clue Sokrates'}</span>
              </button>
            </div>

            {onToggleBookmark && (
              <button
                onClick={() => onToggleBookmark(dailyProblem.id)}
                className={`px-3.5 py-2.5 rounded-xl text-xs font-bold border transition-colors flex items-center space-x-1.5 ${
                  isBookmarked
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-indigo-800/40 text-indigo-300 border-indigo-700/60 hover:bg-indigo-800'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-300' : ''}`} />
                <span>{isBookmarked ? 'Tersimpan' : 'Simpan Soal'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4 Pillars Bento Grid Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-800 tracking-tight">4 Pilar Matematika IMO</h2>
            <p className="text-slate-500 text-xs mt-0.5">Pilih pilar cabang untuk menjelajahi silabus dan teorema kunci</p>
          </div>
          <button
            onClick={() => onNavigate('theory')}
            className="text-indigo-600 hover:text-indigo-700 text-xs font-bold flex items-center space-x-1 bg-indigo-50 border border-indigo-100 px-3 py-1.5 rounded-xl transition-colors"
          >
            <span>Semua Teorema</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {pillars.map((pillar) => (
            <div
              key={pillar.id}
              onClick={() => {
                onSelectTopic(pillar.id);
                onNavigate('theory');
              }}
              className={`group rounded-3xl ${pillar.color} border p-6 cursor-pointer transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 flex flex-col justify-between space-y-4`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-3xl font-serif font-extrabold opacity-90 group-hover:scale-105 transition-transform">
                    {pillar.icon}
                  </span>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${pillar.badge}`}>
                    Cabang Utama
                  </span>
                </div>

                <h3 className="font-bold text-base text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {pillar.name}
                </h3>

                <p className="text-slate-600 text-xs leading-relaxed">
                  {pillar.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200/60 space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Formula Sampel:</div>
                <div className="bg-white/90 px-3 py-2 rounded-xl border border-slate-200/80 text-xs font-mono text-slate-800 overflow-x-auto shadow-2xs">
                  <MathRenderer content={`$${pillar.formulaSample}$`} inline />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Platform Content Statistics Summary Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100">
              <Sigma className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Ringkasan Statistik & Silabus Belajar IMO</h3>
              <p className="text-xs text-slate-500">Statistik jumlah materi, teorema, lemma, dan bank soal yang siap dipelajari</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
              100% Autentik IMO
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div 
            onClick={() => onNavigate('theory')}
            className="p-4 bg-slate-50 hover:bg-indigo-50/50 transition-colors rounded-2xl border border-slate-200/80 space-y-1 cursor-pointer group"
          >
            <div className="text-3xl font-black text-indigo-600 font-serif group-hover:scale-105 transition-transform">10</div>
            <div className="text-xs font-bold text-slate-800">Modul Teori Kuliah</div>
            <p className="text-[11px] text-slate-500">Bukti, intuisi & pembahasan detail</p>
          </div>

          <div 
            onClick={() => onNavigate('theory')}
            className="p-4 bg-slate-50 hover:bg-emerald-50/50 transition-colors rounded-2xl border border-slate-200/80 space-y-1 cursor-pointer group"
          >
            <div className="text-3xl font-black text-emerald-600 font-serif group-hover:scale-105 transition-transform">25+</div>
            <div className="text-xs font-bold text-slate-800">Teorema & Lemma Kunci</div>
            <p className="text-[11px] text-slate-500">Ceva, LTE, Schur, Helly, Burnside</p>
          </div>

          <div 
            onClick={() => onNavigate('problems')}
            className="p-4 bg-slate-50 hover:bg-amber-50/50 transition-colors rounded-2xl border border-slate-200/80 space-y-1 cursor-pointer group"
          >
            <div className="text-3xl font-black text-amber-600 font-serif group-hover:scale-105 transition-transform">{problems.length}</div>
            <div className="text-xs font-bold text-slate-800">Bank Soal IMO & OSN</div>
            <p className="text-[11px] text-slate-500">Solusi kaku & Evaluator Juri AI</p>
          </div>

          <div 
            onClick={() => onNavigate('exam')}
            className="p-4 bg-slate-50 hover:bg-purple-50/50 transition-colors rounded-2xl border border-slate-200/80 space-y-1 cursor-pointer group"
          >
            <div className="text-3xl font-black text-purple-600 font-serif group-hover:scale-105 transition-transform">4.5 Jam</div>
            <div className="text-xs font-bold text-slate-800">Simulasi Ujian Realistis</div>
            <p className="text-[11px] text-slate-500">3 Soal Standar Hari Ujian IMO</p>
          </div>
        </div>
      </div>
    </div>
  );
};

