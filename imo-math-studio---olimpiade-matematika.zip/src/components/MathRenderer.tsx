import React, { useMemo } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';

interface MathRendererProps {
  content: string;
  className?: string;
  inline?: boolean;
}

const KATEX_MACROS: Record<string, string> = {
  "\\blacksquare": "\\rule{0.75em}{0.75em}",
  "\\QED": "\\rule{0.75em}{0.75em}",
  "\\qed": "\\rule{0.75em}{0.75em}",
  "\\square": "\\Box",
  "\\implies": "\\Longrightarrow",
  "\\impliedby": "\\Longleftarrow",
  "\\iff": "\\Longleftrightarrow",
  "\\N": "\\mathbb{N}",
  "\\Z": "\\mathbb{Z}",
  "\\Q": "\\mathbb{Q}",
  "\\R": "\\mathbb{R}",
  "\\C": "\\mathbb{C}",
  "\\FF": "\\mathbb{F}",
  "\\dbfrac": "\\dfrac",
  "\\lcm": "\\operatorname{lcm}",
  "\\gcd": "\\operatorname{gcd}",
  "\\mod": "\\operatorname{mod}",
  "\\sgn": "\\operatorname{sgn}",
  "\\arcsec": "\\operatorname{arcsec}",
  "\\arccsc": "\\operatorname{arccsc}",
  "\\arccot": "\\operatorname{arccot}",
  "\\tg": "\\operatorname{tg}",
  "\\ctg": "\\operatorname{ctg}",
  "\\arctg": "\\operatorname{arctg}",
  "\\arcctg": "\\operatorname{arcctg}",
  "\\coloneqq": ":=",
  "\\eqqcolon": "=:",
};

const renderKaTeXHTML = (rawMath: string, isBlock: boolean): string => {
  let math = rawMath.trim();
  
  // Clean up control characters that might have escaped into rawMath
  math = math
    .replace(/\x0C/g, '\\f')
    .replace(/\x08/g, '\\b')
    .replace(/\x0B/g, '\\v');

  // Convert top-level align/equation/gather environments to aligned in display mode for KaTeX compatibility
  if (isBlock) {
    math = math
      .replace(/\\begin\{(align\*?|equation\*?|gather\*?)\}/g, '\\begin{aligned}')
      .replace(/\\end\{(align\*?|equation\*?|gather\*?)\}/g, '\\end{aligned}');
  }

  try {
    return katex.renderToString(math, {
      displayMode: isBlock,
      throwOnError: false,
      trust: true,
      strict: false,
      macros: KATEX_MACROS,
    });
  } catch (e) {
    const safe = math.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `<span class="font-mono text-xs text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">${safe}</span>`;
  }
};

export const MathRenderer: React.FC<MathRendererProps> = ({ content, className = '', inline = false }) => {
  const renderedContent = useMemo(() => {
    if (!content) return '';

    let textToParse = content
      .replace(/\r\n/g, '\n')
      .replace(/\x0C/g, '\\f')
      .replace(/\x08/g, '\\b')
      .replace(/\x0B/g, '\\v');

    const mathMap = new Map<string, { isBlock: boolean; html: string }>();

    // 1. Preserve escaped dollar signs
    textToParse = textToParse.replace(/\\\$ /g, 'ESCAPEDDOLLARSPACE').replace(/\\\$/g, 'ESCAPEDDOLLAR');

    // 2. Extract Display Math Blocks ($$...$$, \[...\], \begin{...}...\end{...})
    // Math block regex: $$...$$
    textToParse = textToParse.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => {
      const token = `XPMATHBLOCKTOKEN${mathMap.size}ENDMATH`;
      const html = renderKaTeXHTML(math, true);
      mathMap.set(token, {
        isBlock: true,
        html: `<div class="my-3.5 overflow-x-auto py-3 px-4 text-center bg-indigo-50/50 rounded-2xl border border-indigo-100/80 text-indigo-950 shadow-2xs font-serif leading-relaxed">${html}</div>`,
      });
      return token;
    });

    // Display math regex: \[...\]
    textToParse = textToParse.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => {
      const token = `XPMATHBLOCKTOKEN${mathMap.size}ENDMATH`;
      const html = renderKaTeXHTML(math, true);
      mathMap.set(token, {
        isBlock: true,
        html: `<div class="my-3.5 overflow-x-auto py-3 px-4 text-center bg-indigo-50/50 rounded-2xl border border-indigo-100/80 text-indigo-950 shadow-2xs font-serif leading-relaxed">${html}</div>`,
      });
      return token;
    });

    // Environments: \begin{align*}...\end{align*}, \begin{cases}...\end{cases}, etc.
    textToParse = textToParse.replace(/\\begin\{(align\*?|equation\*?|gather\*?|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|cases|aligned|split|subarray|array|eqnarray\*?)\}([\s\S]*?)\\end\{\1\}/g, (fullMatch) => {
      const token = `XPMATHBLOCKTOKEN${mathMap.size}ENDMATH`;
      const html = renderKaTeXHTML(fullMatch, true);
      mathMap.set(token, {
        isBlock: true,
        html: `<div class="my-3.5 overflow-x-auto py-3 px-4 text-center bg-indigo-50/50 rounded-2xl border border-indigo-100/80 text-indigo-950 shadow-2xs font-serif leading-relaxed">${html}</div>`,
      });
      return token;
    });

    // 3. Extract Inline Math (\(... \), $...$)
    // Inline math regex: \(...\)
    textToParse = textToParse.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => {
      const token = `XPMATHINLINETOKEN${mathMap.size}ENDTOK`;
      const html = renderKaTeXHTML(math, false);
      mathMap.set(token, {
        isBlock: false,
        html: `<span class="inline-math font-medium mx-0.5">${html}</span>`,
      });
      return token;
    });

    // Inline math regex: $...$
    textToParse = textToParse.replace(/\$([^\$\n\r]+?)\$/g, (_, math) => {
      const token = `XPMATHINLINETOKEN${mathMap.size}ENDTOK`;
      const html = renderKaTeXHTML(math, false);
      mathMap.set(token, {
        isBlock: false,
        html: `<span class="inline-math font-medium mx-0.5">${html}</span>`,
      });
      return token;
    });

    // 4. Restore escaped dollar signs
    textToParse = textToParse
      .replace(/ESCAPEDDOLLARSPACE/g, '$ ')
      .replace(/ESCAPEDDOLLAR/g, '$');

    // Helper to parse inline markdown (bold, italic, code, blacksquare, qed)
    const parseInlineMarkdown = (str: string): string => {
      return str
        .replace(/\\blacksquare|\\QED|\\qed/g, '<span class="font-bold text-indigo-700 ml-1">■</span>')
        .replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold">$1</strong>')
        .replace(/__([^_]+)__/g, '<strong class="font-bold">$1</strong>')
        .replace(/\*([^\*]+)\*/g, '<em class="italic">$1</em>')
        .replace(/`([^`]+)`/g, '<code class="bg-slate-100 text-indigo-700 px-1.5 py-0.5 rounded text-xs font-mono">$1</code>');
    };

    // If pure inline mode requested
    if (inline) {
      let result = parseInlineMarkdown(textToParse);
      mathMap.forEach((entry, token) => {
        result = result.split(token).join(entry.html);
      });
      return result;
    }

    // Process line by line for block markdown & layout
    const lines = textToParse.split('\n');
    const processedLines: string[] = [];
    let inUnorderedList = false;
    let inOrderedList = false;
    let inCodeBlock = false;
    let codeBlockContent: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];

      // Code block handling (```)
      if (line.trim().startsWith('```')) {
        if (inCodeBlock) {
          // Close code block
          processedLines.push(`<pre class="bg-slate-900 text-slate-100 p-4 rounded-2xl text-xs font-mono overflow-x-auto my-3"><code>${codeBlockContent.join('\n')}</code></pre>`);
          codeBlockContent = [];
          inCodeBlock = false;
        } else {
          inCodeBlock = true;
        }
        continue;
      }

      if (inCodeBlock) {
        codeBlockContent.push(line);
        continue;
      }

      // Check if line contains a block math token
      const blockMathMatch = line.match(/XPMATHBLOCKTOKEN\d+ENDMATH/);
      if (blockMathMatch) {
        if (inUnorderedList) { processedLines.push('</ul>'); inUnorderedList = false; }
        if (inOrderedList) { processedLines.push('</ol>'); inOrderedList = false; }

        // Check if this line is also a heading
        const headerMatch = line.match(/^\s*(#{1,6})\s+(.*)/);
        if (headerMatch) {
          const level = headerMatch[1].length;
          const headingContent = headerMatch[2];
          const parts = headingContent.split(/(XPMATHBLOCKTOKEN\d+ENDMATH)/);
          const innerHtml = parts.map(part => {
            if (part.startsWith('XPMATHBLOCKTOKEN')) return part;
            return parseInlineMarkdown(part);
          }).join('');

          if (level === 1) {
            processedLines.push(`<h1 class="text-xl font-black text-indigo-950 mt-6 mb-3 tracking-tight pb-2 border-b border-indigo-200">${innerHtml}</h1>`);
          } else if (level === 2) {
            processedLines.push(`<h2 class="text-lg font-extrabold text-indigo-950 mt-5 mb-2.5 tracking-tight pb-1.5 border-b border-indigo-100">${innerHtml}</h2>`);
          } else if (level === 3) {
            processedLines.push(`<h3 class="text-base font-extrabold text-indigo-950 mt-5 mb-2.5 tracking-tight pb-1 border-b border-indigo-100/80">${innerHtml}</h3>`);
          } else {
            processedLines.push(`<h4 class="text-sm font-extrabold text-indigo-900 mt-4 mb-2 tracking-tight">${innerHtml}</h4>`);
          }
          continue;
        }

        // Split line by block math token so text before/after stays in <p> and block stays as <div>
        const parts = line.split(/(XPMATHBLOCKTOKEN\d+ENDMATH)/);
        for (const part of parts) {
          if (part.startsWith('XPMATHBLOCKTOKEN')) {
            processedLines.push(part);
          } else if (part.trim() !== '') {
            const parsedPart = parseInlineMarkdown(part);
            processedLines.push(`<p class="my-1.5 leading-relaxed">${parsedPart}</p>`);
          }
        }
        continue;
      }

      // Unordered list item (- or *)
      if (/^\s*[-*]\s+(.*)/.test(line)) {
        if (inOrderedList) {
          processedLines.push('</ol>');
          inOrderedList = false;
        }
        if (!inUnorderedList) {
          processedLines.push('<ul class="my-2 space-y-1.5 pl-1">');
          inUnorderedList = true;
        }
        const itemText = parseInlineMarkdown(line.replace(/^\s*[-*]\s+(.*)/, '$1'));
        processedLines.push(`<li class="ml-5 list-disc leading-relaxed">${itemText}</li>`);
        continue;
      } else if (inUnorderedList && line.trim() === '') {
        processedLines.push('</ul>');
        inUnorderedList = false;
      }

      // Ordered list item (1. )
      if (/^\s*\d+\.\s+(.*)/.test(line)) {
        if (inUnorderedList) {
          processedLines.push('</ul>');
          inUnorderedList = false;
        }
        if (!inOrderedList) {
          processedLines.push('<ol class="my-2 space-y-1.5 pl-1">');
          inOrderedList = true;
        }
        const itemText = parseInlineMarkdown(line.replace(/^\s*\d+\.\s+(.*)/, '$1'));
        processedLines.push(`<li class="ml-5 list-decimal leading-relaxed">${itemText}</li>`);
        continue;
      } else if (inOrderedList && line.trim() === '') {
        processedLines.push('</ol>');
        inOrderedList = false;
      }

      // Headers (robust matching for #, ##, ###, ####, #####, ######)
      const headerMatch = line.match(/^\s*(#{1,6})\s+(.*)/);
      if (headerMatch) {
        if (inUnorderedList) { processedLines.push('</ul>'); inUnorderedList = false; }
        if (inOrderedList) { processedLines.push('</ol>'); inOrderedList = false; }

        const level = headerMatch[1].length;
        const heading = parseInlineMarkdown(headerMatch[2]);
        if (level === 1) {
          processedLines.push(`<h1 class="text-xl font-black text-indigo-950 mt-6 mb-3 tracking-tight pb-2 border-b border-indigo-200">${heading}</h1>`);
        } else if (level === 2) {
          processedLines.push(`<h2 class="text-lg font-extrabold text-indigo-950 mt-5 mb-2.5 tracking-tight pb-1.5 border-b border-indigo-100">${heading}</h2>`);
        } else if (level === 3) {
          processedLines.push(`<h3 class="text-base font-extrabold text-indigo-950 mt-5 mb-2.5 tracking-tight pb-1 border-b border-indigo-100/80">${heading}</h3>`);
        } else {
          processedLines.push(`<h4 class="text-sm font-extrabold text-indigo-900 mt-4 mb-2 tracking-tight">${heading}</h4>`);
        }
        continue;
      }

      if (line.startsWith('> ')) {
        const quote = parseInlineMarkdown(line.slice(2));
        processedLines.push(`<blockquote class="pl-4 py-2 my-2.5 border-l-4 border-indigo-500 bg-indigo-50/50 rounded-r-2xl italic text-xs sm:text-sm leading-relaxed">${quote}</blockquote>`);
      } else if (line.trim() === '') {
        processedLines.push('<div class="h-2"></div>');
      } else {
        const parsed = parseInlineMarkdown(line);
        processedLines.push(`<p class="my-1.5 leading-relaxed">${parsed}</p>`);
      }
    }

    if (inUnorderedList) processedLines.push('</ul>');
    if (inOrderedList) processedLines.push('</ol>');

    let finalHtml = processedLines.join('');

    // Restore math blocks and inlines safely
    mathMap.forEach((entry, token) => {
      finalHtml = finalHtml.split(token).join(entry.html);
    });

    return finalHtml;
  }, [content, inline]);

  return (
    <div 
      className={`prose max-w-none text-inherit leading-relaxed ${className}`}
      dangerouslySetInnerHTML={{ __html: renderedContent }}
    />
  );
};
