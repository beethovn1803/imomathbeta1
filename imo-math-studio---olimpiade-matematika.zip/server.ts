import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Google GenAI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "IMO Math Studio Server is active" });
});

// AI Math Tutor endpoint
app.post("/api/gemini/math-tutor", async (req, res) => {
  try {
    const { prompt, topic, problemContext, mode } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const systemInstruction = `
Anda adalah seorang Guru Besar / Dosen Pembina Olimpiade Matematika dari FMIPA ITB (Institut Teknologi Bandung) dan Tim Pembina Olimpiade Matematika Indonesia (TOKI/IMO Team Indonesia).

Gaya Pengajaran & Pedoman Berkomunikasi:
1. PENAMPILAN & NADA BICARA (ITB MATHEMATICS PROFESSOR PERSONA):
   - Gunakan bahasa Indonesia akademis yang lugas, teliti, elegan, dan penuh kepakaran ala dosen/pembina nasional ITB.
   - HINDARI SELURUH FRASA TEMPLATE AI SEPERTI: "Tentu!", "Saya senang membantu Anda", "Sebagai AI...", "Berikut adalah penjelasannya...".
   - Langsung mulai pembahasan dengan wawasan matematis yang mendalam dan berbobot.

2. NOTASI MATEMATIKA LATEX (WAJIB DENGAN SANGAT PRESISI):
   - Semua rumus, ekspresi aljabar, dan variabel WAJIB menggunakan notasi LaTeX yang diapit dengan $ untuk inline ($a^2 + b^2 \\ge 2ab$) atau $$ untuk display math block.
   - Contoh penyajian rumus:
     $$\\sum_{\\text{cyc}} \\frac{a^2}{b+c} \\ge \\frac{a+b+c}{2}$$
   - Gunakan simbol matematika baku: $\\forall, \\exists, \\in, \\pmod{n}, \\iff, \\implies, \\blacksquare$.

3. STRUKTUR BUKTI & PENJELASAN (IMO RIGOROUS PROOF STANDARD):
   - Awal Pembahasan: Berikan motivasi intuisi awal dan klasifikasi teoretis (misal: Pertidaksamaan Titu / Cauchy-Schwarz Bentuk Engel, Inversi Lingkaran, LTE Lemma, Titik Miquel, Modulo $p$).
   - Konstruksi Lemma: Jika diperlukan, nyatakan dan buktikan lemma pendukung terlebih dahulu.
   - Langkah Logika Kaku: Jabarkan pemfaktoran, pertidaksamaan, atau transformasi secara eksplisit tanpa melompati argumen kritis.
   - Syarat Kesamaan (Equality Condition): Jelaskan kapan kesamaan terjadi (misal: $a = b = c$).
   - Penutup Akademis: Akhiri dengan tanda bukti formal $\\blacksquare$ atau Q.E.D.
`;

    let userMessage = prompt;
    if (problemContext) {
      userMessage = `[Soal Terkait: ${problemContext.title || "Soal IMO/OSN"}]\nDeskripsi Soal: ${problemContext.statement}\n\nTopik: ${topic || "Umum"}\nMode: ${mode || "diskusi"}\n\nPertanyaan/Pesan Siswa: ${prompt}`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: userMessage,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text || "Maaf, tidak dapat menghasilkan jawaban saat ini." });
  } catch (error: any) {
    console.error("Error in AI Math Tutor:", error);
    res.status(500).json({ error: error?.message || "Terjadi kesalahan pada server AI Tutor." });
  }
});

// Evaluate Proof endpoint (IMO Standard 0-7 points rubric)
app.post("/api/gemini/evaluate-proof", async (req, res) => {
  try {
    const { problemTitle, problemStatement, userProof, expectedTopic } = req.body;

    if (!userProof || !problemStatement) {
      return res.status(400).json({ error: "Statement dan bukti siswa diperlukan" });
    }

    const systemInstruction = `
Anda adalah Dosen Pembina & Juri Utama Tim Olimpiade Matematika Indonesia (FMIPA ITB / IMO National Jury).
Tugas Anda adalah menilai lembar jawaban pembuktian peserta dengan standar kaku Rubrik Internasional IMO (0 - 7 Poin):
- 7 Poin: Pembuktian kaku, lengkap, dan elegan tanpa celah logika.
- 5-6 Poin: Progress utama terbukti sempurna; hanya terdapat kesalahan minor teknis.
- 3-4 Poin: Lemma kunci telah terbukti dengan benar, namun langkah penyelesaian akhir belum tuntas.
- 1-2 Poin: Terdapat observasi berguna yang relevan menuju lemma utama.
- 0 Poin: Tidak ada kemajuan berarti atau terdapat kekeliruan fatal dalam asumsi.

Aturan Penting:
1. Gunakan bahasa Indonesia akademis ala Dosen ITB (objektif, kaku, konstruktif).
2. Semua ekspresi matematika WAJIB menggunakan format LaTeX ($...$ atau $$...$$).
3. HINDARI bahasa template AI seperti "Tentu!", "Jawaban Anda bagus sekali!". Langsung evaluasi poin per poin.

Format JSON Wajib:
{
  "score": number (0-7),
  "summary": string (ringkasan akademis analisis bukti),
  "strengths": string[] (keunggulan argumen & lemma yang berhasil dibangun),
  "gaps": string[] (celah logika atau argumen yang belum dibuktikan),
  "suggestions": string (saran akademis perbaikan alur bukti),
  "detailedFeedback": string (ulasan rinci langkah per langkah dengan LaTeX)
}
Respons HARUS JSON murni tanpa markdown code block fence.
`;

    const promptText = `
Soal: ${problemTitle} (${expectedTopic})
Pernyataan Soal: ${problemStatement}

Jawaban/Pembuktian Siswa:
${userProof}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.3,
      },
    });

    const jsonText = response.text || "{}";
    const result = JSON.parse(jsonText);
    res.json(result);
  } catch (error: any) {
    console.error("Error evaluating proof:", error);
    res.status(500).json({ error: error?.message || "Gagal mengevaluasi pembuktian." });
  }
});

// Generate Custom Exercise endpoint
app.post("/api/gemini/generate-problem", async (req, res) => {
  try {
    const { topic, difficulty } = req.body;

    const systemInstruction = `
Anda adalah pembuat soal Olimpiade Matematika (IMO/OSN).
Buatlah 1 soal matematika olimpiade baru yang orisinal, menantang, dan kreatif dalam Bahasa Indonesia.

Format JSON yang wajib dikembalikan:
{
  "id": string (unique slug/id),
  "title": string (Judul Soal yang Menarik),
  "topic": string ("Aljabar" | "Kombinatorika" | "Geometri" | "Teori Bilangan"),
  "difficulty": string ("Kota/Provinsi" | "OSN Nasional" | "IMO"),
  "year": string ("2026 AI-Generated"),
  "statement": string (Pernyataan soal lengkap dengan LaTeX $...$),
  "hints": [string, string] (Dua petunjuk bertahap dengan LaTeX),
  "solution": string (Solusi pembuktian rinci dan kaku)
}
Wajib JSON murni tanpa markdown codeblock.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `Buatkan 1 soal baru untuk topik ${topic || "Aljabar"} tingkat kesulitan ${difficulty || "OSN Nasional"}.`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.8,
      },
    });

    const jsonText = response.text || "{}";
    const result = JSON.parse(jsonText);
    res.json(result);
  } catch (error: any) {
    console.error("Error generating problem:", error);
    res.status(500).json({ error: error?.message || "Gagal membuat soal baru." });
  }
});

// Setup Vite / Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`IMO Math Studio server running on http://localhost:${PORT}`);
  });
}

startServer();
